# Loaded Roulette Design

Loaded Roulette is a roulette-based game for GameHub. Players plan bets at the same
time, watch a shared roulette spin, and race to reach a money goal.

This is a working basis for the game, with later modifications expected.
The rules below describe the current game. Numerical balance remains
adjustable through playtesting; deferred ideas are collected near the end.

Technical decisions and implementation details belong in the [implementation
notes](implementation.md).

## Game overview

Each round has a planning stage and a rolling stage. Planning contains Rewards,
Shop, Card Theft, Public Effects, Betting, and Final Preparations. Players
build their card collections, buy cards, modify betting spaces, place bets, and
use weaker personal effects before a shared roulette spin resolves everyone's
bets. Winning paid bets return stakes plus winnings; losing paid bets lose their
stakes. Free bets return profit only and cost nothing on a loss.
Money, debt, and owned cards persist according to their rules between rounds.

Cards, loans, hybrid personal shops, limited late-entry assistance, and these
planning substages are confirmed parts of the game. Their numerical balance and
values remain subject to playtesting; they are not merely optional future features.

- Game name: Loaded Roulette
- Number of players: 2-12. The room has 12 total places shared by players and
  spectators, rather than separate capacities for each role.
- Typical game length: Not yet measured; up to about 40 minutes is acceptable.

- Player objective: Build up net balance and reach the host's goal before the others.
- Winning condition: After a round is fully paid out, a player whose net balance
  reaches the goal qualifies to win. Net balance is cash minus outstanding debt.
  If several qualify, the highest net balance wins. An exact tie for the
  highest qualifying net balance leads to
  extra rounds between the tied players. Permanent departures leaving one
  participant award that participant an automatic win without the money goal.

Money is the in-game resource. Chips represent the amounts players put on bets;
each player's chips use their assigned color.

**Cash balance** is the player's settled cash, including borrowed cash.
**Available cash** is cash balance minus stakes reserved for unsettled bets.
**Net balance = cash balance - outstanding debt.** The winning goal and leader
comparisons use net balance, not cash or available cash. Borrowing increases
cash and debt; it does not by itself bring the player closer to winning.

## Intended player experience

Players should be attentive during the rolling stage and involved during the
planning stage. A large payout should feel exciting. During planning, players
should feel that they used their time wisely and made deliberate choices.
Winning should feel well fought for and satisfying.

Players who are behind should still feel that they have an understandable path
to winning. How well the betting choices alone achieve this needs playtesting;
cards, shops, late-entry assistance, and loans form the strategy and
comeback systems.

A possible later addition is a short explanation of the winning player's build
or strategy, helping others understand effective choices and synergies.
The current card catalogue is listed below; further effects and synergies can be
added later.

The game should remain readable and usable on phones as well as larger screens.

## Design priorities

1. **Keep planning simultaneous.** Players act in the same timed substages,
   rather than waiting through a separate turn for every player.
2. **Make risk and reward understandable.** Show available money, reserved
   stakes, debt, possible returns, and card modifiers clearly.
3. **Make the roll worth watching.** The shared spin creates anticipation and
   explains which bets won and how balances changed.
4. **Keep the race competitive.** Cards and loans provide choices for trailing
   players; limited late-entry assistance does not recreate a full earned build.
5. **Make crowded tables readable.** Identify each player's bets and amounts
   with up to 12 players, including on smaller screens.

## Game mechanics

### Starting a game

The host chooses a starting amount of money and a goal to reach. Each player
starts with the same configured amount and receives an assigned color. Their
chips reflect that color so others can identify who placed a bet and its size.

Players compete individually. The game opens with a planning stage and then
alternates between planning and rolling. One planning stage and one rolling
stage make a round; money, debt, and owned cards carry between rounds according
to their rules.

When the host allows late participation, spectators automatically enter at the
start of the next normal round's planning stage. A new participant receives the
host-configured late-player starting money and entry-card assistance based on
the current round. Returning participants retain money, debt, and cards instead
of receiving entry assistance again.

Use conventional roulette bets and payouts as the baseline, before card effects.

Use single-zero roulette: 37 slots, numbered 0 through 36, with conventional
single-zero roulette bets and payouts. Zero is not an ordinary red/black,
odd/even, or low/high win. The betting board and spinner use the same rules.

The basic prototype supports the conventional single-zero catalog: straight-up
(35:1 profit), splits (17:1), streets and zero trios (11:1), corners and first
four (8:1), six lines (5:1), dozens/columns (2:1), and red/black, odd/even,
low/high (1:1). Paid wins also return the original stake.

Chips may be dragged to a target or selected and then placed by clicking it. A
custom chip may represent any affordable whole amount. Repeated same-owner bets
on one space combine. Stack height represents that spot's stake as a share of
the owner's settled bankroll: one chip from $1 through 10%, then another chip
per 10% band up to ten. Compact displays use five 20% bands. Exact amounts
remain available; chips are a visual representation, not a finite inventory.

Starting balance ranges from 1,000 to 200,000 and goal from 100,000 to 2,000,000,
using draggable sliders in 1,000-unit increments.

### Turns and rounds

During planning, the main board is the classic roulette betting layout. All
participating players place bets during the same planning period and may place
multiple bets on the spaces they choose during the betting substage. Betting
ends when every participating player locks in or its shared timer expires.
Planning contains smaller substages; completing betting does not skip any Final
Preparations before rolling.

A player who places no bets has no betting gain or loss that round. The player
does not need to place a bet merely to let the round continue.

When rolling begins, the betting board is replaced by a roulette spinner. The
wheel rotates with an animated ball that eventually lands in a slot. The same
result is used for every player. Successful paid bets return the original stake
and profit according to the bet's rules; unsuccessful paid bets lose their
stakes. Free bets pay profit only on a win and lose no money on a loss. All bets are settled before comparing net balances or declaring a winner.

If nobody wins the match, admit eligible spectators when the host allows it,
then open the next planning stage. Each timed substage receives its own full
countdown when it opens. A spectator joining or receiving permission during
planning or rolling waits for that next round; they do not enter the current
round halfway through. Waiting spectators do not count toward the current
round's readiness requirement.

If players tie for the highest qualifying net balance, only the tied players
participate in the additional tiebreaker rounds. Do not admit new participants
after a tiebreaker begins or after the match has already been won.

### Rules and player actions

The server accepts bets, closes planning, determines the roulette result, and
settles the round. The visible spin communicates that result; it does not let a
player's device choose the winning slot.

#### Place a bet

A participating player chooses a legal bet space and an amount during Betting.
Their chips show the chosen space, ownership, and amount. Multiple bets may be
placed during the same round.

Players may bet any positive amount they currently have available, including
all of it. No additional per-space or per-round cap applies to ordinary paid
bets. Card-created free bets and free betting rounds use their own stated limits.
Previously reserved stakes and spent money are unavailable for new bets; reserve
accepted stakes so the same money cannot fund multiple actions.

Invalid bets should be rejected with an explanation without removing money or
changing the player's other accepted bets. Bets arriving after betting closes
cannot affect the spin already in progress.

Use whole-number money only, with a minimum positive stake of 1. Monetary
calculations round down to whole units. Percentage rates may include halves
(such as 0.5% or 2.5%); do not round those rates before applying them. Shop prices use the nearest-unit/nearest-five rule below. Host-setting values cannot be decimal.
The explicit round-up rule for catch-up card counts remains separate.

#### Change or remove a bet

While betting is open and the player has not ready, they
can change a bet's amount, move it to another legal space, or remove it.
Removing a bet makes its reserved stake available again.

Players may undo readiness and resume editing while the Betting substage remains
open. Once the server advances the substage, cancelling ready cannot reopen it.

#### Ready up or wait

A player locks in when satisfied with their bets. The betting substage can end
early once all participating players have ready; Final Preparations still
follow. A player can also wait for the timer; any accepted bets then become
final for that round. A player with no bets simply has nothing to win or lose
from the spin.

Every player-input planning substage has its own timer and a Ready up control.
Players can undo readiness while that substage is still open. Locking in does not
spend stakes or cards again, refund already spent actions, or trigger a separate
spin. All-ready can advance the substage before its deadline.

#### Roll and settle

Once betting closes, players cannot add, move, or remove bets for that round.
Final Preparations closes before rolling begins. Cards played there are
activated before the spin; outcome-dependent effects settle after the result
in the confirmed settlement order. The roulette result is
revealed, winning bets are identified, and all returns and losses are applied
once. A player can win some bets and lose others on the same spin; their final
balance reflects all of them.

The interface should distinguish the stake returned, the profit from a winning
bet, and the player's overall gain or loss for the round.

### Planning substages, cards, and shops

The planning order is Rewards -> Shop -> Card Theft -> Public Effects -> Betting
-> Final Preparations. Public placement uses stronger public effects; Final
Preparations uses weaker personal effects. These are substages of planning, not
additional top-level stages. Rolling follows Final Preparations. Reward
selection prepares the next round after the previous rolling stage and winner
check; there is no further reward draft once the match has been won.

Card Theft lasts 30 seconds, or ends when everyone is ready. Go Fish, Pickpocket,
Sticky Fingers, Double Choice, Interception, Reclaim, and Sleight of Hand are
restricted to this stage, including their reversed effects. Other card plays
wait until it ends, preventing a targeted player from spending or trading away
cards to dodge a steal. Competing thefts revalidate their original choices;
mandatory paid choices resolve at the deadline. The chip controls stay hidden.

#### Card rewards and scaling

Round 1 gives no cards and plays as ordinary roulette; card-related substages
begin in round 2. Rewards are offered at the start of that round's planning,
not after the same numbered round has finished:

| Round | Reward |
| --- | --- |
| 1 | None |
| 2 | Temporary |
| 3 | Temporary |
| 4 | Permanent |
| 5 | Temporary |
| 6 | Temporary |
| 7 | Permanent |

Repeat temporary, temporary, permanent thereafter. Permanent rewards occur in
rounds 4, 7, 10, and so on, replacing the temporary reward for that round.
Offer three cards where enough eligible cards exist. Temporary cards may
reappear when held. The initial card ideas below are subject to balance changes.

Permanent means that a card remains owned, not that its effect necessarily
grows. Permanent effects may be fixed bonuses, capped bonuses growing from
acquisition onward, or bonuses based on the match round counted from the start
of the game. Each card specifies how it uses these counts; do not impose a
single acquisition-round versus continuously updated rule on all cards.

Growing effects have fixed caps. Match-round-scaled cards should have stronger
late-game effects and higher caps where appropriate to help long matches end.
Numerical values remain adjustable after playtesting. Winning
payout modifiers apply to the full winning return, including the returned
paid stake. Positive payout bonus values, growth and caps are halved; negative
card values are unchanged. Other cash, debt, refund, tax and price percentages
retain their own values.

Cards may retain information specific to their effects, such as their current
scaling bonus or the debt amount an effect refers to. Refunds must follow the
card's stated rule exactly, rather than use one universal refund amount or
return more than the card promises. For example, a card saying "refund the
latest taken debt" refers to the player's most recently taken loan, not all debt
or an unrelated fixed amount. Preserve enough loan history to identify that
loan.

Debt-relief amounts are card-specific, as listed below. Final Preparations is
their initial window; broader use during planning is a deferred possibility.
Loan Relief is capped by the latest loan's unpaid amount; total-debt relief
also includes penalty debt. Neither restores that round's borrowing allowance.

Duration and stacking depend on each card's stated effect. Ordinary percentage
payout bonuses add together; cards explicitly saying to multiply or double use
that operation. Do not silently multiply ordinary additive bonuses.

Any card effect that deducts money from a player's total takes available money
first. If the deduction exceeds that money, add the uncovered amount to penalty
debt instead of making the cash balance negative. Do not spend money already
reserved for another accepted action. For example, a deduction of 100 with 30
available takes the 30 and adds 70 debt. This general rule uses the same penalty
debt treatment as Double Everything: no loan surcharge, no consumption of the
round's borrowing allowance, and normal debt accounting toward winning.

#### Card catalogue

Names and all numerical values are working ideas that can be tweaked and
balanced later. Temporary cards are consumed on use unless their final rules
say otherwise. Permanent cards remain owned. Public temporary cards below are
played during Public Effects and affect the current round.

##### Temporary cards

###### Beneficial effects

| Working name | Current effect |
| --- | --- |
| Loan Relief | Clear 50% of the latest loan's original debt, capped by its unpaid balance. |
| Debt Reduction | Pay off 20% of total outstanding debt. |
| More draws | Randomly place two free, uneditable bets, each worth 5% of current total. |
| Profit up | Gain +10% payout on this round's winning bets, including the returned paid stake. |
| Goal Grant | Receive cash equal to 5% of the required goal. |
| Cash Bonus | Receive cash equal to 10% of current total. |
| Random temp card (rare) | Receive two random temporary cards, excluding this card itself. |
| Random permanent card (rare) | Receive one random permanent card. |
| Shared Agreement | If every participant who placed a bet this round, including you, makes positive net betting profit, gain +15% winning payout. Abstaining participants are excluded. |
| Safety Net | Select a bet before rolling. If it loses, recover 50% of its paid stake. |
| Debt Collector | This round, winning bets additionally clear debt equal to 10% of their profit. |
| Quick Sale | Sell one other owned card, including a negative card, for 50% of its estimated normal shop price. Usable during planning. |
| On Hold | During Shop, reserve one available offer until your next Shop at its current price and discount. Maximum one reserved offer. |
| Shop Reroll | During the Shop stage, reroll all regular offers and the deal, for this player only. Other shops remain unchanged. |
| Reward Reroll | Before choosing a reward, replace all your current reward choices. Keep the same number of choices and remaining time. Use an already-owned copy; a newly chosen copy is saved for a later draft. |
| Go Fish | During Card Theft, choose another player and blindly select one temporary card to steal from their hand. |
| Pickpocket | During Card Theft, steal one random temporary card from another player's hand. |
| Sticky Fingers | During Card Theft, privately reveal two random temporary cards from another player's hand and steal one. |
| Double Choice | During Card Theft, steal one random temporary card from each of two random players. |
| Interception | During Card Theft, choose another player. At their next reward draft, take the first temporary card they select instead of them. The effect expires after that draft, even if no temporary card was selected. |
| Reclaim | During Card Theft, recover a card stolen from you if it is still a temporary card in its current owner's hand. |
| Equal Opportunity | During Final Preparations, gain +15% winning payout this round if you have the lowest settled net money among participants. Tied lowest players also qualify when they play this card. |

###### Neutral effects

| Working name | Current effect |
| --- | --- |
| Reassignment | During planning, choose one assigned Specialist copy and move its bonus to another betting spot. |
| Discard | Discard one of your cards. Use during planning, except Card Theft. |
| Trade up | Trade a temporary card for a choice among three permanent cards. Use during planning, except Card Theft. |
| Roll down | Trade a permanent card for three random temporary cards. Use during planning, except Card Theft. |

###### Risky effects

| Working name | Current effect |
| --- | --- |
| Sleight of Hand | During Card Theft, choose one temporary card from your hand and exchange it for a blind pick of one temporary card from another player's hand. |
| Double or nothing | Activate during Final Preparations. After normal betting settlement, a separate 50/50 gamble doubles positive net betting profit or removes that profit entirely. A zero-profit or losing round is unchanged. |
| Double Everything | Activate during Final Preparations. Double this round's net betting profit or net betting loss, with no separate coin flip. Uncovered additional losses become penalty debt. |

###### Negative effects

These cards apply automatically when received and discard themselves after
their stated penalty resolves or its duration ends.

| Working name | Current effect |
| --- | --- |
| Cold Streak | Your first winning round after acquiring this card receives 30% less payout. |
| Bad Deal | During your next Shop, halve the deal's discount, rounding down. The reduction lasts through that Shop's rerolls, then expires. Copies halve it again, with a minimum 1% discount. Reserved prices stay locked. |
| Bad Investment | Your next shop purchase costs 25% more. |
| Short Changed | During the next round only, winning bets receive 20% less payout. Discard after that round even if no bet wins. |
| Paperwork | You cannot borrow during the next planning stage. |
| Limited Selection | Your next reward draft offers one fewer choice, with a minimum of one. |
| Shop Closure | Skip your next Shop stage. |
| Public Silence | You cannot play public cards next round. |
| Collection Notice | After the next round, pay 5% of your current total. |
| Forced Sale | At the end of the next planning stage, discard one other card of your choice. |

###### Settlement notes

Hand theft and swaps affect temporary cards in players' hands, not permanent cards.
For all blind thefts and swaps, selections use shuffled, face-down cards, and
the chosen card's identity is revealed to its recipient only after the transfer.
Sticky Fingers explicitly allows its player to privately reveal cards before
choosing. Hand theft and swaps require enough eligible cards in the target's
hand. Interception targets a future reward instead, so an empty hand does not
prevent targeting that player. A transferred negative card applies to its new
owner immediately.

Double or nothing risks only positive net betting profit, not the original
stakes returned or the player's remaining balance. Resolve its separate 50/50
gamble after the normal roulette result and betting settlement, but before debt
repayment and the match winner check. It does not gamble shop purchases, loan
proceeds, or direct cash grants. For example, a round with 10,000 net betting
profit becomes either 20,000 profit or zero profit. A net betting loss remains
the same loss.

Double Everything is a separate temporary card from Double or nothing. Resolve
it after the normal betting outcome and before debt repayment and the winner
check. A net betting gain of 10,000 becomes 20,000; a net loss of 10,000 becomes
20,000 lost. A zero net outcome stays zero. It affects betting gain or loss,
not total wealth, shop spending, direct cash grants, or loan proceeds.

For an extra loss, first take remaining available money; turn only the uncovered
amount into penalty debt. Do not charge the original stake again. For example,
a normal net betting loss of 100 creates an extra loss of 100; if only 30 cash
remains, take that 30 and add 70 penalty debt. Cash never goes negative.
Penalty debt has no loan surcharge, does not consume the once-per-round loan,
and counts against winning like other outstanding debt. Show this risk before
playing the card.

Losing paid-stake refunds are calculated per wager before round-wide gambles.
Cashback copies add up to the paid stake; free wagers have nothing to refund.
Double or nothing is limited to one play per round; Double Everything copies
multiply the round result. Debt Reduction includes penalty debt. Loan Relief
uses the latest actual loan and does not treat penalty debt as a new loan.

##### Public temporary cards

###### Beneficial effects

| Working name | Current effect |
| --- | --- |
| Bounty (public) | Mark a betting spot; anyone winning a bet on that exact spot receives +25% payout this round. |
| Profit Bonus (public) | Increase all players' winning payouts by 15% this round. |
| Crowd Favorite (public) | Mark a number; straight-up wins there gain +5% payout per distinct player betting there, capped at +25%. |
| Lone Wolf (public) | Mark a number; a straight-up win gains +25% payout if exactly one player bets there. |

###### Neutral effects

| Working name | Current effect |
| --- | --- |
| White Out (public) | Remove all status effects, positive and negative, from one betting spot before Betting begins. |
| Copycat (public) | Copy one public effect already placed onto another eligible spot. |
| Reverse Fortune (public) | Turn one negative payout modifier on a spot into an equally strong positive modifier, or vice versa. |
| Relocation (public) | Move one status effect from its current spot to another eligible spot. |

###### Risky effects

| Working name | Current effect |
| --- | --- |
| Erase (public) | Remove one randomly selected status effect from a betting spot before Betting begins. |

###### Negative effects

| Working name | Current effect |
| --- | --- |
| Targeted (public) | Mark a betting spot; anyone winning a bet on that exact spot receives 50% less payout this round. |
| Profit Cut (public) | Reduce all players' winning payouts by 30% this round. |
| Parking Tax (public) | Mark a betting spot; anyone winning a bet on that exact spot pays 10% of that bet's profit to the card's owner this round, subject to the combined tax cap. |
| Cross out (public) | Mark a betting spot and disable betting on that spot for the round. |

##### Permanent cards

###### Beneficial effects

| Working name | Current effect |
| --- | --- |
| Profit up, held rounds | Gain +2.5% winning payout per round held, capped at +30%. Maximum one copy. |
| Profit up, rounds played | Gain +2.5% winning payout per match round played, capped at +25%. Maximum one copy. |
| Third times the charm | Every third betting round covers stakes up to 20% of your cash at Betting start for free. Each additional copy adds 20 percentage points of coverage. You may bet more using your cash; excess stakes remain paid. |
| More cards | Rare. One copy gives a random extra card every other round; two copies give one every round. Maximum two copies. The extra card can be temporary or permanent; permanent selection has one-sixth the temporary selection weight. |
| More choices | Rare. Add reward choices every other round with one copy, or every round when maxed. Each copy adds one choice in Rewards only, not choices from active cards. Maximum two copies. |
| More the merrier | One copy allows an extra public temporary-card play, then has a one-round cooldown. A second copy removes the cooldown; maximum two copies. |
| Specialist | After Shop, immediately choose a required betting slot for each acquired copy; gain +15% winning payout there. Copies may target different slots or stack additively on the same slot. |
| Negative to Positive (rare) | Suppress negative temporary and permanent effects while owned; gain +1% winning payout per negative card owned, capped at +30%. Maximum one copy. Does not undo resolved effects. Exempt from Type Reversal. |
| Split Decision | Split bets gain +12.5% winning payout. Maximum one copy. |
| Street Hustle | Street, corner, and six-line bets gain +10% winning payout. Maximum one copy. |
| Clean Slate | Removing a currently negative card with Discard or a trade adds +1.5% winning payout, capped at +15%. Sales do not count. Maximum one copy. |
| Good Standing | Each round you manually repay debt adds +1% winning payout, capped at +10%. Only once per round. Maximum one copy. |
| Publicity | Gain +2.5% personal winning payout per public card you play this round, capped at +7.5%. Maximum one copy. |
| Reseller | During Shop, sell currently positive, neutral, or risky cards for 50% of their estimated normal shop price. Negative cards cannot be sold. Maximum one copy. |
| Shopping Spree | Each successful shop purchase while owned adds +0.5% winning payout, capped at +25%. Buying this card counts. Maximum one copy. |
| Patient Investor | Each round with no shop purchases adds +2.5% winning payout, up to +15%. Buying pauses growth without resetting it. Maximum one copy. |
| Against the Crowd | Gain +20% payout on winning bets on spots no other betting participant used this round. Check all other placed bets, including stacked bets. Maximum two copies; bonuses add. |
| Debt-Free Dividend | Gain +10% winning payout while no debt is outstanding. Maximum two copies; bonuses add. |
| Cashback | Recover 20% of each lost paid stake. Copies add, capped at returning that stake. |
| Gap Closer | Gain +0.5% winning payout for every complete 2% remaining to the goal. |
| Final Sprint | Gain +0.5% winning payout for every complete 2% of progress toward the goal. |
| MinMax | Multiply positive payout bonuses from cards by 1.05 per copy. |
| Cheapskate | Shop cards cost 10% less. |
| TAX | Each copy transfers 2.5% of other players' qualifying betting profit to you. Maximum four copies per owner. Triggers on a player's combined net betting profit for the round at the 10%-of-goal threshold: 100,000 for a 1,000,000 goal. |

###### Risky effects

| Working name | Current effect |
| --- | --- |
| Type Reversal | Negative and positive card effects swap. Newly positive temporary cards can be held and played in their allowed stage; newly negative temporary cards activate at their stated timing and then discard. Each copy flips positive and negative effects and grants +10% winning payout, capped at +50%. Neutral/risky cards and Negative to Positive are exempt. Preserve original values, accumulated state, and already-played effects. Normal rarity. |

Type Reversal keeps each card's own numerical magnitudes and changes the
direction of its effect. For example, a -25% effect becomes +25%, while a +15%
effect becomes -15%. Preserve that card's caps, scaling amounts, conditions,
and duration; do not replace it with a different card's opposite effect or
values. Neutral and risky cards are unaffected. Already-played effects keep
their committed behavior. Utility effects without a numerical sign use the explicit mappings below.

Negative to Positive is exempt from Type Reversal: it stays positive, retains
its suppression ability, and keeps its +1% payout bonus per currently
negative card owned, capped at +30%. Determine other cards' current polarity
after reversal before applying suppression or counting that bonus. Previously
resolved effects are unchanged.

###### Negative effects on the owner

| Working name | Current effect |
| --- | --- |
| House Cut | Your winning bets receive 10% less payout. |
| Expensive Taste | Shop cards cost 15% more. |
| Bad Credit | New loans add 40% debt instead of the normal 25%. |
| Leaky Pockets | Lose 1% of your available cash after each round. |
| Dead Weight | Receive one fewer reward choice, with a minimum of one. |
| Loan Dependency | Receive 15% less winning payout while debt-free. |
| Maintenance Fee | After each round, pay 5% of your current total for each permanent card you own, capped at 50% of your current total. |
| Storage Fee | After each round, pay 0.5% of current cash per temporary/public card held per copy, capped at 5% of cash in total. |
| Compound Interest | After each round, outstanding debt increases by 1% per copy. Includes penalty debt; cash is unchanged. |
| Repeat Offender | Winning bets on exact betting spots also used in the previous round receive 10% less payout per copy. An abstained round clears the previous spots. |

###### Card interaction notes

There is no cap on the number of negative cards a player can own. Players
usually choose which cards they receive, so no separate ownership limit applies.

Discard, Trade up, and Roll down work during Rewards, Shop, Public Effects,
Betting, and Final Preparations. They cannot be used during Card Theft, Rolling,
or Results. This lets players remove negative cards before their penalties
resolve without spending cards to dodge a steal or changing passive ownership
after the wheel reveals its result. Trade up may trade away a negative temporary
card; Roll down may trade away a negative permanent card. Removing a card prevents
its remaining penalties, but does not undo effects already applied.

Negative permanent cards apply their penalties while owned and remain until
removed, including by Discard. Discard removes the chosen card's ongoing effect;
it does not undo penalties already paid. Cold Streak is a negative temporary
card that expires after affecting the first winning round following acquisition.

Negative cards use the normal reward and shop pools and can also arrive through
card transfers or generators. Their stated timing determines when they apply.

The newly suggested values for Safety Net (50%), Debt Collector (10%), and
Patient Investor (+2.5% per qualifying round, capped at +15%) are provisional
starting values. Bounty gives +25%, Specialist +15%, Against the Crowd +20%,
and Debt-Free Dividend +10%; these remain adjustable for balance.
Patient Investor does not reset on purchases.
Double or nothing retains the 50/50 positive-profit gamble described above;
extra-loss or double-all-outcomes alternatives are not its current rule.

Free betting-round effects apply during Betting; More draws creates its
free wagers during Final Preparations. Free wagers cost no cash, return profit only on
a win, and return nothing on a loss: no fictitious stake is paid back, and the
free bet itself has no loss consequence. Refunds based on paid stakes have no
paid stake to refund for these bets.

The acquisition round counts for held-round growth. Debt-Free Dividend checks
outstanding debt at settlement. Acquired passives affect later eligible events
in the current round; already-settled effects are never recalculated.

Card descriptions state their play stage or passive/automatic timing. Current
total means cash unless the card explicitly refers to net balance, debt, or the
goal. Ordinary temporary plays consume one copy on commitment; paid choices
cannot be cancelled after revealing offers. Trade inputs must be owned and of
the required lifetime. Draws exclude maxed cards and offer fewer choices when
the eligible pool is smaller. More Cards uses an independent 6:1 temporary-to-
permanent type draw; it does not replace the scheduled reward.

Shared Agreement checks positive net betting profit, not whether every
individual bet won. Evaluate its condition before its own bonus. Include only
participants who placed bets, even if they are currently disconnected.
Against the Crowd also checks bets placed by other betting participants;
stacked chips do not make an occupied betting spot eligible.

Double or nothing may be activated once per player per round. Further owned
copies remain available in later rounds.

More the Merrier adds one public play. Spending that extra play starts its
one-round cooldown; two copies remove the cooldown. More Cards and More Choices
activate every second round after acquisition with one copy, every round with
two. Their acquisition round does not count as the first alternating trigger.

Storage Fee counts held temporary and public cards after settlement; its cash
rate adds across copies up to 5% overall. Compound Interest then changes debt
by 1% per copy after fees, before the winner check. Its reversed form clears
that much debt instead, never granting cash; changes use whole-money floors.
Repeat Offender uses exact spots from the immediately previous settled round,
including free wagers. Abstaining clears that history, which is tracked even
before the card is acquired. Reversal turns its reduction into the same bonus.

Bad Deal is consumed when its next eligible Shop begins. Its discount change
persists for that Shop, including rerolls, even if reversal changes afterward.
Each copy halves the discount again with a minimum of 1%; reserved prices remain
locked. A reversed copy is held and played during Shop, increasing discounts by
50% of their current value, rounded down and capped at 100%. It affects current
stock and rerolls, without changing other players' shops. Normal minimum-price
rounding still applies. Suppression postpones unresolved Bad Deal penalties.

#### Approved Type Reversal utility mappings

These reversals keep each original card's own quantities and timing. They do
not substitute another catalogue card's values. These mappings are implemented.

| Original card | Approved reversed effect |
| --- | --- |
| More draws | Place two forced paid bets, each worth 5% of current cash, instead of two free bets. |
| Random temp card | Lose two random temporary cards. |
| Random permanent card | Lose one random permanent card. |
| Quick Sale | Automatically sell one random available other card, including a negative card, and receive 50% of its estimated normal shop price. |
| On Hold | Block one random offer in the next Shop only. Current offers stay unchanged. |
| Reseller | Selling costs 50% of estimated normal shop price instead of paying cash; currently negative cards remain ineligible. |
| Bad Deal | During Shop, increase the deal discount by 50% of its current value, rounded down and capped at 100%; it lasts through that Shop's rerolls. Reserved prices remain locked. |
| Shop Reroll | Automatically reroll the applicable shop once and consume this card, even if the new offers are not worse. |
| Reward Reroll | Automatically reroll the applicable reward choices once and consume this card, even if the new choices are not worse. |
| Go Fish | During Card Theft, choose another player and blindly select one temporary card to steal from their hand. |
| Pickpocket | During Card Theft, steal one random temporary card from another player's hand. |
| Sticky Fingers | During Card Theft, privately reveal two random temporary cards from another player's hand and steal one. |
| Double Choice | During Card Theft, steal one random temporary card from each of two random players. |
| Interception | During Card Theft, choose another player. At their next reward draft, take the first temporary card they select instead of them. The effect expires after that draft, even if no temporary card was selected. |
| Reclaim | During Card Theft, recover a card stolen from you if it is still a temporary card in its current owner's hand. |
| Cold Streak | Gain 30% payout on the first winning round after activation, then expire. |
| Shop Closure | Refresh the current round's personal shop once when played during Shop. |
| Cross out | Free Entry: every participant gets one free straight-up bet on the marked number at Betting entry, worth 5% of their current cash. |
| Forced Sale | Choose one temporary card to gain from three offers. |

Short Changed reduces winning-bet payout by 20% during the next round only,
then expires even if no bet wins or the player abstains. The reversed version
gives +20% winning-bet payout during that same next-round window and expires
afterward regardless of wins. It does not reduce losing stakes.

For every reversed theft or interception that gives another player a card,
show the recipient which player it came from and which reversed card caused
the transfer, for example: "Alex's reversed Go Fish gave you a card."
Also explain the transfer to the source player. Keep card identities private
to entitled viewers; this feedback must not expose either player's remaining
hand. This cause-specific feedback is required even though ordinary personal
card plays do not produce a public alert.

Flipping a card preserves its accumulated state. A held-round payout bonus
that has reached +15% becomes -15%, not its original -2.5% starting value.
Acquisition round, accumulated growth, counters, cooldowns, assignments, and
other card-specific memory are retained through each reversal. Flipping back
restores the corresponding positive direction without restarting progression.

Reversed Cross out is Free Entry: when Betting opens, every participant gets
one free straight-up bet on the marked number worth 5% of their current cash.
It pays profit only on a win and loses nothing on a loss. Reversed Forced Sale
grants a choice of one temporary card from three offers. Its source is consumed
before revealing the required choice, preventing free rerolls by cancellation.

#### Round settlement order

After the roulette outcome is known, resolve the round in this order:

1. Additive winning-payout bonuses and reductions (including returned paid stakes).
2. Explicit multiplicative effects.
3. Profit gambles such as Double or nothing.
4. Taxes.
5. Debt changes, including winning-condition repayment.
6. Winner check.

Cap payout reduction at 80%: modifiers cannot leave less than 20% of the base
winning payout at the payout-modifier stage. This is not a guarantee against
later tax, a failed profit gamble, or an ordinary losing bet. Monetary results
use the whole-number floor rule, so rounding can produce less than an exact
20% payout on very small amounts. Specific refund and conditional-card timing
must fit this order without introducing circular calculations.

#### Copy limits, betting-round counts, and public stacking

Permanent copy rules are specified per card above. The two scaling Profit up
cards and Patient Investor allow one copy each. More cards, More the merrier,
Against the Crowd, and Debt-Free Dividend allow two. TAX allows four. Specialist
can stack on the same slot or apply to different slots. Third times the charm
increases its free-round limit by 20 percentage points per copy. More choices
allows at most two copies and only affects the scheduled Rewards stage.

Third times the charm counts betting rounds, not individual bet placements.
All bets placed in one round count as one combined bet. After betting in two
rounds, the next betting round is free, subject to the combined free-stake cap.
Abstaining does not advance the count; editing or splitting a bet cannot advance
it multiple times. This changes the card's original "every third placed bet"
wording.

Third Times the Charm snapshots cash when Betting opens and caps free coverage
at 100% across copies. Only betting rounds with paid input while the card is
owned advance its counter; abstention and card-created free wagers do not.
Coverage is applied when Betting closes. Wagers above coverage remain paid.

Profit Bonus (+15%) and Profit Cut (-30%) combine additively; Bounty (+25%)
and Targeted (-50%) combine on the same spot. Equal copies no longer cancel.
Cap the combined payout reduction at 80%, leaving 20% of the base winning
payout before later taxes or gambles. A reduced winning payout can be less
than the paid stake, producing a net loss despite a matching roulette result.

White Out removes all status effects attached to its target spot, including
buffs, debuffs, Parking Tax, and Cross out. Erase removes one attached status
effect at random, which may be positive or negative. Neither removes a global
effect that is not attached to that spot.

Public plays resolve in server acceptance order, serialized by the shared animation hold. Removal, relocation, copy, and reversal reject an ineligible or empty target without consuming the source card.

Parking Tax and TAX transfer profit earned from bets in the round, not returned
stakes or tax income. TAX's threshold is 10% of the goal; a 1,000,000 goal
therefore means a 100,000 threshold. Check the player's combined net betting
profit across the round, rather than testing each winning bet separately.
Calculate all tax claims from the same pre-tax betting profit after bonuses,
multipliers, and profit gambles. Never tax incoming tax transfers or returned
stakes. Total tax collected from one player, including TAX and Parking Tax,
cannot exceed 50% of that player's qualifying round betting profit.

For nonnegative pre-tax qualifying profit P, set the whole-unit cap to
floor(P / 2). A player with zero or negative net betting profit has a zero
round-profit tax cap.
Calculate each claim using its stated rate and eligible profit, rounding down.
If their sum S exceeds the cap C, reduce each claim proportionally to
floor(claim * C / S). Do not redistribute leftover rounding units: they remain
with the payer, so actual collection may be slightly below the cap.

Determine all claims before moving money. After applying each payer's cap and
rounding each claim, cancel opposing player-to-player obligations so only their
net difference is transferred. This does not change the underlying tax claims
or add another tax event.

Exactly meeting the TAX threshold triggers it.

Card generators and enabling cards should be rare to make generation loops
resource-intensive. More cards and More choices are explicitly rare; existing
rare generators retain that status. Do not add a hard generation-chain limit
for now. More choices never enlarges choices from active generator/trade cards.

[Review remaining generator/enabler rarity, including Trade up and Roll down.]

Cross out blocks its space even if Bounty or Targeted is also present; decide
whether useless overlapping placements are allowed. Other card interactions
must use the confirmed settlement order above.

The general intention of stronger late-game scaling remains, but the proposed
held-round +60% and match-round +50% caps are the current concrete card ideas;
there is no universal requirement that every match-round cap exceed every
held-round cap.

#### Hybrid personal shops

Each player has a separate shop; buying does not consume another player's stock.
The selection combines shared temporary and permanent cards with random personal
temporary and permanent offers. Everyone receives seven offers: five temporary
cards and two permanent cards. Refresh every round. Personal shop contents are
private to their owner.

Group personal randomized offers at the top and shared offers at the bottom.
Within each group, place permanent cards to the right of temporary cards.
Keep these groupings clear when adapting the shop to narrow screens.

Temporary cards use silver frames; permanent cards use gold styling. Public
temporary cards use a silver border with a muted purple interior, retaining
the temporary-card frame while making their public scope easy to recognize.
Use high-contrast text and an explicit Public badge so identification does not
depend on color alone. Apply this card styling consistently in shops, reward
choices, and hands.

The shared/random split means how many offer slots show the same card selection
to every player, versus individually randomized cards. Shared offers are not
shared stock: another player's purchase cannot remove your copy. Use this split:

| Type | Shared offers | Personal random offers |
| --- | --- | --- |
| Temporary | 3 | 2 |
| Permanent | 1 | 1 |

Shared selections are identical across players, but inventories and purchases
remain independent. Personal random offers are chosen individually.

Card pricing uses the configured starting cash and goal plus the average net
balance of current contenders, not combined room wealth. Net balance is cash
minus outstanding debt, so borrowed principal does not artificially raise
prices. Capture the signed whole-unit average when Shop opens; clamp a negative
average to zero only when applying the formula. Include offline contenders,
but exclude spectators, departed players, and non-contenders in a tiebreaker.
All players use the same captured average for that Shop stage, including owner
rerolls. Recompute it when the next Shop stage opens.

A round adjustment would raise prices based only on round number. This remains
future balancing work, alongside card-specific price weights. Current prices
already incorporate average net balance using the formula below.

Do not apply early-round purchase restrictions for now. Fewer early offers,
purchase limits, and delayed permanent access are deferred balancing options.

A Shop Reroll replaces every offer for its owner, including originally shared
slots, without rerolling other players' shops. Shared slot positions remain in
their group even when their rerolled cards differ.

For More cards' extra reward, permanent cards have one-sixth the temporary-type
selection weight (temporary 6, permanent 1). This type roll is separate from
a card's rarity within its type. This is a type-selection draw, separate from rarity weights within that type.

A rare card has one-sixth the selection weight of a regular card of the same
type. For example, use regular weight 6 and rare weight 1, then normalize over
the eligible pool. This is relative weight, not a flat 1-in-6 rare-card chance.

Each offer can be bought once before it is replaced; show Sold out afterward.
Copies can still be purchased from other offers or later refreshes, subject to
that card's ownership cap. Show Already maxed and disable purchasing when the
player owns the maximum permitted copies. Reroll replaces all shop offers,
including sold-out slots, for that player only; replacement offers are new
purchase opportunities subject to ownership caps.

Regular card price = (4 x starting cash + 4 x max(0, average net) + goal)
x type rate x rarity multiplier / 200. Type rate is 1 for temporary/public and
3 for permanent; rare prices use a multiplier of 2. Round to the nearest unit
below 20 and nearest five otherwise, with a minimum price of 1. Deal discounts
are 25-75%. The catalogue marks each rare card explicitly.

#### Public effects and Final Preparations

Before betting, players can apply stronger public buffs or debuffs to betting
spaces. Start with a limit of two public-effect cards per player per round. This
is a base play limit, not a two-card hand limit: cards can be saved for later.
More the merrier can grant an extra public temporary-card play when not on
cooldown. Show final public modifiers before betting opens.

After betting closes, allow weaker personal card effects in the Final
Preparations substage. These are not unrestricted attacks on other players'
committed bets. Bet positions and stakes remain fixed during this substage.

Explain board effects with symbols, readable descriptions, and a symbol
reference.

Effects use card-specific durations. Ordinary percentage bonuses combine
additively; explicit multiplier effects follow their own text. Payout reductions
are capped at 80%, retaining at least 20% of the base winning payout before
separately resolved taxes. Apply additive modifiers before explicit multipliers, as
specified in Round settlement order.

Global public cards such as Profit Bonus and Profit Cut affect their owner as
well as the other players. Payout modifiers include the returned paid stake
and combine additively. Cross out disables a betting space, not the roulette
pocket: that number may still roll and pay other legal covering bets. It is
placed before Betting, so no existing paid bet needs to be cancelled.

Any number of personal cards can be played during Final Preparations, allowing
players to stack effects. A personal-card limit is only a later balancing option.

Public cards resolve in server acceptance order. Their shared animation holds
the stage timer and serializes placement; rejected overlapping plays consume
nothing. Normal Cross out can disable any exact betting spot. Bounty, Targeted,
and Parking Tax also accept any exact spot; Crowd Favorite, Lone Wolf, and
reversed Cross out remain number-only.

### Late-entry assistance

Late players receive the host-configured late-player starting money, defaulting
to the same starting-money setting as original players unless overridden.

Calculate the temporary and permanent rewards already offered at the entry
round separately. Divide each count by two and round up. Each granted card has
two choices rather than three; all cards are eligible within its reward type.
Temporary cards are part of this grant, not a separate unlimited bonus.

For round r, the scheduled counts through that round are:

- Permanent: floor((r - 1) / 3).
- Temporary: max(0, r - 1) minus the permanent count.
- Catch-up grant: ceil(temporary / 2) and ceil(permanent / 2).

At round 4 this gives one temporary and one permanent card. At round 7 this
gives two temporary and one permanent card. Three missed permanent rewards give
two permanent choices after halving and rounding up. Counts can be derived
from the round rather than stored as separate cumulative counters.

**Entry accounting:** The grant includes the entry round's reward
and replaces its normal draft for that newcomer, avoiding a duplicate reward.
Returning players retain existing state; they never receive fresh entry money.
Their missed-reward assistance is described under offline players.

### Loans

A bank or loan shark lets players borrow spendable money and acquire debt,
including when bankrupt. Net balance is cash minus outstanding debt;
borrowing itself cannot move a player closer to the winning requirement.

After full round settlement, automatically repay all debt if the player can do
so and still meet the goal. Compare qualifying net balances after repayment. Players
can also repay voluntarily during planning.

Each player can take one loan per round, during either Shop or Betting, choosing
its size up to the limit. Repayment or debt-relief cards do not reset that round's
borrowing allowance. Profit cards do not multiply borrowed money itself.

**Provisional balance values:** Maximum principal is
`floor(0.5 * starting cash + 0.25 * max(0, average participant net balance))`.
Capture the shared cap at each round start, after admitting late players. Include
offline contenders and exclude departed players, spectators and tiebreaker
outsiders. Loans, purchases, repayment and card plays cannot change it mid-round.
For 100,000 starting cash, an average net of 100,000 allows 75,000; an average
net of 400,000 allows 150,000. It does not depend on the goal. A loan
adds debt equal to its principal plus a one-time 25% surcharge: borrowing 100
creates 125 debt. This does not imply recurring interest. Show terms before
confirmation.

Existing unpaid debt does not block the next round's loan: borrowing is intended
to keep players able to bet. The round's shared cap limits an individual loan, not
total outstanding debt. Players may abstain, and an empty balance does not
eliminate them. Spending a loan before Betting can exhaust that round's funds;
that player can abstain and borrow again next round, not take a second loan.

Loan amounts and debt use whole units; percentage calculations round down.

### Future special wheel slots

Begin with ordinary default roulette slots. Keep slot definitions and the
matching spinner presentation changeable so slots can be added or replaced
later. Bankruptcy, double-money, and gifting slots remain future ideas without
committed gameplay rules.

### Winning, losing, and elimination

Check the goal only after the entire round has settled. If one player's net
balance reaches or exceeds it, that player wins. If several qualify, compare
their net balances (cash minus outstanding debt); the highest wins,
regardless of which payout appeared first.

If several players share the highest qualifying net balance exactly, another round
starts with only those players participating. Keep awarding cards on the same
round schedule and refreshing shops for those tied players until the tie ends.
Non-tied players cannot draft, shop, bet, or play cards in these extra rounds.
Continue the tiebreaker if they remain tied. After showing the result, return
players to the lobby, where the host can change settings and start another match.

A lost bet does not by itself eliminate a player. A player with no money cannot
place a positive-money bet but may borrow under the loan rules.

A round with no bets still proceeds. Loans become available again next round;
there is no forced bankruptcy elimination or automatic wager.

Once a tiebreaker begins, the player with the highest settled net balance wins when
the tie breaks, even if all tied players have fallen below the original goal.
Continue comparing money after accounting for outstanding debt, as in the
normal winning rule; the goal no longer has to be met again.

### Example of play

For illustration, suppose neither player has debt or active card effects, the
goal is 500, and a winning paid bet returns 40 in total
for a stake of 20. These example amounts do not establish the final payout
table.

Alex begins a round with 480 and Sam with 490. Both place a 20-money bet that
wins on the shared spin. Alex's balance becomes 480 - 20 + 40 = 500; Sam's
becomes 490 - 20 + 40 = 510. Both reach the goal in the same round, so Sam wins
with the higher net balance (cash minus debt; neither player has debt here). Alex does not win merely because their payout
was shown first.

If both instead finish on exactly 500, they enter the tiebreaker. Other players
do not place bets in those extra rounds.

## Hidden information and spectators

Player identities, assigned chip colors, bet positions, and bet amounts are
public, matching the intention that players can see what everyone is betting.
The phase, remaining planning time, revealed result, and settled balances should
also be clear to everyone.

Each player's hand and personal shop are visible only to that player. When a
Final Preparations card is played, everyone sees who used it and which card was
used. That reveal does not expose the rest of the hand or shop. The upcoming
roulette result stays hidden until the roll reveals it; personal display
choices must not reveal the outcome early.

Spectators can watch public bets, spins, and standings, but cannot place bets,
ready up, or affect outcomes while spectating. Late joiners initially spectate.
When the host allows late participation, eligible spectators are automatically
moved into play at the next normal planning stage with the configured
late-player balance and entry-card assistance. They do not need to wait for a
new match or take a separate join action. If the host does not allow it, they
remain spectators.

Every spectator already occupies one of the room's 12 places. Moving them into
play changes their role without adding another room member. A room with 12
players is full and cannot also contain additional spectators. The total of
players and spectators must never exceed 12.

Non-participating players can continue watching a tiebreaker, but spectators
cannot enter its betting rounds. A returning participant resumes their existing
match balance, debt, and cards; leaving and rejoining must not grant fresh
starting money or repeat entry-card assistance.

Private hands and personal shops must also remain hidden from spectators.

Inventories and passive ownership remain private. Public bets, balances and
confirmed card plays are visible; private choices and theft receipts are shown
only to the entitled participants.

## Settings reference

Shared betting rules are chosen before starting a match. Changes should affect
the next match rather than changing the goal or stakes during an ongoing race.
Permission to admit spectators into later rounds is a separate host control.

### Setting: Starting money

Every player receives this amount at the start of the match. It determines the
initial betting budget and how much risk players can take early on.

The host chooses this amount. Use a provisional default of 100,000 until testing.

Starting cash ranges from 1,000 to 200,000 in steps of 1,000.

### Setting: Late-player starting money

Default to the match's starting money, initially 100,000. The host can override
this balance for late players.

The late-entry setting ranges from 0 to 200,000 in steps of 1,000; 0 inherits
starting cash. Settings are captured when the match starts and do not change
existing participants' cash.

### Setting: Money goal

This is the balance players must reach or exceed after a settled round to
qualify for winning after outstanding debt is repaid. Its relationship to the
starting balance, card effects, shop prices, and payouts affects game length.

The host chooses the goal. Use a provisional default of 1,000,000 until testing.

The goal ranges from 100,000 to 2,000,000 in steps of 1,000. It can be at or
below starting cash; winner checks still occur after a settled round.

### Setting: Planning time

Every planning substage has its own timer and reversible Ready up control.
Use 30 seconds for Rewards, Shop, Card Theft, Public Effects, and Final
Preparations, and 60 seconds for Betting. All-ready can end an input substage
early. Round 1 skips card-related substages because no cards are in use yet.
Rolling lasts as long as its wheel animation; it has no player readiness button.

If a connected player times out without choosing a reward, randomly select one
of their offered cards. If disconnected at timeout, award no card automatically.
This applies to reward selection, not automatic shop purchases or card plays.

Phase durations are fixed, not host settings. Rewards ends when its drafts and
required choices finish; otherwise all queued drafts share its 30-second window.
Shop, Card Theft, Public Effects and Final Preparations remain available even without useful
actions and can end by readiness. Rolling lasts six seconds and Results five.

### Host control: Allow late participation

The host decides whether eligible spectators automatically enter the next normal
round. Enabling permission does not interrupt the current planning or rolling
stage, change existing bets, or let anyone enter a tiebreaker. Without
permission, spectators keep watching. The shared 12-person room limit still
applies.

Next-round joining is enabled by default as a match-start game setting.

### Personal preferences and presets

Rule configurations can use GameHub's browser-local presets. This game does not
need its own separate preset system.

Personal presentation options must preserve roulette outcome colors and keep
players' assigned chips identifiable.

Loaded Roulette has browser-local dropdowns for Table detail (Textured/Simple),
Card detail (Detailed/Simple), Chip detail (3D stacks/Flat chips), Wheel effects
(Full/Reduced), and Target spotlight (Fade and gold highlights/Gold highlights
only). Defaults keep full detail. Reduced wheel effects remove the launch hand
and result zoom, while preserving wheel/ball motion and reveal timing. Simplified
cards keep lifetime/category colors and readable effects. Flat chips keep owner
colors and exact wager amounts. Disabling the spotlight removes its dimming mask,
not the gold target highlights or selection controls. These choices affect only
presentation, apply live, and do not change any gameplay rules.

GameHub provides saved audio, graphics and keybind preferences. Card lifetimes,
player colors and roulette outcome colors retain their gameplay meaning.

## Offline players and host ownership

Every disconnect pauses the game for 60 seconds, then play continues unless
the host has manually paused. The host can resume earlier or kick a player who
repeatedly causes pauses. No repeat-disconnect exemption is planned for now. Preserve money,
debt, cards, borrowing allowance, and accepted actions: already spent actions
resolve as though the player were present. Missed actions have no effect; do
not invent bets, purchases, or card plays for an absent player.

Players can reconnect whenever their existing player remains in the lobby or
game. Restore their state and current substage without new starting money or
repeating rewards already received. The existing round borrowing allowance
remains unchanged.

Absent players do not automatically choose rewards and may miss cards.
On return to the same match, keep existing possessions and offer half the
temporary and permanent rewards they could have received while absent, rounding
each type up as for late entry. Track their absent round interval
or missed reward rounds; count only rewards they actually missed, not every
reward since the match began. Repeated reconnects must not claim the same
missed rewards twice.

Returning-player assistance opens at the next normal reward stage with two
choices per card. Only missed normal scheduled rewards count; missed More Cards
bonuses do not. Temporary and permanent missed counts are halved and rounded up
separately. Assistance and the current normal draft share the 30-second window.
Connected players get random choices for all remaining drafts at timeout.
Disconnected players get no automatic choices; unchosen assistance carries forward
until a connected reward stage. Already granted rewards are never counted again.

Each new disconnect resets the automatic disconnect countdown to the full
60 seconds, including overlapping disconnects. The alert names the player who
disconnected. The host can resume or kick repeat disconnectors.

Resume immediately when the disconnected player reconnects, without waiting
for the automatic countdown to finish, unless a manual host pause remains.

Early automatic resume waits until all currently missing participants return.
The host can resume earlier. A manual pause remains in force independently.

The host should be able to pause or resume. A manual pause should stop phase
progression and preserve the remaining time and accepted bets. A host change
should transfer these controls without resetting the round, bets, or balances.
If the host permanently leaves, transfer room ownership to another eligible
remaining player. This refers to host ownership, not automatic transfer of the
departed player's cards, money, or bets.

An automatic disconnect-pause deadline must not undo a manual host pause.

Permanently leaving or being removed removes the participant from the game;
temporary disconnection leaves them present but without automatic actions.

End the game and award an automatic win when permanent departures or removals
leave only one participant. This does not require reaching the money goal.
Keep the 2-12 starting requirement; solo continuation is only a future option.
A temporary disconnect does not remove a participant or trigger this ending.

After permanent departure, retain actions and effects already applied, including
public board modifiers for their remaining duration. Do not execute future
actions or future triggers belonging to the departed player. An action already
spent is distinct from a new passive trigger scheduled for a later event.

Already-placed bets still settle if their owner permanently leaves; departure
does not cancel those committed bets. The departed player is no longer eligible
to win. If no participants remain, close the game without a winner.

Committed wagers settle into the departed owner's retained ledger, not another
player's account. If a spin is already underway, finish settlement before
awarding the last participant a win. With no participants remaining, close
immediately without a winner.

## Room scoreboard and social panel

Current-match standings use each player's net balance (cash minus outstanding debt). The player's
own display should also show how much is available and how much is currently
committed to bets, so a temporary reservation is not confused with a settled
loss.

For deciding a winner, compare net balances after the entire round settles.
Display cash, outstanding debt, net balance, and available cash distinctly.
Equal net balances remain equal; a display ordering must not break a gameplay tie.

The scoreboard columns are Bets won, Money gained, Money spent, Cards played,
and Biggest bet win, in that order, followed by Ping. Match wins are not tracked. It updates during the match, survives reconnects, and resets
when the next game starts. No manual reset is available. Money gained excludes
starting cash and loans; money spent includes paid stakes, purchases, repayments,
fees and deductions. Cancelled bet reservations are excluded.

A bottom-right Scoreboard button and the general Tab shortcut open its modal.
Ping/status appears in the rightmost column. Chat and spectators use the side
panel independently of the scoreboard.

GameHub supplies chat and spectator controls. Roulette does not introduce a
separate chat channel or expose private card choices through public messages.

## Layout and controls

### Board and player areas

Use a different main board for each stage, switching automatically with the
round rather than showing both boards side by side.

During planning, use the classic roulette betting board for public effects,
betting, and Final Preparations. Rewards and Shop need card-choice and purchase
views within planning; these must not imply that betting is already open.
Players place their colored chips on the board during Betting. Bets need clear
ownership, amounts, and enough separation to inspect crowded spaces. Show names
or other identifying markers alongside colors so ownership does not depend on
color alone. The exact spaces must match the chosen wheel and bet rules.

During rolling, replace that board with the roulette spinner centered in the
playing area. List color-coded players around the board, or in groups above and
below the wheel depending on available space. Pair colors with names or labels.
Animate the wheel
rotating and the ball moving until it settles into the result slot. Betting
controls are unavailable during this stage. Keep a summary of committed bets and
balances available so players can follow what the spin means for them.

Keep the local player's money and committed total in consistent locations across
both stages. During planning, group the chosen stake, timer, and readiness control
near the betting board. Show the phase and round result clearly. Other players'
balances and readiness states should not make the active board too small to use.
If the match continues after settlement, restore the betting board for the next
planning stage.

A target shows up to three owner-colored stacks, with the viewer's own first;
extra owners are counted. Exact amounts and owners remain in All table bets.
Select an owned stack to edit it during Betting.

### Buttons and keybinds

**Controls:** Select a stake amount, choose a bet space, edit or
remove an unlocked bet, and use **Ready up**. Show a round payout summary after
the roll. There is no player-controlled button that chooses the roulette result.

Disable betting changes outside the betting substage and while paused. During a
tiebreaker, only its participating players get gameplay controls. Show card
selection, purchases, public placement, personal card use, borrowing, and
repayment controls only in their permitted windows. Explain rejected inputs
without clearing other accepted bets.

Touch users should be able to choose an amount and tap a space. Keyboard users
should be able to reach the same controls with clear focus and accessible
labels.

Default shortcuts: R toggles Ready up/Cancel ready, E checks cards, B opens the
bank, F opens last results, 1-5 select preset chips, and 6 selects Max. GameHub
provides Tab to toggle the scoreboard and configurable bindings.

### Screen sizes and accessibility

Give the active stage's board the available playing space: the betting layout
during planning and the spinner during rolling. Adapt each independently to
portrait phones, landscape screens, and larger displays. Keep the money summary,
phase, timer, and primary control readable at each size. Avoid relying on hover
to inspect a bet or on color alone to identify a player or outcome.

Announce phase changes and the final round result without repeatedly announcing
every countdown update. Reduced-motion presentation should still reveal the same
outcome and use the same betting deadlines.

The table is landscape when width exceeds height and portrait otherwise; text
stays upright. The game fits the viewport. On phones, the details sidebar is a
shallow wallet tray with a centered expand tab; opening it shows the same live
controls full-screen. Desktop retains the right-hand sidebar.

### Art, animation, and audio

The transition to rolling should clearly replace the planning board with the
spinner. Animate both the rotating wheel and the ball, making the final landing
slot clear. The presentation must match the authoritative round result.

During planning, player-colored chips visibly connect placed bets to their
owners. After the roll, identify the winning bets in the result summary and show
each player's gain or loss.

**Provisional:** Use distinct sounds for placing chips, readying up, spinning,
revealing the result, and receiving payouts. Sound and animation should
reinforce the result while leaving it understandable without audio or full
motion.

Use green felt, direction-following wood rails and gold trim. The wheel has
separate number and landing rings, a brass compass and eight diamond inlays.
Music and effects are MP3 assets in separate package folders, controlled through
one Audio settings tab. The bank remains a plain modal without shark animation.

### Card and result presentation

The order is title, excess players 7-12, board/wheel, players 1-6, timer, then
chips and actions. Chips and the card fan share the wide bottom dock and stack
in portrait. The board texture stays behind cells, labels, effects and chips.

Hands group temporary, public and permanent cards, then positive, neutral,
risky and negative effects. Duplicates share one face with a count at top right;
polarity is top left, the name centered and lifetime below it. Silver temporary,
gold permanent and purple public faces have distinct subtle textures and diamond
ornaments. Category badges/glows use green, blue-gray, amber and red. Player-
colored backs use the agreed checker-to-radial design and white framing.

Only bottom-hand cards show enlarged inspection after a one-second hover/focus.
Shop and reward cards remain directly inspectable/selectable without that extra
overlay. Required reward and paid continuation choices cannot be dismissed;
confirmed reward choices close immediately. Whole cards and the separate button
below them can select rewards. The inventory stays open after instant effects
and confirms the accepted play inside it; targeting exposes the actual board.

Target choices highlight the real player cards or eligible betting spots, with
a dimmed viewport behind them. Blind theft uses a shuffled floating fan: backs
for the chooser and known faces for the hand owner. The victim sees the chosen
card leave; the recipient privately sees a back-to-front reveal of what arrived.
No spectator sees private choice identities or transfer receipts.

Every public play shows the common board-level card pop to all viewers; targeted
cards then move to their spot. The server holds the stage timer for the full
1.4-second global or 1.55-second targeted animation. Personal animations are
private and sit behind an open inventory. Reduced motion retains confirmation
and outcome without the full motion. Alternating passives notify their owner
only when they activate; constant bonuses do not repeatedly alert.

At match end, a compact gold announcement shows the winner and net balance on
the board for three seconds. Everyone returns to the lobby, where a dismissible
review shows up to three most-used cards with resolved-use counts. These counts
do not claim monetary contribution. Starting another game dismisses that review.

## Action timing and pacing

Each planning substage has its own countdown and reversible Ready up control.
It ends when every participating player is ready or the timer expires. Betting's
countdown begins only when Betting opens. Accepted bets
are then fixed for that round; an unlocked player does not gain extra planning
time.

Rolling switches the main board to the animated spinner and includes the spin,
result reveal, and complete settlement. Players wait until the betting board
returns and the next Betting substage opens before placing new bets. Check the
win condition after settlement and before opening another normal round.

Pausing preserves the remaining planning time and accepted
bets. A paused round must not silently advance or pay out while appearing
stopped. Resuming continues the same round rather than opening betting again
after it has already closed.

Several players can bet on the same space; placing a bet does not reserve that
space exclusively. A player's overlapping edits must not spend the same money
twice. Delayed, repeated, or outdated requests must not duplicate a bet, change
a closed round, or apply a payout more than once.

Rolling duration follows the wheel animation.

Rolling includes a final 750 ms stopped-wheel reveal before balances change.
Results lasts five seconds. Requests at or past the authoritative deadline
cannot reopen a closed stage; accepted request IDs make retries idempotent.

## Implementation status

The roulette game and its defined card catalogue are implemented for local
GameHub testing. Type Reversal and late-entry/returning-player assistance are
active. Physical-device audio, performance and numerical balance still need
playtesting.

### Game availability

- [x] Implement the individual roulette race for the intended 2-12 players.
- [x] Share the room's 12 places between players and spectators.
- [x] Automatically admit eligible spectators at the next normal round when the
  host allows, using configured late-player balances and entry-card assistance.
- [x] Preserve returning participants' money, debt, cards, and actions; prevent
  new late entrants from joining tiebreaker rounds. Existing tied participants
  can still reconnect.

### Existing configuration

- [x] Add host-set starting money and a money goal.
- [x] Add late-player starting-money overrides (0 inherits normal starting cash).
- [x] Implement single-zero roulette and the supported standard bets and payouts.
- [ ] Decide whether to expose planning time as a host setting.

### Server-authoritative gameplay

- [x] Implement individually timed planning substages and reversible readiness.
- [x] Implement the defined cards, reward timeout choices, and private hybrid shops.
- [x] Implement Type Reversal's numeric and approved utility effects.
- [x] Implement public effects and Final Preparations.
- [x] Implement late-player balances and entry-card assistance.
- [x] Implement one variable-size loan per round in Shop or Betting, repayments,
  debt-relief cards, and debt-aware win comparisons.
- [x] Validate and account for accepted bets without overspending.
- [x] Resolve a shared spin and settle every bet once.
- [x] Check the goal after settlement and support tied-player extra rounds.
- [x] Implement 60-second pauses on all disconnects and restore accepted actions.
- [x] Implement continued loan access, abstention, and permanent removal.
- [x] Award an automatic win when one participant remains after permanent departures.
- [x] Reset overlapping disconnect pauses to 60 seconds and name the disconnected player.
- [x] Preserve applied departure effects and settle committed bets; suppress new triggers.
- [x] Resume on reconnect, transfer departing-host ownership, and close empty games.

### Client gameplay

- [x] Show personal offers above shared offers, with permanent cards to the
  right of temporary cards; retain the five-temporary/two-permanent offer split.
- [x] Style temporary cards silver, permanent cards gold, and public temporary
  cards with silver borders, muted purple interiors, and Public badges.
- [x] Show money, committed bets, readiness, phase, timer, and results.
- [x] Provide usable betting and readiness controls with keyboard and touch access.
- [x] Provide card drafts, shop purchases, public placement, and Final Preparations.
- [x] Show card-specific values, loans, debt, and repayment controls.
- [x] Hide other hands and shops; show used cards in played-card history; alert only for public card plays.
- [x] Show public standings and the chosen spectator/social features.

### Table presentation

- [x] Show the classic roulette betting board during planning.
- [x] Switch to a rotating roulette wheel and animated ball during rolling.
- [x] Adapt each stage's board for phones and desktops without requiring both
  boards to share the playing space.
- [x] Identify players' bets using colors and additional labels or markers.
- [ ] Present spins and payouts with accessible motion and sound alternatives.

## Open questions and later additions

Balance remains subject to playtesting: card values/caps, the two-card public
limit, shop pricing and the effect on match length. The implemented timing,
refund, catch-up and departure rules above are current decisions, not unanswered
prompts. Optional configurable timers and empty-stage skipping remain future
choices rather than requirements of the current build.

### Deferred possibilities

Keep these ideas documented for later consideration; none is an initial rule:

- Protective Seal (temporary, public): protect one spot from further public
  effects for the round. If added, use an opening protection-placement step
  within Public Effects, before other public cards can be placed;
  its usefulness must not depend on who sends their ordinary placement first.
  Its protection-step timing and interaction rules remain undecided.

- Special wheel slots such as bankruptcy, double money, or gifting, with editable
  slot definitions and matching spinner animation.
- Early-round offer or purchase limits and delayed permanent-card access.
- A personal-card play limit in Final Preparations, if unrestricted stacking
  proves too strong; no such limit is applied initially.
- Reduce the base public-card play limit from two to one per player per round
  if balancing calls for it. Keep two as the current rule; More the merrier
  adds its extra play to whichever base limit is in use.
- Debt-relief card use throughout planning instead of only Final Preparations.
- A catch-up card budget as an alternative to the reduced draft.
- Milestone-based late-entry grants as an alternative allocation method.
- Shared-stock shops, auctions, or entirely shared/random selections instead of
  hybrid personal shops.
- High Stakes (temporary, public): mark a betting group before Betting. Proposed
  values give +25% profit on wins and cost 25% extra stake on losses. Keep this
  card deferred; any future version uses the general overflow-to-penalty-debt
  rule rather than requiring an extra-loss cash reserve.
- Alternative Double or nothing mechanics: an all-bets-must-win condition, a
  called-color condition, or a two-round streak. The chosen version stays the
  50/50 profit gamble. Double Everything is a separate implemented card above.
- A monetary contribution/synergy analysis beyond the current most-used-card review.
- Solo play as a possible later expansion; the current game ends with one participant.

Additional card effects, conflict rules, and pricing are deferred design work for
confirmed systems, rather than reasons to omit those systems.

The intended game includes the two-stage round loop and planning substages,
public colored bets, card rewards, hybrid shops, public and personal effects,
loans, limited late-entry assistance, consistent money accounting, a defined
wheel and payouts, debt-aware winning, and tiebreakers. A smaller prototype may
validate the core loop first; that does not remove the confirmed systems.
Measure match length through play; up to about 40 minutes is acceptable.

Playtest card synergies, prices and numerical balance together.

## Playtest questions

- **Do late-round cards help matches finish?** Check scaling without making
  earlier choices irrelevant.
- **Does the economy resist exploits?** Test loans, shop pricing, entry rewards,
  stake refunds, and loss protection together.
- **Does planning remain engaging with 12 players?** Measure waiting across
  substages and whether Final Preparations preserves meaningful betting choices.

- **Does planning feel useful?** Players should understand their choices and
  have enough time to make them without excessive waiting once ready.
- **Is the rolling stage exciting and readable?** Players should follow the ball,
  recognize winning bets, and understand their final gain or loss.
- **Do players who fall behind still see a route to winning?** Test whether cards
  and loans provide worthwhile choices without guaranteeing recovery.
- **Does the money goal create the intended match length?** Compare different
  player counts, starting balances, goals, and bet payouts.
- **Do ties resolve without dragging?** Extra rounds should remain engaging for
  the tied players and understandable to everyone watching.
- **Does late entry stay exciting and fair enough for this game?** Newcomers
  should have a chance through a risky bet without repeated entry providing
  fresh money to an existing participant. Check whether waiting for the next
  planning stage and the host's admission control are clear.
- **Can 12 players' bets be read on a phone?** Shared spaces and stacked chips
  should not hide ownership, amounts, or essential controls.
- **Do players understand the result?** They should distinguish returned stakes,
  winnings, losses, and why one qualifying player beat another.
