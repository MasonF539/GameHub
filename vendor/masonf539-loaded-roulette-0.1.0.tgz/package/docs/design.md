# Loaded Roulette Design

Loaded Roulette is a roulette-based game for GameHub. Players plan bets at the same
time, watch a shared roulette spin, and race to reach a money goal.

This is a working basis for the game, with later modifications expected.
Unmarked rules develop the concept already described. Details labelled
**Provisional** are suggested starting points rather than settled decisions.
Square-bracketed prompts identify information still to choose; replace each
whole prompt, including its brackets, when that decision is made.

Technical decisions and implementation details belong in the [implementation
notes](implementation.md).

## Game overview

Each round has a planning stage and a rolling stage. Planning contains Rewards,
Shop, Public Buff/Debuff Placement, Betting, and Final Preparations. Players
build their card collections, buy cards, modify betting spaces, place bets, and
use weaker personal effects before a shared roulette spin resolves everyone's
bets. Winning paid bets return stakes plus winnings; losing paid bets lose their
stakes. Free bets return profit only and cost nothing on a loss.
Money, debt, and owned cards persist according to their rules between rounds.

Cards, loans, hybrid personal shops, limited late-entry assistance, and these
planning substages are confirmed parts of the game. Their numerical balance and
remaining detailed rules are open; they are not merely optional future features.

- Game name: Loaded Roulette
- Number of players: 2-12. The room has 12 total places shared by players and
  spectators, rather than separate capacities for each role.
- Typical game length: Not yet measured; up to about 40 minutes is acceptable.
  The earlier 5-20 minute estimate was a placeholder.
- Player objective: Build up net balance and reach the host's goal before the others.
- Winning condition: After a round is fully paid out, a player whose net balance
  reaches the goal qualifies to win. Net balance is cash minus outstanding debt.
  If several qualify, the highest net balance wins. An exact tie for the
  highest qualifying net balance leads to
  extra rounds between the tied players. Permanent departures leaving one
  participant award that participant an automatic win without the money goal.

Money is the in-game resource. Chips represent the amounts players put on bets;
each player's chips use their assigned color.

**Cash balance** is the player's settled cash, including borrowed cash.
**Available cash** is cash balance minus stakes reserved for unsettled bets.
**Net balance = cash balance - outstanding debt.** The winning goal and leader
comparisons use net balance, not cash or available cash. Borrowing increases
cash and debt; it does not by itself bring the player closer to winning.

## Intended player experience

Players should be attentive during the rolling stage and involved during the
planning stage. A large payout should feel exciting. During planning, players
should feel that they used their time wisely and made deliberate choices.
Winning should feel well fought for and satisfying.

Players who are behind should still feel that they have an understandable path
to winning. How well the betting choices alone achieve this needs playtesting;
cards, shops, late-entry assistance, and loans now form the planned strategy and
comeback systems.

A possible later addition is a short explanation of the winning player's build
or strategy, helping others understand effective choices and synergies.
The initial card ideas are listed below; further effects and synergies can be
added later.

The game should remain readable and usable on phones as well as larger screens.

## Design priorities

1. **Keep planning simultaneous.** Players act in the same timed substages,
   rather than waiting through a separate turn for every player.
2. **Make risk and reward understandable.** Show available money, reserved
   stakes, debt, possible returns, and card modifiers clearly.
3. **Make the roll worth watching.** The shared spin creates anticipation and
   explains which bets won and how balances changed.
4. **Keep the race competitive.** Cards and loans provide choices for trailing
   players; limited late-entry assistance does not recreate a full earned build.
5. **Make crowded tables readable.** Identify each player's bets and amounts
   with up to 12 players, including on smaller screens.

## Game mechanics

### Starting a game

The host chooses a starting amount of money and a goal to reach. Each player
starts with the same configured amount and receives an assigned color. Their
chips reflect that color so others can identify who placed a bet and its size.

Players compete individually. The game opens with a planning stage and then
alternates between planning and rolling. One planning stage and one rolling
stage make a round; money, debt, and owned cards carry between rounds according
to their rules.

When the host allows late participation, spectators automatically enter at the
start of the next normal round's planning stage. A new participant receives the
host-configured late-player starting money and entry-card assistance based on
the current round. Returning participants retain money, debt, and cards instead
of receiving entry assistance again.

Use conventional roulette bets and payouts as the baseline, before card effects.

Use single-zero roulette: 37 slots, numbered 0 through 36, with conventional
single-zero roulette bets and payouts. Zero is not an ordinary red/black,
odd/even, or low/high win. The betting board and spinner use the same rules.

The basic prototype supports the conventional single-zero catalog: straight-up
(35:1 profit), splits (17:1), streets and zero trios (11:1), corners and first
four (8:1), six lines (5:1), dozens/columns (2:1), and red/black, odd/even,
low/high (1:1). Paid wins also return the original stake.

Chips may be dragged to a target or selected and then placed by clicking it. A
custom chip may represent any affordable whole amount. Repeated same-owner bets
on one space combine. Stack height represents that spot's stake as a share of
the owner's settled bankroll: one chip from $1 through 10%, then another chip
per 10% band up to ten. Compact displays use five 20% bands. Exact amounts
remain available; chips are a visual representation, not a finite inventory.

Starting balance ranges from 1,000 to 200,000 and goal from 100,000 to 2,000,000,
using draggable sliders in 1,000-unit increments.

### Turns and rounds

During planning, the main board is the classic roulette betting layout. All
participating players place bets during the same planning period and may place
multiple bets on the spaces they choose during the betting substage. Betting
ends when every participating player locks in or its shared timer expires.
Planning contains smaller substages; completing betting does not skip any Final
Preparations before rolling.

A player who places no bets has no betting gain or loss that round. The player
does not need to place a bet merely to let the round continue.

When rolling begins, the betting board is replaced by a roulette spinner. The
wheel rotates with an animated ball that eventually lands in a slot. The same
result is used for every player. Successful paid bets return the original stake
and profit according to the bet's rules; unsuccessful paid bets lose their
stakes. Free bets pay profit only on a win and lose no money on a loss. All bets are settled before comparing net balances or declaring a winner.

If nobody wins the match, admit eligible spectators when the host allows it,
then open the next planning stage. Each timed substage receives its own full
countdown when it opens. A spectator joining or receiving permission during
planning or rolling waits for that next round; they do not enter the current
round halfway through. Waiting spectators do not count toward the current
round's readiness requirement.

If players tie for the highest qualifying net balance, only the tied players
participate in the additional tiebreaker rounds. Do not admit new participants
after a tiebreaker begins or after the match has already been won.

### Rules and player actions

The server accepts bets, closes planning, determines the roulette result, and
settles the round. The visible spin communicates that result; it does not let a
player's device choose the winning slot.

#### Place a bet

A participating player chooses a legal bet space and an amount during Betting.
Their chips show the chosen space, ownership, and amount. Multiple bets may be
placed during the same round.

Players may bet any positive amount they currently have available, including
all of it. No additional per-space or per-round cap applies to ordinary paid
bets. Card-created free bets and free betting rounds use their own stated limits.
Previously reserved stakes and spent money are unavailable for new bets; reserve
accepted stakes so the same money cannot fund multiple actions.

Invalid bets should be rejected with an explanation without removing money or
changing the player's other accepted bets. Bets arriving after betting closes
cannot affect the spin already in progress.

Use whole-number money only, with a minimum positive stake of 1. Monetary
calculations round down to whole units, except Shop prices use the nearest-unit/nearest-five rule below. Host-setting values cannot be decimal.
The explicit round-up rule for catch-up card counts remains separate.

#### Change or remove a bet

**Provisional:** While betting is open and the player has not ready, they
can change a bet's amount, move it to another legal space, or remove it.
Removing a bet makes its reserved stake available again.

Players may undo readiness and resume editing while the Betting substage remains
open. Once the server advances the substage, cancelling ready cannot reopen it.

#### Ready up or wait

A player locks in when satisfied with their bets. The betting substage can end
early once all participating players have ready; Final Preparations still
follow. A player can also wait for the timer; any accepted bets then become
final for that round. A player with no bets simply has nothing to win or lose
from the spin.

Every player-input planning substage has its own timer and a Ready up control.
Players can undo readiness while that substage is still open. Locking in does not
spend stakes or cards again, refund already spent actions, or trigger a separate
spin. All-ready can advance the substage before its deadline.

#### Roll and settle

Once betting closes, players cannot add, move, or remove bets for that round.
Final Preparations closes before rolling begins. Cards played there are
activated before the spin; outcome-dependent effects settle after the result
in the confirmed settlement order. The roulette result is
revealed, winning bets are identified, and all returns and losses are applied
once. A player can win some bets and lose others on the same spin; their final
balance reflects all of them.

The interface should distinguish the stake returned, the profit from a winning
bet, and the player's overall gain or loss for the round.

### Planning substages, cards, and shops

The planning order is Rewards -> Shop -> Public Buff/Debuff Placement -> Betting
-> Final Preparations. Public placement uses stronger public effects; Final
Preparations uses weaker personal effects. These are substages of planning, not
additional top-level stages. Rolling follows Final Preparations. Reward
selection prepares the next round after the previous rolling stage and winner
check; there is no further reward draft once the match has been won.

#### Card rewards and scaling

Round 1 gives no cards and plays as ordinary roulette; card-related substages
begin in round 2. Rewards are offered at the start of that round's planning,
not after the same numbered round has finished:

| Round | Reward |
| --- | --- |
| 1 | None |
| 2 | Temporary |
| 3 | Temporary |
| 4 | Permanent |
| 5 | Temporary |
| 6 | Temporary |
| 7 | Permanent |

Repeat temporary, temporary, permanent thereafter. Permanent rewards occur in
rounds 4, 7, 10, and so on, replacing the temporary reward for that round.
Offer three cards where enough eligible cards exist. Temporary cards may
reappear when held. The initial card ideas below are subject to balance changes.

Permanent means that a card remains owned, not that its effect necessarily
grows. Permanent effects may be fixed bonuses, capped bonuses growing from
acquisition onward, or bonuses based on the match round counted from the start
of the game. Each card specifies how it uses these counts; do not impose a
single acquisition-round versus continuously updated rule on all cards.

Growing effects have fixed caps. Match-round-scaled cards should have stronger
late-game effects and higher caps where appropriate to help long matches end.
Percentages discussed so far are examples, not final balance values. Betting
profit bonuses affect winnings rather than the returned stake.

Cards may retain information specific to their effects, such as their current
scaling bonus or the debt amount an effect refers to. Refunds must follow the
card's stated rule exactly, rather than use one universal refund amount or
return more than the card promises. For example, a card saying "refund the
latest taken debt" refers to the player's most recently taken loan, not all debt
or an unrelated fixed amount. Preserve enough loan history to identify that
loan.

Debt-relief amounts are card-specific, as listed below. Final Preparations is
their initial window; broader use during planning is a deferred possibility.
Detailed handling of prior repayments and borrowing costs can be settled when
these cards are implemented rather than blocking the wider design now.

Duration and stacking depend on each card's stated effect. Ordinary percentage
profit bonuses add together; cards explicitly saying to multiply or double use
that operation. Do not silently multiply ordinary additive bonuses.

Any card effect that deducts money from a player's total takes available money
first. If the deduction exceeds that money, add the uncovered amount to penalty
debt instead of making the cash balance negative. Do not spend money already
reserved for another accepted action. For example, a deduction of 100 with 30
available takes the 30 and adds 70 debt. This general rule uses the same penalty
debt treatment as Double Everything: no loan surcharge, no consumption of the
round's borrowing allowance, and normal debt accounting toward winning.

#### Initial card ideas

Names and all numerical values are working ideas that can be tweaked and
balanced later. Temporary cards are consumed on use unless their final rules
say otherwise. Permanent cards remain owned. Public temporary cards below are
played during Public Buff/Debuff Placement and affect the current round.

##### Temporary cards

###### Beneficial effects

| Working name | Proposed effect |
| --- | --- |
| Loan Relief | Clear 50% of the latest loan's original debt, capped by its unpaid balance. |
| Debt Reduction | Pay off 20% of total outstanding debt. |
| More draws | Randomly place two free, uneditable bets, each worth 5% of current total. |
| Profit up | Gain +20% profit on this round's bets. |
| Goal Grant | Receive cash equal to 5% of the required goal. |
| Cash Bonus | Receive cash equal to 10% of current total. |
| Random temp card (rare) | Receive two random temporary cards, excluding this card itself. |
| Random permanent card (rare) | Receive one random permanent card. |
| Shared Agreement | If every participant who placed a bet this round, including you, makes positive net betting profit, gain +30% betting profit. Abstaining participants are excluded. |
| Safety Net | Select a bet before rolling. If it loses, recover 50% of its paid stake. |
| Debt Collector | This round, winning bets additionally clear debt equal to 10% of their profit. |
| Quick Sale | Sell one other owned card, including a negative card, for 50% of its estimated normal shop price. Usable during planning. |
| On Hold | During Shop, reserve one available offer until your next Shop at its current price and discount. Maximum one reserved offer. |
| Shop Reroll | During the Shop stage, reroll all regular offers and the deal, for this player only. Other shops remain unchanged. |
| Reward Reroll | Before choosing a reward, replace all current choices using an already-owned copy. Keep the choice count, reward type, and remaining timer. A copy chosen in this draft is saved for a later draft. |
| Go Fish | During Final Preparations, choose another player and blindly select one temporary card to steal from their hand. |
| Pickpocket | During Final Preparations, steal one random temporary card from another player's hand. |
| Sticky Fingers | During Final Preparations, privately reveal two random temporary cards from another player's hand and steal one. |
| Double Choice | During Final Preparations, steal one random temporary card from each of two random players. |
| Interception | During Final Preparations, choose another player. At their next reward draft, take the first temporary card they select instead of them. The effect expires after that draft, even if no temporary card was selected. |
| Reclaim | During Final Preparations, recover a card stolen from you if it is still a temporary card in its current owner's hand. |
| Equal Opportunity | During Final Preparations, gain +30% betting profit this round if you have the lowest settled net balance among participants. Tied lowest players also qualify when they play this card. |

###### Neutral effects

| Working name | Proposed effect |
| --- | --- |
| Reassignment | Choose one assigned Specialist copy and move its bonus to another betting spot. |
| Discard | Discard one of your cards. |
| Trade up | Trade a temporary card for a choice among three permanent cards. |
| Roll down | Trade a permanent card for three random temporary cards. |

###### Risky effects

| Working name | Proposed effect |
| --- | --- |
| Sleight of Hand | At any time, choose one temporary card from your hand and exchange it for a blind pick of one temporary card from another player's hand. |
| Double or nothing | Activate during Final Preparations. After normal betting settlement, a separate 50/50 gamble doubles positive net betting profit or removes that profit entirely. A zero-profit or losing round is unchanged. |
| Double Everything | Activate during Final Preparations. Double this round's net betting profit or net betting loss, with no separate coin flip. Uncovered additional losses become penalty debt. |

###### Negative effects

These cards apply automatically when received and discard themselves after
their stated penalty resolves or its duration ends.

| Working name | Proposed effect |
| --- | --- |
| Cold Streak | Your first winning round after acquiring this card earns 30% less profit. |
| Bad Investment | Your next shop purchase costs 25% more. |
| Short Changed | During the next round only, winning bets earn 20% less profit. Discard after that round even if no bet wins. |
| Paperwork | You cannot borrow during the next planning stage. |
| Limited Selection | Your next reward draft offers one fewer choice, with a minimum of one. |
| Shop Closure | Skip your next Shop stage. |
| Public Silence | You cannot play public cards next round. |
| Collection Notice | After the next round, pay 5% of your current total. |
| Forced Sale | At the end of the next planning stage, discard one other card of your choice. |

###### Settlement notes

Hand theft and swaps affect temporary cards in players' hands, not permanent cards.
For all blind thefts and swaps, selections use shuffled, face-down cards, and
the chosen card's identity is revealed to its recipient only after the transfer.
Sticky Fingers explicitly allows its player to privately reveal cards before
choosing. Hand theft and swaps require enough eligible cards in the target's
hand. Interception targets a future reward instead, so an empty hand does not
prevent targeting that player. A transferred negative card applies to its new
owner immediately.

Double or nothing risks only positive net betting profit, not the original
stakes returned or the player's remaining balance. Resolve its separate 50/50
gamble after the normal roulette result and betting settlement, but before debt
repayment and the match winner check. It does not gamble shop purchases, loan
proceeds, or direct cash grants. For example, a round with 10,000 net betting
profit becomes either 20,000 profit or zero profit. A net betting loss remains
the same loss.

Double Everything is a separate temporary card from Double or nothing. Resolve
it after the normal betting outcome and before debt repayment and the winner
check. A net betting gain of 10,000 becomes 20,000; a net loss of 10,000 becomes
20,000 lost. A zero net outcome stays zero. It affects betting gain or loss,
not total wealth, shop spending, direct cash grants, or loan proceeds.

For an extra loss, first take remaining available money; turn only the uncovered
amount into penalty debt. Do not charge the original stake again. For example,
a normal net betting loss of 100 creates an extra loss of 100; if only 30 cash
remains, take that 30 and add 70 penalty debt. Cash never goes negative.
Penalty debt has no loan surcharge, does not consume the once-per-round loan,
and counts against winning like other outstanding debt. Show this risk before
playing the card.

[Define refund placement within the confirmed settlement order, multiple-copy
multiplier/gamble behavior, and whether debt relief clears penalty debt.]

##### Public temporary cards

###### Beneficial effects

| Working name | Proposed effect |
| --- | --- |
| Bounty (public) | Mark a betting spot; anyone winning a bet on that exact spot receives +50% profit this round. |
| Profit Bonus (public) | Increase profit on all players' winning bets by 30% this round. |
| Crowd Favorite (public) | Mark a number; straight-up wins there gain +10% profit per distinct player betting there, capped at +50%. |
| Lone Wolf (public) | Mark a number; a straight-up win gains +50% profit if exactly one player bets there. |

###### Neutral effects

| Working name | Proposed effect |
| --- | --- |
| White Out (public) | Remove all status effects, positive and negative, from one betting spot before Betting begins. |
| Copycat (public) | Copy one public effect already placed onto another eligible spot. |
| Reverse Fortune (public) | Turn one negative profit modifier on a spot into an equally strong positive modifier, or vice versa. |
| Relocation (public) | Move one status effect from its current spot to another eligible spot. |

###### Risky effects

| Working name | Proposed effect |
| --- | --- |
| Erase (public) | Remove one randomly selected status effect from a betting spot before Betting begins. |

###### Negative effects

| Working name | Proposed effect |
| --- | --- |
| Targeted (public) | Mark a betting spot; anyone winning a bet on that exact spot receives 50% less profit this round. |
| Profit Cut (public) | Reduce profit on all players' winning bets by 30% this round. |
| Parking Tax (public) | Mark a betting spot; anyone winning a bet on that exact spot pays 10% of that bet's profit to the card's owner this round, subject to the combined tax cap. |
| Cross out (public) | Mark a betting spot and disable betting on that spot for the round. |

##### Permanent cards

###### Beneficial effects

| Working name | Proposed effect |
| --- | --- |
| Profit up, held rounds | Gain +5% profit per round held, capped at +60%. Maximum one copy. |
| Profit up, rounds played | Gain +5% profit per match round played, capped at +50%. Maximum one copy. |
| Third times the charm | Every third betting round covers stakes up to 20% of your cash at Betting start for free. Each additional copy adds 20 percentage points of coverage. You may bet more using your cash; excess stakes remain paid. |
| More cards | Rare. One copy gives a random extra card every other round; two copies give one every round. Maximum two copies. The extra card can be temporary or permanent; permanent selection has one-sixth the temporary selection weight. |
| More choices | Rare. Add reward choices every other round with one copy, or every round when maxed. Each copy adds one choice in Rewards only, not choices from active cards. Maximum two copies. |
| More the merrier | One copy allows an extra public temporary-card play, then has a one-round cooldown. A second copy removes the cooldown; maximum two copies. |
| Specialist | After Shop, immediately choose a required betting slot for each acquired copy; gain +30% profit there. Copies may target different slots or stack additively on the same slot. |
| Negative to Positive (rare) | Suppress negative temporary and permanent effects while owned; gain +2% betting profit per negative card owned, capped at +60%. Maximum one copy. Does not undo resolved effects. Exempt from Type Reversal. |
| Split Decision | Split bets gain +25% profit. Maximum one copy. |
| Street Hustle | Street, corner, and six-line bets gain +20% profit. Maximum one copy. |
| Clean Slate | Removing a currently negative card with Discard or a trade adds +3% betting profit, capped at +30%. Sales do not count. Maximum one copy. |
| Good Standing | Each round you manually repay debt adds +2% betting profit, capped at +20%. Only once per round. Maximum one copy. |
| Publicity | Gain +5% personal betting profit per public card you play this round, capped at +15%. Maximum one copy. |
| Reseller | During Shop, sell currently positive, neutral, or risky cards for 50% of their estimated normal shop price. Negative cards cannot be sold. Maximum one copy. |
| Shopping Spree | Each successful shop purchase while owned adds +1% betting profit, capped at +50%. Buying this card counts; rewards, generated cards, and failed or repeated purchase requests do not. Maximum one copy. |
| Patient Investor | Each round with no shop purchases adds +5% betting profit, up to +30%. Buying pauses growth without resetting it. Maximum one copy. |
| Against the Crowd | Gain +40% profit on winning bets on spots no other betting participant used this round. Check all other placed bets, including stacked bets. Maximum two copies; bonuses add. |
| Debt-Free Dividend | Gain +20% betting profit while no debt is outstanding. Maximum two copies; bonuses add. |
| Cashback | Recover 20% of each lost paid stake. Copies add, capped at returning that stake. |
| Gap Closer | Gain +1% profit for every 2% you are from reaching the goal. |
| Final Sprint | Gain +1% profit for every 2% you are closer towards reaching the goal. |
| MinMax | Increase all profit gains from cards by 1.1x. |
| Cheapskate | Shop cards cost 10% less. |
| TAX | Each copy transfers 2.5% of other players' qualifying betting profit to you. Maximum four copies per owner. Triggers on a player's combined net betting profit for the round at the 10%-of-goal threshold: 100,000 for a 1,000,000 goal. |

###### Risky effects

| Working name | Proposed effect |
| --- | --- |
| Type Reversal | Negative and positive card effects swap. Newly positive temporary cards can be held and played in their allowed stage; newly negative temporary cards activate at their stated timing and then discard. Each copy flips effects again and grants +20% betting profit, capped at +100%. Normal rarity. Negative to Positive is exempt from reversal. Numeric reversals preserve each card's values; approved utility reversals are implemented. |

Type Reversal keeps each card's own numerical magnitudes and changes the
direction of its effect. For example, a -25% effect becomes +25%, while a +15%
effect becomes -15%. Preserve that card's caps, scaling amounts, conditions,
and duration; do not replace it with a different card's opposite effect or
values. Neutral and risky cards are unaffected. Already-played effects keep
their committed behavior. Utility effects without a numerical sign use the explicit mappings below.

Negative to Positive is exempt from Type Reversal: it stays positive, retains
its suppression ability, and keeps its +2% betting-profit bonus per currently
negative card owned, capped at +60%. Determine other cards' current polarity
after reversal before applying suppression or counting that bonus. Previously
resolved effects are unchanged.

###### Negative effects on the owner

| Working name | Proposed effect |
| --- | --- |
| House Cut | Your winning bets earn 10% less profit. |
| Expensive Taste | Shop cards cost 15% more. |
| Bad Credit | New loans add 40% debt instead of the normal 25%. |
| Leaky Pockets | Lose 1% of your available cash after each round. |
| Dead Weight | Receive one fewer reward choice, with a minimum of one. |
| Loan Dependency | Earn 15% less betting profit while debt-free. |
| Maintenance Fee | After each round, pay 5% of your current total for each permanent card you own, capped at 50% of your current total. |

###### Card interaction notes

There is no cap on the number of negative cards a player can own. Players
usually choose which cards they receive, so no separate ownership limit applies.

Discard and trading cards can be used at any time, regardless of the current
stage, to remove negative cards before their penalties resolve. Trade up can
trade away a negative temporary card; Roll down can trade away a negative
permanent card. Removing a card prevents its remaining penalties, but does not
undo effects already applied.

Negative permanent cards apply their penalties while owned and remain until
removed, including by Discard. Discard removes the chosen card's ongoing effect;
it does not undo penalties already paid. Cold Streak is a negative temporary
card that expires after affecting the first winning round following acquisition.

[Choose how negative cards are acquired.]

The newly suggested values for Safety Net (50%), Debt Collector (10%), and
Patient Investor (+5% per qualifying round, capped at +30%) are provisional
starting values. Bounty gives +50%, Specialist +30%, Against the Crowd +40%,
and Debt-Free Dividend +20%; these remain adjustable for balance.
Patient Investor does not reset on purchases.
Double or nothing retains the 50/50 positive-profit gamble described above;
extra-loss or double-all-outcomes alternatives are not its current rule.

Free betting-round effects apply during Betting; More draws creates its
free wagers during Final Preparations. Free wagers cost no cash, return profit only on
a win, and return nothing on a loss: no fictitious stake is paid back, and the
free bet itself has no loss consequence. Refunds based on paid stakes have no
paid stake to refund for these bets.

[Define acquisition-round eligibility and when Debt-Free Dividend checks debt.]

[Define card timing and consumption, what "current total" means for each card,
free-stake snapshots, trade inputs, remaining generator rarity, alternating-round
alignment, and offers with too few eligible cards. Decide how bonus cards use
the temporary/permanent schedule.]

Shared Agreement checks positive net betting profit, not whether every
individual bet won. Evaluate its condition before its own bonus. Include only
participants who placed bets, even if they are currently disconnected.
Against the Crowd also checks bets placed by other betting participants;
stacked chips do not make an occupied betting spot eligible.

Double or nothing may be activated once per player per round. Further owned
copies remain available in later rounds.

[Define remaining activation timing for More the merrier.]

#### Approved Type Reversal utility mappings

These reversals keep each original card's own quantities and timing. They do
not substitute another catalogue card's values. These mappings are implemented.

| Original card | Approved reversed effect |
| --- | --- |
| More draws | Place two forced paid bets, each worth 5% of current cash, instead of two free bets. |
| Random temp card | Lose two random temporary cards. |
| Random permanent card | Lose one random permanent card. |
| Quick Sale | Automatically sell one random available other card, including a negative card, and receive 50% of its estimated normal shop price. |
| On Hold | Block one random offer in the next Shop only. Current offers stay unchanged. |
| Reseller | Selling costs 50% of estimated normal shop price instead of paying cash; currently negative cards remain ineligible. |
| Shop Reroll | Automatically reroll the applicable shop once and consume this card, even if the new offers are not worse. |
| Reward Reroll | Automatically reroll the applicable reward choices once and consume this card, even if the new choices are not worse. |
| Go Fish | A randomly selected eligible other player blindly selects one temporary card from your hand to take. |
| Pickpocket | Give one random temporary card to another player. |
| Sticky Fingers | A randomly selected eligible other player privately sees two random temporary cards from your hand and takes one. |
| Double Choice | Give one temporary card to each of two randomly selected eligible players. |
| Interception | Another player receives the next temporary reward you select; retain the original draft-expiry rule. |
| Reclaim | Return a temporary card you stole, provided it is still in your hand. |
| Cold Streak | Gain 30% extra profit on the first winning round, then discard. It is not restricted to the immediately following round. |
| Shop Closure | Refresh the current round's personal shop once when played during Shop. |
| Cross out | Free Entry: every participant gets one free straight-up bet on the marked number at Betting entry, worth 5% of their current cash. |
| Forced Sale | Choose one temporary card to gain from three offers. |

Short Changed reduces winning-bet profit by 20% during the next round only,
then expires even if no bet wins or the player abstains. The reversed version
gives +20% winning-bet profit during that same next-round window and expires
afterward regardless of wins. It does not reduce losing stakes.

For every reversed theft or interception that gives another player a card,
show the recipient which player it came from and which reversed card caused
the transfer, for example: "Alex's reversed Go Fish gave you a card."
Also explain the transfer to the source player. Keep card identities private
to entitled viewers; this feedback must not expose either player's remaining
hand. This cause-specific feedback is required even though ordinary personal
card plays do not produce a public alert.

Flipping a card preserves its accumulated state. A held-round profit bonus
that has reached +15% becomes -15%, not its original -5% starting value.
Acquisition round, accumulated growth, counters, cooldowns, assignments, and
other card-specific memory are retained through each reversal. Flipping back
restores the corresponding positive direction without restarting progression.

Reversed Cross out is Free Entry: when Betting opens, every participant gets
one free straight-up bet on the marked number worth 5% of their current cash.
It pays profit only on a win and loses nothing on a loss. Reversed Forced Sale
grants a choice of one temporary card from three offers. Its source is consumed
before revealing the required choice, preventing free rerolls by cancellation.

#### Round settlement order

After the roulette outcome is known, resolve the round in this order:

1. Additive profit bonuses and reductions.
2. Explicit multiplicative effects.
3. Profit gambles such as Double or nothing.
4. Taxes.
5. Debt changes, including winning-condition repayment.
6. Winner check.

Cap profit reduction at 80%: modifiers cannot leave less than 20% of normal
winning profit at the profit-modifier stage. This is not a guarantee against
later tax, a failed profit gamble, or an ordinary losing bet. Monetary results
use the whole-number floor rule, so rounding can produce less than an exact
20% payout on very small profits. Specific refund and conditional-card timing
must fit this order without introducing circular calculations.

#### Copy limits, betting-round counts, and public stacking

Permanent copy rules are specified per card above. The two scaling Profit up
cards and Patient Investor allow one copy each. More cards, More the merrier,
Against the Crowd, and Debt-Free Dividend allow two. TAX allows four. Specialist
can stack on the same slot or apply to different slots. Third times the charm
increases its free-round limit by 20 percentage points per copy. More choices
allows at most two copies and only affects the scheduled Rewards stage.

Third times the charm counts betting rounds, not individual bet placements.
All bets placed in one round count as one combined bet. After betting in two
rounds, the next betting round is free, subject to the combined free-stake cap.
Abstaining does not advance the count; editing or splitting a bet cannot advance
it multiple times. This changes the card's original "every third placed bet"
wording.

[Define the balance snapshot for free stakes, treatment of card-created bets,
acquisition-round eligibility, and any upper cap on the per-copy stake limit.
Define alternating-round alignment.]

Profit Bonus (+30%) and Profit Cut (-30%) cancel additively; Bounty (+50%) and
Targeted (-50%) cancel on the same slot. Cap combined profit reductions at 80%
for now, rather than allowing repeated cuts to suppress all profit indefinitely.

Apply the 80% maximum reduction to the combined profit-modifier result; leave
at least 20% of ordinary winning profit at that stage. Taxes are resolved later.

White Out removes all status effects attached to its target spot, including
buffs, debuffs, Parking Tax, and Cross out. Erase removes one attached status
effect at random, which may be positive or negative. Neither removes a global
effect that is not attached to that spot.

Public plays resolve in server acceptance order, serialized by the shared animation hold. Removal, relocation, copy, and reversal reject an ineligible or empty target without consuming the source card.

Parking Tax and TAX transfer profit earned from bets in the round, not returned
stakes or tax income. TAX's threshold is 10% of the goal; a 1,000,000 goal
therefore means a 100,000 threshold. Check the player's combined net betting
profit across the round, rather than testing each winning bet separately.
Calculate all tax claims from the same pre-tax betting profit after bonuses,
multipliers, and profit gambles. Never tax incoming tax transfers or returned
stakes. Total tax collected from one player, including TAX and Parking Tax,
cannot exceed 50% of that player's qualifying round betting profit.

For nonnegative pre-tax qualifying profit P, set the whole-unit cap to
floor(P / 2). A player with zero or negative net betting profit has a zero
round-profit tax cap.
Calculate each claim using its stated rate and eligible profit, rounding down.
If their sum S exceeds the cap C, reduce each claim proportionally to
floor(claim * C / S). Do not redistribute leftover rounding units: they remain
with the payer, so actual collection may be slightly below the cap.

Determine all claims before moving money. After applying each payer's cap and
rounding each claim, cancel opposing player-to-player obligations so only their
net difference is transferred. This does not change the underlying tax claims
or add another tax event.

Exactly meeting the TAX threshold triggers it.

Card generators and enabling cards should be rare to make generation loops
resource-intensive. More cards and More choices are explicitly rare; existing
rare generators retain that status. Do not add a hard generation-chain limit
for now. More choices never enlarges choices from active generator/trade cards.

[Review remaining generator/enabler rarity, including Trade up and Roll down.]

Cross out blocks its space even if Bounty or Targeted is also present; decide
whether useless overlapping placements are allowed. Other card interactions
must use the confirmed settlement order above.

The general intention of stronger late-game scaling remains, but the proposed
held-round +60% and match-round +50% caps are the current concrete card ideas;
there is no universal requirement that every match-round cap exceed every
held-round cap.

#### Hybrid personal shops

Each player has a separate shop; buying does not consume another player's stock.
The selection combines shared temporary and permanent cards with random personal
temporary and permanent offers. Everyone receives seven offers: five temporary
cards and two permanent cards. Refresh every round. Personal shop contents are
private to their owner.

Group personal randomized offers at the top and shared offers at the bottom.
Within each group, place permanent cards to the right of temporary cards.
Keep these groupings clear when adapting the shop to narrow screens.

Temporary cards use silver frames; permanent cards use gold styling. Public
temporary cards use a silver border with a muted purple interior, retaining
the temporary-card frame while making their public scope easy to recognize.
Use high-contrast text and an explicit Public badge so identification does not
depend on color alone. Apply this card styling consistently in shops, reward
choices, and hands.

The shared/random split means how many offer slots show the same card selection
to every player, versus individually randomized cards. Shared offers are not
shared stock: another player's purchase cannot remove your copy. Use this split:

| Type | Shared offers | Personal random offers |
| --- | --- | --- |
| Temporary | 3 | 2 |
| Permanent | 1 | 1 |

Shared selections are identical across players, but inventories and purchases
remain independent. Personal random offers are chosen individually.

Card pricing uses the configured starting cash and goal plus the average net
balance of current contenders, not combined room wealth. Net balance is cash
minus outstanding debt, so borrowed principal does not artificially raise
prices. Capture the signed whole-unit average when Shop opens; clamp a negative
average to zero only when applying the formula. Include offline contenders,
but exclude spectators, departed players, and non-contenders in a tiebreaker.
All players use the same captured average for that Shop stage, including owner
rerolls. Recompute it when the next Shop stage opens.

A round adjustment would raise prices based only on round number. This remains
future balancing work, alongside card-specific price weights. Current prices
already incorporate average net balance using the formula below.

Do not apply early-round purchase restrictions for now. Fewer early offers,
purchase limits, and delayed permanent access are deferred balancing options.

A Shop Reroll replaces every offer for its owner, including originally shared
slots, without rerolling other players' shops. Shared slot positions remain in
their group even when their rerolled cards differ.

For More cards' extra reward, permanent cards have one-sixth the temporary-type
selection weight (temporary 6, permanent 1). This type roll is separate from
a card's rarity within its type. Whether this is intended as type selection or
per-card weighting should be confirmed before implementation.

A rare card has one-sixth the selection weight of a regular card of the same
type. For example, use regular weight 6 and rare weight 1, then normalize over
the eligible pool. This is relative weight, not a flat 1-in-6 rare-card chance.

Each offer can be bought once before it is replaced; show Sold out afterward.
Copies can still be purchased from other offers or later refreshes, subject to
that card's ownership cap. Show Already maxed and disable purchasing when the
player owns the maximum permitted copies. Reroll replaces all shop offers,
including sold-out slots, for that player only; replacement offers are new
purchase opportunities subject to ownership caps.

[Define prices and any additional rare-card assignments.]

#### Public effects and Final Preparations

Before betting, players can apply stronger public buffs or debuffs to betting
spaces. Start with a limit of two public-effect cards per player per round. This
is a base play limit, not a two-card hand limit: cards can be saved for later.
More the merrier can grant an extra public temporary-card play when not on
cooldown. Show final public modifiers before betting opens.

After betting closes, allow weaker personal card effects in the Final
Preparations substage. These are not unrestricted attacks on other players'
committed bets. Bet positions and stakes remain fixed during this substage.

Explain board effects with symbols, readable descriptions, and a symbol
reference.

Effects use card-specific durations. Ordinary percentage bonuses combine
additively; explicit multiplier effects follow their own text. Profit reductions
are capped at 80%, retaining at least 20% of normal profit before separately
resolved taxes. Apply additive modifiers before explicit multipliers, as
specified in Round settlement order.

Global public cards such as Profit Bonus and Profit Cut affect their owner as
well as the other players. Profit modifiers change profit, not returned stakes,
and combine additively. Cross out disables a betting space, not the roulette
pocket: that number may still roll and pay other legal covering bets. It is
placed before Betting, so no existing paid bet needs to be cancelled.

Any number of personal cards can be played during Final Preparations, allowing
players to stack effects. A personal-card limit is only a later balancing option.

[Define simultaneous public resolution and eligible Cross out targets.]

### Late-entry assistance

Late players receive the host-configured late-player starting money, defaulting
to the same starting-money setting as original players unless overridden.

Calculate the temporary and permanent rewards already offered at the entry
round separately. Divide each count by two and round up. Each granted card has
two choices rather than three; all cards are eligible within its reward type.
Temporary cards are part of this grant, not a separate unlimited bonus.

For round r, the scheduled counts through that round are:

- Permanent: floor((r - 1) / 3).
- Temporary: max(0, r - 1) minus the permanent count.
- Catch-up grant: ceil(temporary / 2) and ceil(permanent / 2).

At round 4 this gives one temporary and one permanent card. At round 7 this
gives two temporary and one permanent card. Three missed permanent rewards give
two permanent choices after halving and rounding up. Counts can be derived
from the round rather than stored as separate cumulative counters.

**Entry accounting:** The grant includes the entry round's reward
and replaces its normal draft for that newcomer, avoiding a duplicate reward.
Returning players retain existing state; they never receive fresh entry money.
Their missed-reward assistance is described under offline players.

### Loans

A bank or loan shark lets players borrow spendable money and acquire debt,
including when bankrupt. Net balance is cash minus outstanding debt;
borrowing itself cannot move a player closer to the winning requirement.

After full round settlement, automatically repay all debt if the player can do
so and still meet the goal. Compare qualifying net balances after repayment. Players
can also repay voluntarily during planning.

Each player can take one loan per round, during either Shop or Betting, choosing
its size up to the limit. Repayment or debt-relief cards do not reset that round's
borrowing allowance. Profit cards do not multiply borrowed money itself.

**Provisional balance values:** Maximum principal is 25% of the goal. A loan
adds debt equal to its principal plus a one-time 25% surcharge: borrowing 100
creates 125 debt. This does not imply recurring interest. Show terms before
confirmation.

Existing unpaid debt does not block the next round's loan: borrowing is intended
to keep players able to bet. The 25%-of-goal cap limits an individual loan, not
total outstanding debt. Players may abstain, and an empty balance does not
eliminate them. Spending a loan before Betting can exhaust that round's funds;
that player can abstain and borrow again next round, not take a second loan.

Loan amounts and debt use whole units; percentage calculations round down.

### Future special wheel slots

Begin with ordinary default roulette slots. Keep slot definitions and the
matching spinner presentation changeable so slots can be added or replaced
later. Bankruptcy, double-money, and gifting slots remain future ideas without
committed gameplay rules.

### Winning, losing, and elimination

Check the goal only after the entire round has settled. If one player's net
balance reaches or exceeds it, that player wins. If several qualify, compare
their net balances (cash minus outstanding debt); the highest wins,
regardless of which payout appeared first.

If several players share the highest qualifying net balance exactly, another round
starts with only those players participating. Keep awarding cards on the same
round schedule and refreshing shops for those tied players until the tie ends.
Non-tied players cannot draft, shop, bet, or play cards in these extra rounds.
Continue the tiebreaker if they remain tied. After showing the result, return
players to the lobby, where the host can change settings and start another match.

A lost bet does not by itself eliminate a player. A player with no money cannot
place a positive-money bet but may borrow under the loan rules.

A round with no bets still proceeds. Loans become available again next round;
there is no forced bankruptcy elimination or automatic wager.

Once a tiebreaker begins, the player with the highest settled net balance wins when
the tie breaks, even if all tied players have fallen below the original goal.
Continue comparing money after accounting for outstanding debt, as in the
normal winning rule; the goal no longer has to be met again.

### Example of play

For illustration, suppose neither player has debt or active card effects, the
goal is 500, and a winning paid bet returns 40 in total
for a stake of 20. These example amounts do not establish the final payout
table.

Alex begins a round with 480 and Sam with 490. Both place a 20-money bet that
wins on the shared spin. Alex's balance becomes 480 - 20 + 40 = 500; Sam's
becomes 490 - 20 + 40 = 510. Both reach the goal in the same round, so Sam wins
with the higher net balance (cash minus debt; neither player has debt here). Alex does not win merely because their payout
was shown first.

If both instead finish on exactly 500, they enter the tiebreaker. Other players
do not place bets in those extra rounds.

## Hidden information and spectators

Player identities, assigned chip colors, bet positions, and bet amounts are
public, matching the intention that players can see what everyone is betting.
The phase, remaining planning time, revealed result, and settled balances should
also be clear to everyone.

Each player's hand and personal shop are visible only to that player. When a
Final Preparations card is played, everyone sees who used it and which card was
used. That reveal does not expose the rest of the hand or shop. The upcoming
roulette result stays hidden until the roll reveals it; personal display
choices must not reveal the outcome early.

Spectators can watch public bets, spins, and standings, but cannot place bets,
ready up, or affect outcomes while spectating. Late joiners initially spectate.
When the host allows late participation, eligible spectators are automatically
moved into play at the next normal planning stage with the configured
late-player balance and entry-card assistance. They do not need to wait for a
new match or take a separate join action. If the host does not allow it, they
remain spectators.

Every spectator already occupies one of the room's 12 places. Moving them into
play changes their role without adding another room member. A room with 12
players is full and cannot also contain additional spectators. The total of
players and spectators must never exceed 12.

Non-participating players can continue watching a tiebreaker, but spectators
cannot enter its betting rounds. A returning participant resumes their existing
match balance, debt, and cards; leaving and rejoining must not grant fresh
starting money or repeat entry-card assistance.

Private hands and personal shops must also remain hidden from spectators.

[Decide whether owned permanent effects are public before they are used.]

## Settings reference

Shared betting rules are chosen before starting a match. Changes should affect
the next match rather than changing the goal or stakes during an ongoing race.
Permission to admit spectators into later rounds is a separate host control.

### Setting: Starting money

Every player receives this amount at the start of the match. It determines the
initial betting budget and how much risk players can take early on.

The host chooses this amount. Use a provisional default of 100,000 until testing.

[Choose permitted whole-number setting ranges.]

### Setting: Late-player starting money

Default to the match's starting money, initially 100,000. The host can override
this balance for late players.

[Choose permitted values and whether the override can change during a match.]

### Setting: Money goal

This is the balance players must reach or exceed after a settled round to
qualify for winning after outstanding debt is repaid. Its relationship to the
starting balance, card effects, shop prices, and payouts affects game length.

The host chooses the goal. Use a provisional default of 1,000,000 until testing.

[Choose permitted values and validation against starting money.]

### Setting: Planning time

Every planning substage has its own timer and reversible Ready up control.
Use 30 seconds for Rewards, Shop, Public Buff/Debuff Placement, and Final
Preparations, and 60 seconds for Betting. All-ready can end an input substage
early. Round 1 skips card-related substages because no cards are in use yet.
Rolling lasts as long as its wheel animation; it has no player readiness button.

If a connected player times out without choosing a reward, randomly select one
of their offered cards. If disconnected at timeout, award no card automatically.
This applies to reward selection, not automatic shop purchases or card plays.

[Choose whether the host can configure durations and whether empty substages
are skipped. Define timing for additional or catch-up reward choices.]

### Host control: Allow late participation

The host decides whether eligible spectators automatically enter the next normal
round. Enabling permission does not interrupt the current planning or rolling
stage, change existing bets, or let anyone enter a tiebreaker. Without
permission, spectators keep watching. The shared 12-person room limit still
applies.

[Choose whether late participation is allowed by default.]

### Personal preferences and presets

Rule configurations can use GameHub's browser-local presets. This game does not
need its own separate preset system.

No personal themes have been chosen yet. Any later themes should preserve the
meaning of roulette outcome colors and keep players' assigned chips
identifiable.

[Choose any personal presentation options, their defaults, and which choices
should be remembered.]

## Offline players and host ownership

Every disconnect pauses the game for 60 seconds, then play continues unless
the host has manually paused. The host can resume earlier or kick a player who
repeatedly causes pauses. No repeat-disconnect exemption is planned for now. Preserve money,
debt, cards, borrowing allowance, and accepted actions: already spent actions
resolve as though the player were present. Missed actions have no effect; do
not invent bets, purchases, or card plays for an absent player.

Players can reconnect whenever their existing player remains in the lobby or
game. Restore their state and current substage without new starting money or
repeating rewards already received. The existing round borrowing allowance
remains unchanged.

Absent players do not automatically choose rewards and may miss cards.
On return to the same match, keep existing possessions and offer half the
temporary and permanent rewards they could have received while absent, rounding
each type up as for late entry. Track their absent round interval
or missed reward rounds; count only rewards they actually missed, not every
reward since the match began. Repeated reconnects must not claim the same
missed rewards twice.

Returning-player assistance opens at the next normal reward stage with two
choices per card. Only missed normal scheduled rewards count; missed More Cards
bonuses do not. Temporary and permanent missed counts are halved and rounded up
separately. Assistance and the current normal draft share the 30-second window.
Connected players get random choices for all remaining drafts at timeout.
Disconnected players get no automatic choices; unchosen assistance carries forward
until a connected reward stage. Already granted rewards are never counted again.

Each new disconnect resets the automatic disconnect countdown to the full
60 seconds, including overlapping disconnects. The alert names the player who
disconnected. The host can resume or kick repeat disconnectors.

Resume immediately when the disconnected player reconnects, without waiting
for the automatic countdown to finish, unless a manual host pause remains.

[Define early resume when several players are disconnected: whether all must
return or one returning player clears the current disconnect pause.]

The host should be able to pause or resume. A manual pause should stop phase
progression and preserve the remaining time and accepted bets. A host change
should transfer these controls without resetting the round, bets, or balances.
If the host permanently leaves, transfer room ownership to another eligible
remaining player. This refers to host ownership, not automatic transfer of the
departed player's cards, money, or bets.

An automatic disconnect-pause deadline must not undo a manual host pause.

Permanently leaving or being removed removes the participant from the game;
temporary disconnection leaves them present but without automatic actions.

End the game and award an automatic win when permanent departures or removals
leave only one participant. This does not require reaching the money goal.
Keep the 2-12 starting requirement; solo continuation is only a future option.
A temporary disconnect does not remove a participant or trigger this ending.

After permanent departure, retain actions and effects already applied, including
public board modifiers for their remaining duration. Do not execute future
actions or future triggers belonging to the departed player. An action already
spent is distinct from a new passive trigger scheduled for a later event.

Already-placed bets still settle if their owner permanently leaves; departure
does not cancel those committed bets. The departed player is no longer eligible
to win. If no participants remain, close the game without a winner.

[Define the recipient/accounting of a departed player's settled payouts if any
ownership transfer beyond the host role is intended, and how last-player
termination interacts with any still-pending spin.]

## Room scoreboard and social panel

Current-match standings use each player's net balance (cash minus outstanding debt). The player's
own display should also show how much is available and how much is currently
committed to bets, so a temporary reservation is not confused with a settled
loss.

For deciding a winner, compare net balances after the entire round settles.
Display cash, outstanding debt, net balance, and available cash distinctly.
Equal net balances remain equal; a display ordering must not break a gameplay tie.

The scoreboard columns are Bets won, Money gained, Money spent, Cards played,
and Biggest bet win, in that order, followed by Ping. Match wins are not tracked. It updates during the match, survives reconnects, and resets
when the next game starts. No manual reset is available. Money gained excludes
starting cash and loans; money spent includes paid stakes, purchases, repayments,
fees and deductions. Cancelled bet reservations are excluded.

A bottom-right Scoreboard button and the general Tab shortcut open its modal.
Ping/status appears in the rightmost column. Chat and spectators use the side
panel independently of the scoreboard.

[Decide whether players and spectators share chat, and whether later private
mechanics require communication restrictions.]

## Planned layout and controls

### Board and player areas

Use a different main board for each stage, switching automatically with the
round rather than showing both boards side by side.

During planning, use the classic roulette betting board for public effects,
betting, and Final Preparations. Rewards and Shop need card-choice and purchase
views within planning; these must not imply that betting is already open.
Players place their colored chips on the board during Betting. Bets need clear
ownership, amounts, and enough separation to inspect crowded spaces. Show names
or other identifying markers alongside colors so ownership does not depend on
color alone. The exact spaces must match the chosen wheel and bet rules.

During rolling, replace that board with the roulette spinner centered in the
playing area. List color-coded players around the board, or in groups above and
below the wheel depending on available space. Pair colors with names or labels.
Animate the wheel
rotating and the ball moving until it settles into the result slot. Betting
controls are unavailable during this stage. Keep a summary of committed bets and
balances available so players can follow what the spin means for them.

Keep the local player's money and committed total in consistent locations across
both stages. During planning, group the chosen stake, timer, and readiness control
near the betting board. Show the phase and round result clearly. Other players'
balances and readiness states should not make the active board too small to use.
If the match continues after settlement, restore the betting board for the next
planning stage.

[Choose how stacked chips or several players' bets on one space can be
inspected.]

### Buttons and keybinds

**Provisional controls:** Select a stake amount, choose a bet space, edit or
remove an unlocked bet, and use **Ready up**. Show a round payout summary after
the roll. There is no player-controlled button that chooses the roulette result.

Disable betting changes outside the betting substage and while paused. During a
tiebreaker, only its participating players get gameplay controls. Show card
selection, purchases, public placement, personal card use, borrowing, and
repayment controls only in their permitted windows. Explain rejected inputs
without clearing other accepted bets.

Touch users should be able to choose an amount and tap a space. Keyboard users
should be able to reach the same controls with clear focus and accessible
labels.

[Choose specific keyboard shortcuts after the betting interaction is designed.]

### Screen sizes and accessibility

Give the active stage's board the available playing space: the betting layout
during planning and the spinner during rolling. Adapt each independently to
portrait phones, landscape screens, and larger displays. Keep the money summary,
phase, timer, and primary control readable at each size. Avoid relying on hover
to inspect a bet or on color alone to identify a player or outcome.

Announce phase changes and the final round result without repeatedly announcing
every countdown update. Reduced-motion presentation should still reveal the same
outcome and use the same betting deadlines.

[Choose the detailed phone layout and how a large betting table remains usable
without shrinking its targets or text too far.]

### Art, animation, and audio

The transition to rolling should clearly replace the planning board with the
spinner. Animate both the rotating wheel and the ball, making the final landing
slot clear. The presentation must match the authoritative round result.

During planning, player-colored chips visibly connect placed bets to their
owners. After the roll, identify the winning bets in the result summary and show
each player's gain or loss.

**Provisional:** Use distinct sounds for placing chips, readying up, spinning,
revealing the result, and receiving payouts. Sound and animation should
reinforce the result while leaving it understandable without audio or full
motion.

[Choose the visual theme, music, exact effects, and spin presentation.]

## Action timing and pacing

Each planning substage has its own countdown and reversible Ready up control.
It ends when everyone participating locks in or the timer expires. Betting's
countdown begins only when Betting opens. Accepted bets
are then fixed for that round; an unlocked player does not gain extra planning
time.

Rolling switches the main board to the animated spinner and includes the spin,
result reveal, and complete settlement. Players wait until the betting board
returns and the next Betting substage opens before placing new bets. Check the
win condition after settlement and before opening another normal round.

**Provisional:** Pausing preserves the remaining planning time and accepted
bets. A paused round must not silently advance or pay out while appearing
stopped. Resuming continues the same round rather than opening betting again
after it has already closed.

Several players can bet on the same space; placing a bet does not reserve that
space exclusively. A player's overlapping edits must not spend the same money
twice. Delayed, repeated, or outdated requests must not duplicate a bet, change
a closed round, or apply a payout more than once.

Rolling duration follows the wheel animation.

[Choose any separate result-display duration, settlement input lock, and how
inputs arriving exactly at a substage deadline are decided.]

## Implementation status

The roulette game and its defined card catalogue are implemented for local
GameHub testing. Type Reversal is active; late-entry assistance needs
the separate admission work, and audio/balance testing remain outstanding.

### Game availability

- [x] Implement the individual roulette race for the intended 2-12 players.
- [x] Share the room's 12 places between players and spectators.
- [x] Automatically admit eligible spectators at the next normal round when the
  host allows, using configured late-player balances and entry-card assistance.
- [x] Preserve returning participants' money, debt, cards, and actions; prevent
  new late entrants from joining tiebreaker rounds. Existing tied participants
  can still reconnect.

### Existing configuration

- [x] Add host-set starting money and a money goal.
- [x] Add late-player starting-money overrides (0 inherits normal starting cash).
- [x] Implement single-zero roulette and the supported standard bets and payouts.
- [ ] Decide whether to expose planning time as a host setting.

### Server-authoritative gameplay

- [x] Implement individually timed planning substages and reversible readiness.
- [x] Implement the defined cards, reward timeout choices, and private hybrid shops.
- [x] Implement Type Reversal's numeric and approved utility effects.
- [x] Implement public effects and Final Preparations.
- [ ] Implement late-player balances and entry-card assistance.
- [x] Implement one variable-size loan per round in Shop or Betting, repayments,
  debt-relief cards, and debt-aware win comparisons.
- [x] Validate and account for accepted bets without overspending.
- [x] Resolve a shared spin and settle every bet once.
- [x] Check the goal after settlement and support tied-player extra rounds.
- [x] Implement 60-second pauses on all disconnects and restore accepted actions.
- [x] Implement continued loan access, abstention, and permanent removal.
- [x] Award an automatic win when one participant remains after permanent departures.
- [x] Reset overlapping disconnect pauses to 60 seconds and name the disconnected player.
- [x] Preserve applied departure effects and settle committed bets; suppress new triggers.
- [x] Resume on reconnect, transfer departing-host ownership, and close empty games.

### Client gameplay

- [x] Show personal offers above shared offers, with permanent cards to the
  right of temporary cards; retain the five-temporary/two-permanent offer split.
- [x] Style temporary cards silver, permanent cards gold, and public temporary
  cards with silver borders, muted purple interiors, and Public badges.
- [x] Show money, committed bets, readiness, phase, timer, and results.
- [x] Provide usable betting and readiness controls with keyboard and touch access.
- [x] Provide card drafts, shop purchases, public placement, and Final Preparations.
- [x] Show card-specific values, loans, debt, and repayment controls.
- [x] Hide other hands and shops; show used cards in played-card history; alert only for public card plays.
- [x] Show public standings and the chosen spectator/social features.

### Table presentation

- [x] Show the classic roulette betting board during planning.
- [x] Switch to a rotating roulette wheel and animated ball during rolling.
- [x] Adapt each stage's board for phones and desktops without requiring both
  boards to share the playing space.
- [x] Identify players' bets using colors and additional labels or markers.
- [ ] Present spins and payouts with accessible motion and sound alternatives.

## Open questions and later additions

- Supported: 157 standard single-zero betting spaces; see the betting catalogue.
- Implemented host sliders: starting cash 1,000-200,000 and goal 100,000-2,000,000 in 1,000-unit steps.
- Entry assistance replaces the normal entry draft; returning-player assistance opens at the next reward stage and counts only missed scheduled rewards.
- [Refine the initial card ideas, timing, duplicates, free bets, generation, and conflicts.]
- [Choose empty-stage handling, configurable timers, and extra-draft timing.]
- [Define remaining card-specific debt-relief details.]
- [Define departed-player payout accounting and pending-spin last-player endings.]
- [Define early automatic resume with multiple disconnected players.]

### Deferred possibilities

Keep these ideas documented for later consideration; none is an initial rule:

- Protective Seal (temporary, public): protect one spot from further public
  effects for the round. If added, use an opening protection-placement step
  within Public Buff/Debuff Placement, before other public cards can be placed;
  its usefulness must not depend on who sends their ordinary placement first.
  [Choose the protection-step timing and interaction rules before adding it.]

- Special wheel slots such as bankruptcy, double money, or gifting, with editable
  slot definitions and matching spinner animation.
- Early-round offer or purchase limits and delayed permanent-card access.
- A personal-card play limit in Final Preparations, if unrestricted stacking
  proves too strong; no such limit is applied initially.
- Reduce the base public-card play limit from two to one per player per round
  if balancing calls for it. Keep two as the current rule; More the merrier
  adds its extra play to whichever base limit is in use.
- Debt-relief card use throughout planning instead of only Final Preparations.
- A catch-up card budget as an alternative to the reduced draft.
- Milestone-based late-entry grants as an alternative allocation method.
- Shared-stock shops, auctions, or entirely shared/random selections instead of
  hybrid personal shops.
- High Stakes (temporary, public): mark a betting group before Betting. Proposed
  values give +25% profit on wins and cost 25% extra stake on losses. Keep this
  card deferred; any future version uses the general overflow-to-penalty-debt
  rule rather than requiring an extra-loss cash reserve.
- A round receipt showing stakes, normal winnings, card bonuses, tax, debt
  changes, and final balance, to explain complex settlements.
- Alternative Double or nothing mechanics: an all-bets-must-win condition, a
  called-color condition, or a two-round streak. The chosen version stays the
  50/50 profit gamble. Double Everything is now a separate planned card above.
- A summary explaining the winner's build and synergies.
- Solo play as a possible later expansion; the current game ends with one participant.

Additional card effects, conflict rules, and pricing are deferred design work for
confirmed systems, rather than reasons to omit those systems.

The intended game includes the two-stage round loop and planning substages,
public colored bets, card rewards, hybrid shops, public and personal effects,
loans, limited late-entry assistance, consistent money accounting, a defined
wheel and payouts, debt-aware winning, and tiebreakers. A smaller prototype may
validate the core loop first; that does not remove the confirmed systems.
Measure match length through play; up to about 40 minutes is acceptable.

A possible later addition is an explanation of the winning player's build.
The proposed card effects, synergies, prices, and numerical balance still need
to be refined and tested together.

## Playtest questions

- **Do late-round cards help matches finish?** Check scaling without making
  earlier choices irrelevant.
- **Does the economy resist exploits?** Test loans, shop pricing, entry rewards,
  stake refunds, and loss protection together.
- **Does planning remain engaging with 12 players?** Measure waiting across
  substages and whether Final Preparations preserves meaningful betting choices.

- **Does planning feel useful?** Players should understand their choices and
  have enough time to make them without excessive waiting once ready.
- **Is the rolling stage exciting and readable?** Players should follow the ball,
  recognize winning bets, and understand their final gain or loss.
- **Do players who fall behind still see a route to winning?** Test whether cards
  and loans provide worthwhile choices without guaranteeing recovery.
- **Does the money goal create the intended match length?** Compare different
  player counts, starting balances, goals, and bet payouts.
- **Do ties resolve without dragging?** Extra rounds should remain engaging for
  the tied players and understandable to everyone watching.
- **Does late entry stay exciting and fair enough for this game?** Newcomers
  should have a chance through a risky bet without repeated entry providing
  fresh money to an existing participant. Check whether waiting for the next
  planning stage and the host's admission control are clear.
- **Can 12 players' bets be read on a phone?** Shared spaces and stacked chips
  should not hide ownership, amounts, or essential controls.
- **Do players understand the result?** They should distinguish returned stakes,
  winnings, losses, and why one qualifying player beat another.

### Current prototype board arrangement

The title is followed by players 7-12 when present, then the betting board or
wheel, players 1-6, the phase timer, and the chip/action controls. Chips are
dragged upward onto the board. Lists and important information use a right-hand
panel where space allows. The ball slows into its pocket before the wheel comes
to rest over the following second.


### Current card implementation

The current prototype includes private inventory, timed reward choices, and a
30-second Final Preparations stage after betting. Profit up, More draws,
Double or nothing, Goal Grant, Cash Bonus, Loan Relief, and Debt Reduction are
playable there. Profit Bonus and Profit Cut work in the pre-betting Public
Effects stage; reroll cards work in their respective stages. The remaining
defined catalogue is now implemented, including targeted statuses, passives,
generators, exchanges, theft, negative penalties, and Type Reversal.
A wide bottom dock shares its width equally between chips and a
card fan; portrait stacks them. Cards follow the catalogue groups above, with
one visible card per type and an owned count at top right. Polarity is top left,
name top middle, and effect text beneath. The full hand opens in a scrollable
dialog when the compact fan cannot expose the entire collection.

Card indicators distinguish **Positive**, **Neutral**, **Risky**, and **Negative**.
Neutral cards provide controlled utility or conversion; risky cards introduce
a blind exchange, random removal, a gamble, or a collection-wide reversal.
Within each temporary/public/permanent group, display them in that order.
Sleight of Hand, Double or nothing, Double Everything, Erase, and Type Reversal
are risky; Discard, Trade up, Roll down, White Out, Copycat, Reverse Fortune,
and Relocation are neutral.


Card front layout places the lifetime (Temporary, Public temporary, Permanent)
directly under the name. Effects radiate from the center of the remaining empty
area with generous padding; long effects shrink to fit. Temporary fronts are
metallic silver, permanent fronts gold, and public fronts purple with silver
framing. An etched inner border and diamond ornaments distinguish the faces.
Card-back art remains to be designed.

Card effect categories use prominent colored badges badges: Positive is green with +, Negative red with a minus, Neutral blue-gray with
=, and Risky amber with !. The written label stays visible alongside each
symbol, independently of the silver/gold/purple lifetime styling.

Reward choices have a soft, static category glow: green for Positive, red for
Negative, gray for Neutral, and amber for Risky. Hover or keyboard focus
strengthens the same glow. The reduced-shadows preference disables these
shadows while leaving the labeled badge and border accent visible.

Surface treatment: fine weave on red/black cells and mottled green felt, wood-grain rails with gold
trim, lightly textured linen card stock, and molded poker chips with ivory rim
inserts and concentric rings. Text and exact chip values stay unobstructed.

The wheel hub carries a gold eight-point compass rose within a rounded brass
medallion. Eight gold diamond inlays decorate the brown bowl outside the
number ring, alternating long radial and tangential shapes; each has a point
aimed toward the center. The bowl decoration stays fixed while the hub spins.

Wood rails follow the direction of each side: horizontal grain on top/bottom,
vertical grain on the left/right. Green felt has uneven patches shared across
the board instead of a uniform grid. Curved grain patches follow both brown
wheel rings. Eight diamonds sit just inward of the wood ring's midpoint. Card faces are clipped
inside opaque borders and have irregular patches of shine; the neutral accent
is blue-gray for stronger separation from the card surface.

The colored left-edge stripe is removed from cards; category badges and reward
glows provide category identification. The lowest shine patch is softened and
moved into the face, away from the purple card's bottom edge. Green felt uses
the felt patch layers: connected cross-hatching in irregular shading patches above the
broader mottling, with no runtime noise filter. Eight wheel diamonds sit at
radius 131, just inward of the wooden ring's midpoint.

The felt shading uses connected intersecting diagonal lines, rather than
individual X marks. Each irregular patch has a subtle dark-green radial shade
that fades outward into the base felt. Card shine at the upper left is softer
and more broadly feathered. The texture uses static SVG patterns and radial
gradients; it adds no animated noise or filter work.

The felt uses one broad cross-hatched field spanning the board in both
landscape and portrait. It scales with the board, with feathered elliptical
edges and fixed 9px line spacing, beneath betting cells, labels, and chips.
The temporary SVG texture asset is removed.

The reward picker closes immediately once the server confirms a chosen card,
including timeout choices. Players need not wait in a confirmation window for
other participants; Check cards remains available to inspect their collection.
Unresolved reward choices still cannot be dismissed.

During Rewards, clicking anywhere on a card chooses it; the explicit Choose
card button sits below the card as an alternative. Card-picker gutters leave
room for the full category glow at the top and bottom of the scroll area.

The betting-surface stack is the green base, transparent Egyptian War-style
felt (fine 22-degree fibres, 9px/11px dot patterns, subtle lighting),
cross-hatching, then betting cells and chips. Both texture layers ignore pointer input. The single shading field fits inside the rail and follows both board dimensions. Opaque red/black cells cover the texture underneath.

Cross-hatched shading uses low-contrast 1px lines spaced every 9px. Elliptical
masks fade gradually from the center instead of clipping patches to rounded
blob outlines. No blur filter is applied; textures stay below betting targets.

### First playable personal cards

Final Preparations freezes paid wagers and resets readiness readiness. It lasts
30 seconds and ends early when all contenders ready up; players can undo their
lock until that transition. Pause and disconnect recovery preserve its clock.
Any number of supported personal cards may be played before readying up, except
Double or nothing, which is limited to once per round. Only accepted plays
consume a copy; all players can see the owner and name of each card played.

Profit up adds 20% winning profit per played copy, including winning free bets.
Bonuses are additive and money floors per wager. More draws creates two separate
random legal free wagers, each floor(5% of the player's settled balance when
played), without reserving or spending cash. Free wagers are uneditable and
return only profit on a win, with no loss on a miss. A resulting stake below
one is rejected without consuming the card. For this first implementation,
More draws is played in Final Preparations alongside the other personal cards.

Double or nothing resolves once, after bonuses and net betting settlement and
before winner checks. A separate trusted 50/50 draw doubles positive net profit
or removes it. Zero net profit and net losses are unchanged. Results show both
individual wager returns and the separate gamble adjustment. These effects
expire after this round; unsupported cards remain in inventory without effects.

### Implemented bank controls

Call Bank and Last round results share a row below the player's wallet. The bank modal has separate loan
and repayment sections. Quick buttons choose 25%, 50%, 75%, or all of the
current allowed amount; a draggable slider and exact whole-number input below
stay synchronized. Loan terms show principal, floored 25% fee, and total debt
before confirmation. The modal can be closed, and the game clock keeps running.

Loans are available once per round during unlocked Betting. Repayment is
available during unlocked Rewards, Betting, and Final Preparations, limited to
outstanding debt and unreserved cash. Oldest outstanding loans are paid first;
records retain their original amounts for future debt-relief effects. Full
repayment does not reset that round's borrowing allowance. No recurring fee is
charged, and unpaid debt does not block next round's loan. Automatic full
repayment occurs after settlement when net balance still meets the goal;
results identify this cash payment separately from gambling profit.

Loan history is private; debt and net balance appear with player cash balances.
Reconnect preserves all records and round eligibility within this match.
The bank panel has a separate decorative shell for possible future artwork:
a shark opening its mouth with the modal inside. Artwork is not implemented yet.

Betting uses the board directly by clicking or dragging chips onto its targets.
The separate betting-space dropdown and Place selected bet button are removed.

### Approved shop presentation and first implementation

Use a striped booth with a perspective canopy, rear-aligned poles concealed
behind its roof, and rounded lower joins. Keep the centered cream wooden SHOP
sign and its short description separate from the dark-green display. The
section order is SHOP, DEALS, REGULAR. Preserve the seven-offer personal/shared
split above, and add one extra personal deal above them. The discount is drawn
uniformly from whole percentages 25 through 75, once per refresh. Deal type
weights are temporary/public 6, permanent 1; individual rare cards keep 1:6
selection weight within their type.

Fit the complete booth and its separate, free-standing wooden A-frame
sandwich-board preview to roomy windows. The board shows the selected card,
its price, and a purchase button, with short vertical front legs at the frame's
two outside corners. On compact or short-height screens, hide the board and
open an enlarged card dialog when an offer is selected. Keep offer cards
compact, with prices underneath and double-click purchasing. A bottom bar holds Cash / Debt / Net,
Call Bank, and Ready up. Ready up becomes Cancel ready while ready;
no Close button or closing-to-lock behavior. Opening the bank retains the shop
beneath it. Purchases, rerolls, and borrowing are unavailable while locked or
paused. The host retains an in-shop Pause/Resume control.

Shop starts after Rewards from round 2 onward and lasts 30 seconds; round 1
stays ordinary roulette. It closes on all-ready or timeout without inventing
purchases. Each refresh supplies independent offer identities and one purchase
per offer, enforcing permanent ownership caps. Shop Reroll refreshes every
owner slot including the deal and originally shared selections; it consumes a
card without changing anyone else's stock.

**Provisional pricing formula:**

```text
scale = 2 * starting cash + 2 * max(0, average net balance) + goal / 2
raw price = scale * card rate * rarity multiplier
```

Use 1% for temporary/public cards, 3% for permanent cards, and a rarity
multiplier of 2 for rare cards (1 otherwise). Round the raw price to the nearest
whole unit below 20, or the nearest multiple of 5 otherwise, with a minimum of
1. Apply the deal discount to the rounded base price and round it the same way.
The exact displayed integer is charged. This shop-price rounding is an
exception to flooring other money calculations.

At 50,000 starting cash, a 100,000 goal, and 50,000 average net, temporary cards
cost 2,500 and permanent cards 7,500 before rarity and deals. If average net
reaches 100,000, those prices become 3,500 and 10,500 in the next Shop stage.
At default settings with 100,000 average net, base prices remain 9,000 and
27,000. Round-number and individual-card adjustments remain future balancing
work. Unsupported effects remain clearly marked Preview when purchasable.

### Reward rerolls and stage hand access

Provide Check cards in both the Shop footer and Reward picker. The reward hand
returns to its required picker on Back to rewards or Escape, rather than
allowing that draft to disappear. Shop hand inspection preserves the booth.

Reward Reroll (working name) consumes one already-owned temporary card before
its owner chooses a reward. Replace that owner's draft only, preserving choice
count, lifetime, caps, rarity weighting, and remaining timer. Avoid old choices
when enough eligible alternatives exist. If the pool is too small, retaining
some old choices is allowed to keep a complete eligible draft. Repeat uses
require further owned copies. Newly acquired copies cannot be used to undo
the reward that granted them. Timeout selection uses the current choices.

Possible alternative names: Fresh Deal, Second Look, Choice Shuffle, Redraft,
or New Prospects. Shop cards use click selection on the side sign, with a
full-size inspection dialog for compact screens and keyboard access.

The current shop side sign follows the clicked card, not the hovered card. It
hides on portrait or constrained viewports, which use a full-card inspection
dialog. The selected deal displays its percentage-off badge on the sign frame.
Cards have prices underneath and a Buy card button only on the detail sign: double-click or
double-tap to purchase; Shift+Enter is the keyboard equivalent. Shop Reroll, when
owned, appears to the left of the other shop action buttons.


### Implemented Public Effects stage foundation

The current build includes the 30-second Public Effects stage after Shop and
before Betting from round 2. It supports its own timer, reversible readiness,
hand inspection, and existing pause/reconnect behavior. Round 1 skips it.
Profit Bonus and Profit Cut are now playable here, up to two public cards per
player per round, extended by More the Merrier when available. Targeted public effects are active with private target choices and visible status markers. This stage does not yet add the planned
Protective Seal placement window or public-card limits.


### Implemented cash, relief, and public profit cards

Profit Bonus and Profit Cut add global +/-30% winning profit for one round,
including free bets. They add to personal Profit up, cancel equally, and cannot
reduce normal winning profit by more than 80%. Committed public effects survive
their owner's departure and reset next round. More the Merrier is not active yet.

Goal Grant, Cash Bonus, Loan Relief, and Debt Reduction are played during Final
Preparations. Grants add floored cash immediately, based on goal/20 or current
cash/10. Current cash includes reserved stakes. Relief forgives debt without
spending cash: half the latest original loan debt capped by its unpaid balance,
or a floored fifth of all unpaid debt, oldest first. A relief card with no
whole-unit benefit is retained. Latest-loan relief never clears earlier loans.
Cash Bonus is retained when cash is below 10. Normal winner checks occur after
settlement, including for a goal reached by a grant or debt relief.


### Card-play feedback

Public cards share an initial pop onto the playing board, drawn in a separate
layer above the board so the card looks like it lands on the felt. Whole-board
public effects fade after the pop. Cards targeting a betting spot then
have an additional placement animation, sliding/shrinking to the selected spot.
The target-placement presentation is supported; targeted public card mechanics
remain to be implemented. Feedback follows confirmed plays and never delays
server resolution. Reduced motion uses a brief stationary card presentation.


Owned cards playable in the current Public Effects or Final Preparations stage
can be dragged out of the hand/collection and dropped onto the board as an
alternative to Play card. Only a confirmed play activates the card animation.
Canceled, outside, or rejected drops leave the card unspent. Spot-targeting card
rules now use private target choices or a straight-up board drop; global/personal cards accept any board drop.


Public card animations are shared by players and spectators and temporarily hold
the Public Effects countdown. Only one public card is accepted at a time; the
next play becomes available after the animation. Remaining stage time is
preserved, including across manual/disconnect pauses. Personal cards and rerolls animate only for their owner, without play-alert popups. Shop sold-out status
uses a gold stamp running diagonally from bottom left to top right on the card.

Stage changes into Public Effects, Betting, and Final Preparations use a brief
full-width announcement ribbon. It signals the current activity without
blocking controls or delaying the game, with stationary reduced-motion feedback.


### Defined catalogue implementation and provisional defaults

All catalogue cards are implemented, including Type Reversal's approved
numeric and utility effects. The active implementation
uses these defaults for previously open details; they are adjustable after
playtesting:

- The acquisition round counts toward held-round profit; match-round profit
  uses the current shared round. Debt-Free Dividend checks unpaid debt at
  settlement. Specialist copies are assigned individually through Check cards
  during planning and cannot be configured after the spin starts.
- Third times the charm counts betting rounds only while owned. Betting opens
  with a fixed cash snapshot; on each third betting round, total paid inputs
  must fit the 20%-per-copy free-stake budget (maximum 100%). All accepted inputs
  in that budget become free after Betting; card-created free bets do not advance
  the count. Abstention does not advance it either.
- More cards and More choices trigger every second round after acquisition with
  one copy, every round with two. More cards draws one extra card independently
  (permanent versus temporary weight 1:6); More choices affects only Rewards.
- More the Merrier permits one extra public play. Using the extra play starts a
  one-round cooldown; two copies remove it. The live public limit is shown in
  the instructions and enforced by the server.
- Patient Investor grows after a no-purchase round, including its acquisition
  round, pauses on purchase, and retains growth while owned. Discarding and
  reacquiring resets its growth. MinMax multiplies positive card bonuses, not
  ordinary roulette profit, using exact fractions until whole-money settlement.
- Cashback refunds losing paid stakes individually: 20% per copy, capped at
  100% of that stake. This avoids paying a whole-round refund repeatedly for
  each tiny losing bet. Free bets cannot generate paid-stake refunds.
- Cold Streak triggers on the first positive-net betting round, assessed before
  its own reduction and profit gambles. Short Changed instead applies to winning
  bets during the next round only, even if other losses make the whole round
  unprofitable; it expires after that round regardless of wins or suppression.
- Paperwork/Shop Closure/Public Silence first apply in the next planning round;
  Collection Notice charges after that next round. Forced Sale can be resolved
  by choosing another owned card during that round's Final Preparations; its
  timeout fallback discards a random eligible other card. Limited Selection
  affects the next draft, and Bad Investment the next purchase.
- Suppression holds unresolved negative cards without consuming them. It does
  not refund costs already paid. Fees snapshot cash after settlement and taxes;
  multiple personal charges never spend reserved wagers. Uncovered extra losses
  become penalty debt without another loan surcharge or borrowing allowance.
- Bounty, Targeted, Parking Tax, and normal Cross out can target any exact betting spot. Cross out blocks only that selected spot; all other wagers remain legal. Crowd Favorite and Lone Wolf remain number-only. White Out/Erase
  remove attached statuses but never global modifiers. Reversal applies only to
  signed spot-profit modifiers. Copycat creates a new independent copy owned by
  its player. Public plays resolve in acceptance order.
- TAX triggers at or above 10% of the goal. All tax claims are evaluated before
  transferring money; incoming tax income is never taxed. Proportional 50% caps
  floor each claim separately. Departed owners receive no future tax income;
  other committed public statuses remain until the round ends.
- Temporary-card theft includes public temporary cards, never permanent cards.
  Blind choices have opaque IDs, shuffled backs, and no hidden card names.
  Sticky Fingers reveals at most two private choices and spends its source at
  reveal; its remaining choice is mandatory. Trade up spends its source and
  input before showing its fixed permanent offers. Unfinished paid choices
  resolve at the phase deadline, preventing cancellation from becoming a free
  peek or reroll. An unspent targeting action can be cancelled freely.
- Interceptions resolve in placement order; at most one steals a chosen
  temporary draft reward. All competing claims expire on that draft. Reclaim
  requires a recorded theft and a still-held temporary card. A spent/retraded
  stolen copy cannot be reclaimed through its former theft link.

The initial catalogue values remain balance candidates. Late participation and missed-reward catch-up are implemented alongside Type Reversal.

Targeted public animations reserve 1.55 seconds for the full pop and placement; global public cards reserve 1.4 seconds. Negative temporary cards keep their acquisition timing when stolen or exchanged.

If a paid theft target spends a revealed card before selection, keep only the still-eligible original choices. If none remain, close the choice immediately; otherwise let the player choose from those remaining. Do not reveal replacement cards or refund the paid reveal cost.


### Direct card targeting and shared theft hands

Player-targeting cards highlight the eligible player cards already seated above
and below the board. Eligible betting spots are highlighted directly on the
board for public targeting and Specialist assignments; click or keyboard
activation submits the server-provided opaque option. An on-screen prompt
allows cancellation before spending an uncommitted source card.

Interactive blind theft uses a shuffled fan floating over a darkened screen,
without a surrounding box. The selecting player sees identical card backs;
the hand owner sees their own card faces in the same order and cannot select
or cancel the other player's action. Only those two participants receive this
presentation. Spectators and uninvolved players receive no hand or options.
Hidden identities remain in the server's option map. Reconnect preserves the
same choice and order; completion, cancellation, or phase expiry removes it.
Cards explicitly described as random theft retain their automatic random picks.

The approved design has a white frame, outer checkers fading toward a dark
center, an unpatterned diamond medallion, and surrounding fine lines that soften
toward the edges. Its colors follow the hand owner's public player color. Every
card in a hand uses the same back regardless of kind, polarity, or rarity.
The player-color palette is defined in src/session.ts; card backs use those same colors.


### Player-colored card backs

Card backs automatically use the hand owner's public player color. Every card
in that hand uses the same checker pattern, fading lines, white outer border,
and center diamond, regardless of its kind, polarity, or rarity. During theft
the selecting player sees the other player's color, matching that player's seat
and chips. The hand owner still sees their own card faces. No style dropdown,
extra saved setting, or rule/preset change is needed.


### Card face presentation

Temporary cards use silver faces with a faint checker texture and nested
four-point diamonds. Public cards use purple faces with diagonal slashes and a
framed diamond. Permanent cards use gold faces with cross-hatching and a central
four-point diamond surrounded by eight smaller copies of that same symbol.
Watermarks remain behind the effect text. Category badges, centered names,
card types, and duplicate counts retain their roles; serif headings and etched
frames distinguish the face from its player-colored back.

The approved styling is shared across rewards, shops, hands, inspection,
private selection, and play animations. Compact hand thumbnails keep reduced
padding and typography, and long effects retain automatic text fitting.
The two temporary design preview HTML files have been removed.


### TODO interaction, first-round, and presentation update

Player and spot targeting now darkens the viewport with holes over the actual
eligible controls. Dragging a card to the board starts its choice flow; it does
not silently select the drop location. Animation and source-card consumption
follow the confirmed choice. Bounty, Targeted, Parking Tax, and normal Cross out
accept all betting spots, including outside and combination wagers. Effects
apply to that exact space ID. Crowd Favorite, Lone Wolf, and reversed Cross out
(Free Entry) remain number-only. Copycat and Relocation preserve the original
effect's destination restriction; Specialist can choose any betting spot.

Round 1 goes directly from Betting to Rolling and settlement. Rewards, Shop,
Public Effects, and Final Preparations begin in later rounds. Both timeout and
Ready transitions use this sequence.

Default shortcuts: E checks cards, B toggles the bank, F opens last results,
1-5 select the standard chip amounts, 6 selects Max, and R toggles Ready up/Cancel ready. GameHub provides editing and
persistence for these bindings. Optional panels and required choices guard
against accidental actions behind dialogs.

Winner popups appear to every viewer with the winner's name, net balance,
and up to three most-used effects with actual resolved-use counts. These are
usage highlights, not a claim about monetary value; interactions between cards
make exact contribution rankings unreliable. No hands are revealed before the
match ends.

Original package-owned WAV effects cover wheel/ball movement, confirmed card
plays, hand-only hover, purchases, stage entries, bets, target choices, and wins.
A quiet original music loop uses GameHub's music category; effects use its game
volume category. Rolling cues are short and cease scheduling on pause or hidden
tabs. Music assets live in `public/assets/audio/music/` and sound effects in
`public/assets/audio/effects/`. Reproduce both folders with scripts/generate_audio.py. Audio still needs listening
on real devices for subjective volume and tone feedback.

The bank uses a plain modal with immediate opening and closing. Decorative shark
art and jaw animations were removed. Further bank/shop visual redesign remains pending.

The current player palette also colors draggable chips, drag ghosts, placed 3D
stacks, player seats, and card backs. Red and gold are softened; turquoise and
chartreuse are slightly less intense. Near-white and gold chips use dark inserts
so alternating edge sections remain visible.


The match ends with a three-second winner announcement over the board showing
only the winner and net balance. Everyone then returns to the lobby, where a
separate review shows the winner's most-used cards and their resolved use counts.
The review may be closed and is dismissed automatically when another game starts.
These are usage highlights, not estimates of each card's monetary contribution.


Specialist assignments are mandatory after Shop: an acquired unassigned copy
opens board selection as soon as no other choice is pending. Cancellation is
unavailable; a stage timeout assigns an eligible spot automatically. The free
coverage from Third Times the Charm does not limit paid wagers above that
coverage. Round receipts distinguish base returns, card adjustments, taxes,
fees, and debt repayment; repaying debt never reduces a bet's recorded return.


Alternating passives show private activation alerts: Third Times the Charm at
Betting start (with its exact free-coverage or reversed extra-charge allowance),
More Cards when it grants/removes a card, More Choices on its active drafts,
and More the Merrier when its extra/reversed public play is available. Constant
profit bonuses do not generate repeated alerts. Simultaneous notices are grouped
and repeated snapshots or pause/resume do not replay them.


The recipient privately sees the exact card obtained from blind and random theft.
A short back-to-front reveal shows the card name/effect and previous owner, then
fades; multiple received cards reveal in sequence. This is a receipt, not a card
play: it does not consume or activate that card. The transfer receipt remains
available even if a received negative card immediately activates and discards.
Victims retain their selected-card exit animation; spectators see neither private
receipt nor reveal. Reduced motion shows the face directly, and old receipts are
not replayed on initial mount.


Unanswered choices from reversed Go Fish or Sticky Fingers automatically select
one still-eligible offered card when the current stage timer expires. The server
performs the transfer and issues the same private reveal receipt as a manual pick.
The recipient cannot cancel the committed choice; pausing preserves its remaining
time. If no offered card remains eligible, nothing is transferred.


Playing a card with no further choice keeps the inventory open. A confirmation
inside the inventory shows the server-confirmed card name and effect, while its
board animation stays behind the inventory. A rejected action never shows success.
Cards requiring a target or continuation still close the inventory to expose the
board/choice interface. Phase changes also close it as before. Received-card reveals
remain separate private feedback rather than being mistaken for played effects.


Enlarged hover inspection is limited to the bottom hand fan. A one-second hover
or keyboard focus shows a readable full-size card without opening the inventory;
leaving the card dismisses it. Inventory, shop, reward, and theft-selection cards
do not create this extra hover overlay. Touch interaction remains unchanged.


The final 750 ms of Rolling is a stopped-wheel reveal before settlement. The
ball and rotor finish their motion, the winning pocket is highlighted, and
balances remain unchanged during that interval. Only then does Results apply
winnings, deductions, and debt repayment. This hold is included in the existing
Rolling duration and follows pause/resume; short test spins use a scaled hold.


Double or Nothing uses the existing winning-bet result boxes, with an explicit
"WIN, then Double or Nothing WON/LOST" outcome and a round-profit explanation.
It does not add a separate result box. Winning boxes replace the gain line with the gamble explanation,
while the round summary reports the final result and gamble outcome. The gamble still applies once to the round,
not separately to each displayed wager.


Result boxes show bet amount, roulette return, total gain, and the base-return/
card-effect breakdown. When Double or Nothing applies, its win/loss explanation
replaces the total-gain line. Final round net stays in the main summary, green
for a gain, red for a loss, and neutral for zero.


A lost Double or Nothing displays: "This bet won, but you lost Double or Nothing.
Your round profit was removed." The final net, including separate taxes or fees, remains in the round summary.


#### Selling and reserved offers

Quick Sale is a one-use planning utility and may sell negative cards before their
unresolved effects occur. Reseller is a permanent Shop-only ability: use Sell cards
in your card inventory during Shop, select cards, then click Sell selected to sell currently positive, neutral, or risky cards. A consumed or
already-played card cannot be sold. Each sale removes one owned copy. Quick Sale
reserves its own source copy, so it cannot sell itself. Reseller may sell itself,
which immediately removes access to further sales.

Both pay half the estimated ordinary shop price, rounded down to whole cash,
using the Shop's frozen average-net economy. Deal discounts, Cheapskate, and other
personal purchase modifiers do not change sale quotes. Reseller sales and Quick
Sale do not trigger Clean Slate or Shopping Spree. Reversed Quick Sale sells a
random card but still pays cash. Reversed Reseller charges the displayed quote;
any uncovered charge becomes penalty debt under the existing rules.

On Hold reserves one unsold, unblocked offer for the next Shop, including its
current displayed price and discount. The current offer becomes unavailable. The
reserved offer uses one existing slot in the next Shop, so stock stays at eight;
its price survives rerolls. Buying it clears the reservation; otherwise it expires
when that Shop ends. Reversed On Hold schedules one random blocked slot for the
next Shop, and the block persists through rerolls for that stage only.

The new flat/growth permanent bonuses are limited to one copy. Split Decision
and Street Hustle apply only to their named inside-bet categories. Clean Slate
counts voluntary removals through Discard, Trade up, or Roll down, evaluated with
the removed card's current polarity. Good Standing counts actual manual repayment
once per round, not automatic repayment or forgiveness. Publicity counts committed
public-card plays and resets its round contribution with the existing round state.
Type Reversal changes these numeric bonuses' signs without resetting accumulated
progress. Reassignment is neutral and moves one existing Specialist assignment;
it grants neither another Specialist copy nor another bonus.


### Next-round membership and catch-up implementation

Allow next-round joining is a host setting selected before starting the match.
Connected room spectators are admitted automatically at the next normal round
before reward drafts. No admission happens mid-stage, during a winning result,
or during tiebreakers. Existing room lock/approval/capacity checks still govern
who can become a room spectator. Hosts running older GameHub builds without the
optional admission service keep spectators read-only.

Late-player starting balance is a whole-number slider from 0 to 200,000 in
1,000-unit steps; 0 inherits the ordinary starting balance. Admission never
changes returning-player cash, debt, cards, progress, or borrowing history.
All drafts are private and reuse the normal reward picker; rerolls retain the
current draft's temporary/permanent type, including during catch-up queues.
