# Loaded Roulette Implementation Plan

This plan supports [the game design](design.md). It describes planned work,
both implemented prototype behavior and remaining planned work. Last reviewed: 2026-11-01.

## Current scope

The basic roulette prototype is implemented: a 157-space legal single-zero bet
catalog, paid-stake reservations and edits, reversible readiness, 60-second
betting, a six-second shared spin with a private result until landing, payouts,
five-second results, qualifying-leader/tie handling, pause/recovery, and stable
reconnect ownership. The browser supports selecting/dragging chips, exact custom
stakes, proportional stacks, physical seam targets, and native focusable board buttons.

Private card inventory, duplicate stacks, and timed reward drafts are implemented.
Public Effects and Final Preparations are implemented, with active public
profit modifiers and personal profit, free-bet, cash, and debt-relief effects.
Bank loans/repayments, shops, and both reroll cards are implemented. Targeted
public effects, passives, automatic negative penalties, generators, private
theft/trade choices, and Type Reversal are implemented. Late-entry admission remains planned.
The package stays private and is installed as a reviewed local tarball in the
normal GameHub build for testing. Existing approved money sliders remain.

The initial six/two/five-second presentation timings, waiting for all missing
players before early auto-resume, and the departure policy in README.md are
explicit prototype decisions rather than silently settled final design rules.

## Source responsibilities

Start with a few modules; extract more only when their responsibilities grow.

| File | Planned responsibility |
| --- | --- |
| `src/definition.ts` | Real roulette settings, approved bounds, rules, input actions, and manifest. |
| `src/session.ts` | Authoritative match state, phase transitions, actions, lifecycle, and completion. |
| `src/roulette.ts` | Pocket definitions, approved bet catalog, result matching, and base payouts. |
| `src/economy.ts` | Cash reservations, loans, debt, settlement receipts, and integer calculations. |
| `src/cards.ts` | Card definitions, instances, eligibility, effect hooks, and shop/reward generation. |
| `src/visibility.ts` | Viewer-specific snapshots and private pending choices. |
| `public/client.js` | Mounting, phase views, input, snapshots, and cleanup; split board rendering when needed. |
| `public/template.html`, `public/style.css` | Betting layout, centered wheel, player areas, cards, and responsive controls. |
| `src/*.test.ts`, `test/` | Pure rules, session timing, privacy, browser behavior, and package tests. |

Use server-owned pocket definitions for both outcomes and wheel presentation.
The initial wheel has 37 single-zero pockets. Keep IDs separate from visual
positions so a later custom wheel does not require rewriting payout logic.
Custom slots remain deferred; do not enable them as part of the initial rules.

## Authoritative state

Each match needs a match ID, round, phase ID, state revision, participants,
ready players, deadline/remaining time, committed bets, public effects,
roulette outcome, and settlement status. Tiebreakers keep an explicit eligible
participant set and admit no new participants.

Each participant needs a stable match-local ID mapped to the current member ID,
assigned color, cash, reserved stakes, loan records, outstanding debt, borrowing
round, card instances, shop inventory, reward choices, and missed-reward tracking.
Reconnects remap membership without recreating resources. This is in-memory
match identity, not an account or persistent user database.

Card instances need their own IDs, owner, definition, acquisition round,
card-specific counters, cooldowns, and stored references such as a particular
loan. Never represent two owned copies as the same mutable instance.

Use whole-number money and explicit integer ratios. Validate safe bounds before
accepting settings or amounts; use exact intermediate products where needed and
floor monetary fractions before returning bounded JSON numbers. Keep the
explicit catch-up rounding-up rule separate. Negative cash is forbidden;
card-caused uncovered deductions become penalty debt under the design rules.

## Phases and deadlines

The normal sequence is Rewards -> Shop -> Public Placement -> Betting -> Final
Preparations -> Rolling -> Settlement. Round 1 skips card-related substages.
Planning substages default to 30 seconds each, except Betting at 60 seconds.
The wheel duration must be chosen before animation and synchronization are built.

Use one session-owned phase timer. Store a deadline based on `context.now()`;
pause preserves remaining time and resume reinstates that time. A phase advances
once on expiry or all-ready. Readiness can be undone only before advancement.
Spectators do not count toward readiness. Connected reward timeouts choose an
offer randomly; disconnected players receive no automatic reward.

Every mutation checks the match/phase identity, role, membership, connection,
readiness status, resources, target, and payload. Include a request ID and retain a
bounded per-player duplicate-result cache so retries cannot spend or settle twice.
Discard and trading cards are explicit exceptions to ordinary phase restrictions,
as the design allows them at any time before their target's penalty resolves.
A late request cannot reopen Betting or replace a committed roulette outcome.

## Bets, loans, and settlement

Reserve paid stakes when accepted. Changing or removing an editable bet adjusts
its reservation atomically. Free bets reserve no money and pay profit only;
normal paid wins return their stake plus profit. Validate legal spaces against
the approved bet catalog, including zero's exclusion from outside bets.

Choose the roulette pocket once through `context.randomInteger()` when Rolling
begins. Keep it private until the reveal. Start clients with an outcome-free spinning
animation, then reveal the pocket for the final landing segment. Client animation
completion cannot authorize payout.

Settle once using the design order: additive modifiers, explicit multipliers,
profit gambles, taxes, debt changes, then winner checks. Preserve the 80% profit
reduction limit. Compute tax claims from the same pre-tax values, apply the 50%
round-profit cap and proportional floors, then net opposing transfers. Do not tax
returned stakes or incoming tax transfers.

Track each loan separately. Borrowing is allowed once per round during Shop or
Betting; the provisional principal cap is 25% of the goal and surcharge 25%.
Repayment and relief never restore that round's borrowing allowance. Penalty
debt is separate from loan principal and creates no borrowing surcharge.

Record a settlement receipt internally, even before choosing its final UI, so
refunds, modifiers, taxes, and debt changes can be tested without circular sums.
Compare balances after required debt repayment. Tied highest qualifying players
continue alone; permanent departures leaving one participant award that player
a win. No remaining participants ends the match without a winner.

## Cards, rewards, and shops

Implement effects through a small set of settlement/phase hooks rather than a
separate conditional branch for every card throughout the session. Each card
definition states its timing, target, copy limit, rarity, and required snapshots.
An accepted play or trade consumes/transfers its instances atomically.

Round 1 has no reward; rounds 2 and 3 give temporary cards, round 4 permanent,
then repeat. Shop inventories are private and independent. Preserve seven offers:
three shared-selection plus two personal temporary offers, and one shared-selection
plus one personal permanent offer. A purchase marks that offer sold out; a reroll
creates new offers only for its owner. Ownership caps still apply.

The phase registry must cover public placement limits, permanent triggers,
automatic negative temporary effects, personal Final Preparations plays, and
anytime discards/trades. Removing a held negative card stops future penalties,
not charges already applied. Card-specific counters and loan references survive
round changes and reconnects.

Blind hand theft uses shuffled opaque selection handles, not exposed card IDs
that can be tracked across public reveals. Sticky Fingers reveals choices only
to its acting player. Interception targets a future reward and does not require
cards currently in the target's hand. Revalidate targets when an action commits;
concurrent discard, trade, or theft must not duplicate or spend the same card.

## Privacy and platform integration

`getPublicState(viewer)` can already return different state per viewer. Public
snapshots include identities/colors, public bets, phase/timer, public effects,
results, and standings. Include a hand, personal shop, reward choices, or private
peek only for its owner. Spectators receive public information only.

`context.emitEvent()` currently broadcasts to active viewers. Do not put private
cards, shop contents, or peek results into that channel. Deliver private choice
updates through viewer-specific snapshots; public card-use notices expose only
information the design says to reveal. A private-event SDK addition is not
required to implement the initial game this way.

The missing platform capability is mid-match spectator admission. GameHub owns
room roles and the active-player set, and the current SDK offers no generic
admission method/hook. Add an opt-in host operation and matching game hook before
enabling late entry. The hub must atomically update membership and notify the
session at an approved phase boundary, enforce the combined 12-person room cap,
and preserve reconnect tokens. Do not let game code mutate hub internals.
Existing games keep their current behavior when they do not opt in.

Use GameHub's existing host transfer, presets, input, and mounting services.
Keep session-specific phase timers inside this game initially. New optional SDK
capabilities must be reflected in peer/dev versions and verified with a packed
consumer before enabling integration.

## Reconnects and departures

Every disconnect starts or resets the game's 60-second disconnect pause. Keep
manual host pause intent separate so automatic expiry cannot undo it. Preserve
committed actions, borrowing allowance, debt, cards, and bets. Do not invent
missed purchases, card plays, or bets when continuing without someone.

Late-entry assistance derives scheduled temporary/permanent counts from the
round and halves each with rounding up. Returning participants keep their
resources and receive assistance only for rewards actually missed. Record which
missed intervals have been claimed to prevent repeated reconnect grants.
The entry-round replacement draft remains provisional until confirmed.

On permanent departure, retain committed effects/bets for their prescribed
resolution while disabling future owner triggers and winner eligibility.
Use `context.finish()` for game completion; room ownership and cleanup stay with
the hub. Never implement a second independent host-transfer timer in the game.

## Browser behavior

Render one main board at a time: betting during planning, the centered wheel
while rolling. Keep balances, phase, and primary controls stable during the
switch. Show personal shop rolls above shared selections, permanent cards to
the right, and the agreed silver/gold/purple card styling.

The browser renders server snapshots and submits intents. It must not infer
private opponent cards or calculate authoritative outcomes. Announce phase and
result changes without repeatedly announcing countdown ticks. Reduced motion
must preserve outcome and input deadlines. Remove input subscriptions, timers,
observers, animations, and pending-choice UI on destroy; late replies must not
notify or mutate a replacement game.

## Implementation milestones and verification gates

1. **Roulette and economy core:** approve the initial bet catalog, implement
   result matching, reservations, paid/free payouts, debt, and integer rounding.
   Verify every supported bet and ledger conservation with pure tests.
2. **Playable round prototype:** replace balance-increment state with timed simultaneous
   betting, ready/cancel ready, one outcome, settlement, pause/resume, and winner/tie
   handling. This validates the core; it is not the complete designed game.
3. **Private progression:** add card instances, reward drafts, hybrid shops,
   loans, relief, and viewer-safe state. Verify duplicate requests, copy limits,
   borrowing allowance, and player/spectator information isolation.
4. **Card interactions:** implement the agreed catalog, public effects,
   personal preparation, theft/trades, negative effects, and settlement hooks.
   Test additive/multiplicative order, tax caps, generation, refunds, and races.
5. **Membership lifecycle:** implement the opt-in hub admission contract and test
   next-round entry, catch-up accounting, reconnect remaps, departures, host
   transfer, tiebreaker exclusion, and no duplicate resource grants.
6. **Presentation and release:** complete the two board views, synchronized
   wheel/ball animation, readable 12-player betting, keyboard/touch controls,
   accessibility, and audio. Run full multiplayer sessions, packed-consumer
   checks, clean installs, and real-device playtests before enabling the game.

Keep each milestone small enough to review and retain the existing lifecycle
regressions while replacing their balance-increment-specific expectations.

## Decisions needed before their affected milestone

The design remains authoritative. These unresolved choices must be answered
before implementing the relevant feature rather than silently filled in here:

- Supported bet spaces/payout catalog and whole-number host-setting bounds.
- Shop pricing, remaining rarity/copy limits, and each card's money snapshot.
- Public-effect ordering, competing theft/interception resolution, and the
  remaining refund/gamble interactions already noted in the design.
- Early resume with several disconnected players and returning-player draft
  timing, including missed extra-card triggers.
- Departed-player payout accounting and pending-spin last-player endings.
- Permanent-effect visibility, detailed phone betting layout, and wheel/result
  presentation durations. Protective Seal remains deferred pending its own
  protection-first placement decision.

## Verification already completed

The initial pure-helper and placeholder tests have been replaced/extended with
real catalog, session, and DOM coverage. Current type checks and 270 tests cover
157 legal targets, all pocket payouts, zero exclusions, validation, reservation
accounting, duplicate/stale requests, pause/deadlines, hidden outcomes, once-only
settlement, ties, reconnect IDs, departed winners, chip drag/click, exact custom
values, stack boundaries, spectators, and teardown.

Real Edge checks at 390x844 and 1366x768 exercised click-to-bet and actual pointer
dragging onto seam/intersection targets, then locked both players, revealed the
server result, and checked settlement without browser errors or horizontal
overflow. Normal GameHub/Docker integration and multiplayer smoke checks are
verified separately before handover. Physical-device touch/performance testing
is still needed.

The basic betting renderer fits one complete table into the available viewport.
It transposes grid coordinates on orientation changes without rotating labels or
replacing betting targets. Outside bets share the number grid; seam positions
are recomputed from cell bounds. Only supporting ledgers/details can scroll.

Fitted-board checks at 360x640, 390x844, 844x390, 768x1024, and 1366x768
confirmed no page/table scrolling, all 157 targets within the viewport,
integrated outside cells, and upright labels across orientation changes.

The play column is ordered as excess seats (7-12), board/wheel, seats 1-6,
phase timer, and chip/readiness controls. The upper row hides when unused.
The information panel stays on the right in landscape and below in portrait. Player rows share six equal cells without horizontal scrolling.

Wheel motion uses one elapsed-time trajectory, including pause/resume. The
server reveal begins the two-second landing segment: the ball eases into its
pocket over the first second, then follows the wheel through one second of
braking. The reveal does not immediately announce the winning number. The
existing six-second server settlement deadline and reduced-motion behavior stay
in effect. Regression checks cover capture continuity, pocket alignment, and
braking speed, alongside twelve-seat ordering and bottom chip placement.

Loaded Roulette uses the same scoped, safe-area-aware outer-frame rules as
Egyptian War. The shell fills available height and caps width at 100rem, so
large-window margins contract before the game width shrinks. CSS owns frame
dimensions; the client only positions cells and seam targets within that frame.

Compact-width and short-height layout switches have been removed. One clamped
size unit scales spacing and controls from both viewport axes; board-container
units scale labels and seam targets from the actual available board space.
Chip selection uses the same two-row layout in both orientations. Only the
intentional portrait/landscape structural reflow changes the board arrangement.
Browser resize checks cover the former 650px and 450px thresholds on either
side and confirm continuous dimensions without page/table scrolling.

The wheel's colored pockets now end at radius 118 in the 320-unit SVG, with a
separate outer ball orbit at radius 137. Capture moves the ball inward by 47
units into its pocket. An 800ms acceleration ramp makes startup visible before
cruising and the existing capture/braking sequence; server phase duration and
settlement are unchanged. Portrait caps the board at 58dvh and reserves larger
controls and a taller information area.

The header offers GameHub an optional settings slot beside the game actions.
GameHub moves its existing settings control there and restores it on exit. The
connection dot and ping use GameHub's existing socket status and latency events,
matching Egyptian War without creating another polling loop.

A decorative vector hand follows the first 850ms of the spin clock: it approaches
the ball, flicks left, and withdraws. Pauses freeze its pose; late arrivals do
not replay it. Reduced motion hides it, and unmount cancels its animation with
the wheel. Static felt, layered rails, and raised owner-colored chip stacks add
board detail. Chip amounts sit below the discs so they do not cover the chips.
The portrait information panel fills the space remaining below the chip tray,
while the board retains its height cap. Outside labels use EVEN, ODD, and
2 to 1 for the column bets.

Red/black outside targets display colored diamonds instead of visible text;
the full bet names stay in their accessible labels and tooltips.

Wheel numbers face the center and occupy their own outer boxes at radii 100-118;
the ball passes over that band before landing at radius 90 in the separate
80-100 inner pocket band. A 650ms result camera gently centers and magnifies the
winning pocket after the wheel stops, with a gold highlight around the ball.
Pause/resume preserves camera progress; a new betting phase resets it. Reduced
motion keeps the whole wheel visible and retains just the pocket highlight.

Wheel number boxes have their own 1.8-unit gold borders; inner pocket dividers
keep the thinner 0.65-unit stroke, so the number ring reads as a separate band.

Red/black diamonds follow the cell proportions with an equal fluid inset on
all four sides, so every point floats near its border without touching it.

Hover, keyboard focus, and a 450ms touch hold preview covered pockets and the
selected stake's potential profit/return without submitting a bet. Releasing a
hold suppresses its synthetic click. Owned chip stacks open a native dialog to
update/remove that wager through existing server actions. The editor closes if
ownership/phase/permission changes; pending controls are disabled. Native dialog
focus trapping and Escape are retained, and the lock shortcut ignores dialogs.

Round receipts are cached locally for the current mounted match and rendered
once per results phase as one win/loss card per bet. The personal summary shows
stake, return, and signed net. A results modal opens 750ms after settlement to
allow the pocket zoom to finish, unless a platform modal is already open. It
closes on phase advancement and can reopen through Last round results. Match
and phase clocks remain authoritative and keep running. The scrollable receipt
area preserves the visible header/close button and summary; unmount cancels all
popup and touch-hold timers. Green seat cards carry a diagonal READY stamp
without changing seat dimensions. No sound cues are added.

Split targets use gold seam strips oriented to their shared number edge; corner
and zero-trio junctions use small squares. Street, six-line, and first-four
bets use rectangular edge tabs marked 3, 6, and 4. Inside decorations reveal
within 28 CSS pixels of a fine desktop pointer, on hover/drop, or keyboard
focus. Touch and hybrid devices always show them. Only decorations fade;
transparent hit areas and placed chips remain present. Cached target centers
are rebuilt on layout changes, so pointer movement does not trigger repeated
layout reads, and classes change only when proximity changes. Pointer leave
and unmount clear proximity state; reduced motion disables the short fade.

Inside markers receive a cyan fill and thin gold perimeter near a pointer, keyboard focus, or chip drop target.
Their hit boxes and decoration proportions scale continuously back to the
original compact sizes as board width or height becomes constrained. The
gold perimeter stays visible with reduced shadows enabled; inactive markers retain their gold fill.

Inside marker enlargement is reserved for roomy boards; medium and small boards
retain compact decoration proportions. Hover/drop highlighting follows the
painted strip or square rather than outlining the larger invisible hit area.
Keyboard focus outlines the painted marker itself.

Post-review regressions preserve seat order when a reconnect replaces a member
ID, keep manually reopened results visible during same-phase broadcasts, and
ignore queued close events from a previous dialog once another editor is open.
Canceled touch holds suppress their following synthetic click; another pointer
cannot cancel an unrelated finger's hold. GameHub now recognizes native dialogs
when routing Escape and game shortcuts, so Escape dismisses the native popup.

Cached result summaries refresh pending-winner metadata if server eligibility
changes, without rebuilding receipt cards or resetting scroll/focus.


## Card inventory and reward foundation (2026-10-28)

`src/cards.ts` contains 73 documented definitions in design order: personal
temporary, public temporary, permanent; positive, neutral, risky, negative
within each group. Public cards retain silver frames with muted purple interiors;
other temporaries are silver and permanents gold. Negative to Positive is rare
and limited to one copy; Type Reversal is normal rarity. Their effect semantics
remain design work, including individually defined reversed effects.

Round 1 remains ordinary roulette. A 30-second reward draft precedes betting
from round 2 onward: temporary in rounds 2/3, permanent in round 4, repeating.
The server draws three distinct eligible offers with rare entries weighted 1:6
against regular entries. Explicit permanent copy caps exclude maxed cards.
Choosing grants exactly one copy; all choices can finish the phase early.
Connected players who time out receive a random offered card; disconnected
players receive none. Offline players get no new draft while absent. No
catch-up grant exists; supported active effects trigger only on an accepted play. Reconnect retains owned
cards and an existing draft. Spectators and other players cannot see a hand
or private offers. Snapshots copy all arrays and card records.

On wide screens the bottom dock splits equally between the chip controls and
a fan of playing cards. Portrait stacks these controls. The compact
fan previews up to seven unique types; Check cards exposes the entire collection
in a scrollable native dialog. Duplicates use one card with an owned-count badge.
Each card places polarity at top left, name centered, count top right, and the
effect below. Inspecting cards never submits a gameplay action. Type Reversal is explicitly labeled Preview only; other negative
cards now apply their documented automatic penalties.

Tests cover private snapshots, forged/stale/duplicate picks, schedule, rare
weights, copy eligibility, disconnected timeouts, reconnect retention, sorted
stacks, header placement, and draft-dialog lifecycle.

Real Edge checks at 1366x768, 1024x768, 844x390, 390x844, and
360x740 verified equal wide dock columns, all card-header positions, duplicate
counts, full-hand inspection, reward submission, cleanup, and no page overflow.
A real two-player GameHub session passed rounds 2 through 4, private inventories,
paused reward controls, native Escape dismissal, and portrait fitting with no
browser errors. Card names stay inside the compact fan; full effects are
available in the inspection dialog.


Card presentation corrections: cards use a fixed 5:7 playing-card aspect ratio.
Equal-width left/right header tracks center the name independently of badge
width. Neutral and Risky are separate indicators and catalogue sections, with
source order checked against design.md. The decorative hand is removed.
Only Check cards opens the collection; clicking a fan card does not. A pointer
hover or keyboard focus glows immediately and, after one second, shows a larger
single-card preview without changing layout. Leaving, switching phases, opening
a dialog, or unmounting clears the preview and timer. Touch users can inspect
full-size cards through Check cards.

The card dialog is larger (up to 1120px wide and 92dvh tall). Unresolved reward selection has no Close button and rejects Escape/native
cancel requests. Confirmed choices close immediately. The server's choice or timeout still advances the phase and
closes the required dialog. Optional collection inspection retains Close and
Escape. Tests cover those paths, including delayed-hover cancellation.

Responsive browser checks additionally confirm that constrained modal grids scroll
without compressing row tracks or overlapping cards, and full-card titles remain
centered independently of the left/right indicator text.


Card front styling now uses metallic silver temporary faces, rich gold permanent
faces, and purple public faces with silver rails. An etched inner frame and
small diamond ornaments provide detail without image downloads or animation.
The card type sits directly below the centered name. Effect copy is centered
horizontally and vertically within the remaining padded area. Only overflowing
copy shrinks; short descriptions retain their normal size. One shared card
ResizeObserver rechecks container changes, and is disconnected on unmount.
Pixel-rounding tolerance avoids shrinking text that already fits.

Card-back artwork has not been created. Current styling covers front faces only.

Effect categories now use high-contrast badges containing a symbol and text:
green + Positive, red minus Negative, blue-gray = Neutral, and amber ! Risky. The badge remains visible in the compact fan.
These use static CSS and retain lifetime-specific metallic faces and framing.

Reward choices have a soft, static category glow: green for Positive, red for
Negative, gray for Neutral, and amber for Risky. Hover or keyboard focus
strengthens the same glow. The reduced-shadows preference disables these
shadows while leaving the labeled badge and border accent visible.


Static surface textures now cover the betting cells themselves: fine weave on red/black cells and irregular felt patches on green areas, with wood-grain outer rails and gold inner trim.
Card fronts use fine crossed linen patterns above their existing metallic faces.
Draggable chips use eight ivory edge inserts, molded concentric rings, surface
grain, and a raised rim; the drag ghost retains the viewer's chip color and
shares the same finish. Table stacks use matching rim inserts. These are CSS
gradients and borders, with no images, filters, or continuous animations added.
Reduced shadows removes the new chip depth shadows while preserving textures.

Wheel decoration uses a static SVG brass gradient: an eight-point compass with
rounded joins and circular edging inside the 53-unit hub, plus eight alternating
radial/tangential diamond inlays at radius 131 in the fixed brown bowl. Inlays
stay outside the 118-unit numbered rotor, just inward of the wood midpoint; ball-path and
landing geometry are unchanged. No spin timings, result geometry, filters, or assets change.

Texture corrections use opaque, clipped card borders to prevent background
bleed, plus three soft, uneven specular patches within the face. Four separate
rail backgrounds follow each board edge. Green cells reveal one continuous
patchy felt surface rather than repeating the same grain in each cell. Each
brown wheel ring receives eight uneven clusters of three curved grain lines.
The outer diamond ring now has eight alternating shapes at radius 131. Neutral
badges and etched frames use blue-gray. Everything remains static and uses
CSS/SVG without additional image requests or animated shine.

The colored left-edge stripe is removed from cards; category badges and reward
glows provide category identification. The lowest shine patch is softened and
moved into the face, away from the purple card's bottom edge. Green felt uses
the felt patch layers: connected cross-hatching in irregular shading patches above the
broader mottling, with no runtime noise filter. Eight wheel diamonds sit at
radius 131, just inward of the wooden ring's midpoint.

The felt shading uses connected intersecting diagonal lines, rather than
individual X marks. Each irregular patch has a subtle dark-green radial shade
that fades outward into the base felt. Card shine at the upper left is softer
and more broadly feathered. The texture uses static SVG patterns and radial
gradients; it adds no animated noise or filter work.

The felt uses one broad cross-hatched field spanning the board in both
landscape and portrait. It scales with the board, with feathered elliptical
edges and fixed 9px line spacing, beneath betting cells, labels, and chips.
The temporary SVG texture asset is removed.

Bottom card diamonds are slightly larger and inset above the etched border
(9px ornament, 10px bottom inset; compact fan 4px/4px). Extra footer padding
keeps effect text and reward buttons clear of the ornament.

The reward picker closes immediately once the server confirms a chosen card,
including timeout choices. Players need not wait in a confirmation window for
other participants; Check cards remains available to inspect their collection.
Unresolved reward choices still cannot be dismissed.

Reward options use a native button for the entire card, plus a separate Choose
card button immediately below it; there are no nested buttons. Both submit
the same server-validated choice and disable while a request is pending. Native
Enter/Space activation is preserved. The scrollable card grid has 32px of inner
padding and inter-option spacing so the category glow clears its clipping edge,
including the first and last rows.

The betting-surface stack is the green base, transparent Egyptian War-style
felt (fine 22-degree fibres, 9px/11px dot patterns, subtle lighting),
cross-hatching, then betting cells and chips. Both texture layers ignore pointer input. The single shading field fits inside the rail and follows both board dimensions. Opaque red/black cells cover the texture underneath.

Card dialogs initially focus their heading instead of the first card. This
prevents native dialog autofocus from triggering the first reward's stronger
focus glow and delayed inspection preview. Tab still reaches the real card
buttons, whose keyboard focus indicator and activation remain available.

Cross-hatched shading uses low-contrast 1px lines spaced every 9px. Elliptical
masks fade gradually from the center instead of clipping patches to rounded
blob outlines. No blur filter is applied; textures stay below betting targets.

## First playable personal effects (2026-10-29)

`preparations` is a separate 30-second phase between betting and rolling. Both
readiness windows support ready/cancel ready and all-ready advancement; entering
preparations clears betting locks. All paid-bet edits are rejected afterwards.
The board, card hand, and lock control remain visible in both orientations.

The existing validated/retry-cached action route accepts `play-card` with a
card ID. The server verifies ownership, support, stage, readiness, connectivity,
pause, deadline, and safe payouts before consuming a copy. Supported IDs are
Profit up, More draws, and Double or nothing. Other cards are inspection-only.
Private snapshots expose `playableCardIds`; `playedCards` publicly records only
accepted plays and their owners, without exposing the remaining hand.

Profit up adds 20 percentage points to winning profit per copy. Returns use
BigInt intermediate arithmetic and floor per wager; public money remains safe
integer numbers. More draws adds two immutable free wagers on random legal
targets, each floor(balance / 20) at play time. Free wagers do not reserve cash
or return a stake. A stake below one or unsafe projected settlement rejects the
play without spending the card. Repeated paid and free wagers stay separate.

Double or nothing is once per round and uses a separate server draw only when
net betting profit is positive. It doubles or removes that profit after other
bonuses, leaving losing/zero rounds alone. Other copies remain owned. Exact
`settlements` carry staked cash, returned money, final net, gamble adjustment,
and optional gamble outcome; the browser lists that adjustment separately so
receipt totals explain the actual balance. Winner checks run afterwards.

Played effects and summaries reset for the next round; accepted effects and
free bets persist across pause, reconnect, and the original owner's departure.
Tests cover stage transitions, retry safety, consumption, additive/floored
bonuses, free wager accounting, both gamble outcomes, lock/pause guards,
reconnect, public announcements, and browser controls/results.

## Bank and debt accounting (2026-10-29)

Net balance = cash balance - outstanding debt. Available cash instead subtracts
reserved stakes from cash balance. Only net balance is compared with the winning
goal; borrowing adds cash and debt, and no surcharge is deducted from cash.

The bank uses existing validated, retry-cached `take-loan` and `repay-debt`
actions. Loans are betting-only and once per round, with principal capped at
floor(goal / 4) and a one-time floor(principal / 4) surcharge. Repayments accept
only unreserved cash during unlocked planning. All amounts are positive safe
integers; projected paid-wager returns remain checked after a loan. No timer,
repayment, or reconnect resets a player's borrowing allowance within a round.

Each participant owns match-local loan records with stable IDs, acquisition
round, principal, original debt, and remaining debt. Repayment allocates oldest
first. Viewer-specific `bank` state contains copied history, limits, and current
permissions; other viewers receive no history. Public balances expose total
cash, debt, and net balance. Pauses and reconnect socket rebinding preserve all
records; the room does not persist loans to disk or user accounts.

After settlement, qualifying participants automatically repay all debt before
winner comparisons. Round summaries record `debtRepaid` so the result panel
explains cash movement separately from betting profit. Goal and tie comparisons
use net balance (cash minus outstanding debt), preserving the existing last-participant win rule.

Call Bank and Last round results share a row below the wallet. The native bank dialog owns a
separate `.lr-bank-shell` and `.lr-bank-panel`, allowing future shark-mouth art
around the inner panel. Each form has four proportional value buttons, a range
slider, and a numeric field; values and exact fee previews update together.
Trusted snapshots drive availability. Pending actions disable submissions, and
phase changes dismiss the bank. The modal scrolls internally on short displays;
opening it does not pause play. Every bank listener is removed on unmount.

Bank tests cover limits, floored fees, malformed amounts, duplicate requests,
stage/role/pause/lock/disconnect guards, reserved-stake safety, oldest-first
repayment, bankruptcy recovery, next-round allowance, private defensive history,
reconnect retention, automatic payoff, and winner ordering by net balance.
Debt-relief cards are now implemented; see the current catalogue section below.

Betting uses the board directly by clicking or dragging chips onto its targets.
The separate betting-space dropdown and Place selected bet button are removed.

The bank header sits outside the scrollable body, flush with the modal roof.
Loans and repayments use two columns when space permits, stacking on phones;
balance information, history, and rules follow below. Percentage presets use
green (25%), blue (50%), amber (75%), and rose (100%) alongside text labels.

The upper player row is grouped immediately below the title, independent of
the toolbar height. Six equal slots remain reserved even with fewer upper
players. In landscape, the row ends at the same edge as the table column.

Pre-commit review fixed a tiebreaker that kept requiring the original goal.
Once a tiebreaker begins, compare remaining contenders by net balance even
below the goal; a regression includes unpaid debt so gross cash cannot win.

## Shop stage and booth (2026-10-29)

`src/shop.ts` owns weighted distinct selection, round-shared card choices, and
pure starting-cash/goal/average-net price calculation. Each contender receives seven regular stock
records and one personal 25%-75% deal with private UUIDs. The shared card IDs are
drawn once per round; stock and transaction state belong to each participant.
The server derives price, discount, caps, availability, and grant; `buy-card`
accepts only an offer identity through the existing phase/retry validation.

The `shop` phase sits after Rewards from round 2 and before Public Effects, with
a 30-second deadline and reversible readiness. Its locks reset before Public Effects.
Loan and repayment guards now include Shop; the existing borrowing-round field
prevents a second loan in Betting. Shop Reroll is playable in Shop only and
atomically replaces all owner stock after consuming one copy. Old offer IDs
become invalid and other shops remain untouched. Histories and stock survive
pause and socket-ID rebinding. Spectators receive no personal offers.

The booth uses native CSS plus a static SVG perspective canopy, sharing the
existing card renderer. `fitShop` scales the complete booth and signboard to
roomy viewports; a ResizeObserver handles resizing rather than a layout loop.
Compact offers show supporting text and prices beneath the cards. Larger
screens show a separate wooden signboard with the selected card, price, and
a bottom-filling Buy card button. Double-click purchase also remains available. On compact/mobile or short-height screens the signboard is
removed from the layout and selecting a card opens a height-aware dialog with
its enlarged face and price, with double-click purchase on the card.
The bank opens above the shop and returns focus to it. Escape cannot dismiss
the Shop stage. Every observer and listener is cleaned up on unmount. A
host-only Pause/Resume control prevents the required modal from hiding pause
access.

Tests exercise stock split, separate deal, inclusive discount endpoints, prices,
forged/duplicate purchases, privacy, copy caps, affordability, readiness, loan
allowance, pause/reconnect, reroll isolation, and nested bank/inspection dialogs.
No SDK or published package version changes are required for local testing.

Spectators keep watching the ordinary stage rather than receiving an empty
required shop overlay; they receive no private stock. Hand inspection labels
Shop Reroll as Shop-only so it cannot be confused with Final Preparations cards.

## Reward Reroll and modal inspection (2026-10-29)

The new `reward-reroll` card uses the existing `play-card` request validation and
retry cache. Rewards are an allowed stage only for this card, and the viewer's
playable IDs require a pending personal choice. `drawCardOffers` accepts an
optional choice count and prior draft, avoiding old choices when possible and
falling back to the full eligible pool rather than creating an empty draft.
Consumption and replacement happen together; phase ID and deadline stay fixed.
Other players' offers remain private and unchanged.

`reward-hand` is a presentation mode of the existing card dialog. Its Back to
rewards and Escape paths restore the required draft. Trusted snapshot updates
preserve this mode until timeout/choice/phase transition. The Shop footer uses
the same hand renderer without dismissing the required booth.

Hand hover cards use a manual popover in the browser top layer. A containing-
dialog fallback remains for browsers without that API; hover leave, state
changes, and unmount hide the preview. Shop cards stay still and use clicked
selection on the side sign, or a full-size inspection dialog on compact screens.

## Average-net shop pricing (2026-10-29)

`shopCardPrice` uses scale = 2 * starting cash + 2 * max(0, average net) + goal/2.
Type rates remain 1% temporary/public and 3% permanent, with a 2x rare multiplier.
`nicePrice` uses exact BigInt fractions, rounding to nearest whole units below
20 or nearest five otherwise, always at least 1. Deals use the same rounding
after applying the percentage discount. Payout, stake, and debt rounding rules
are unchanged.

`#beginShop` sums cash minus outstanding debt for active contenders using BigInt
and stores their whole-unit average in `#shopAverageNetBalance`. Offline active
players count; departed players, spectators, and non-contenders do not. Every
shop and owner reroll uses that stage's frozen value, so spending, loans,
repayments, and rerolls cannot move prices mid-stage. The next Shop stage gets
a fresh snapshot. Equal per-player wealth produces equal prices in 2-player
and 12-player games. Tests cover debt-aware averaging, room-size neutrality,
negative averages, exact rounding, reroll stability, and next-stage repricing.


## Shop selection and responsive signboard

The side sign shows the clicked card, never changes on hover, and uses a corner
percentage-off tag anchored to the board without adding a price row. It is slightly larger and stays
beside the booth only on landscape viewports with enough width and height;
portrait and short viewports use the card inspection dialog instead.
Shelf and inspection cards show their price underneath with a Buy card button only on the detail sign. Double-click/double-tap buys an available card; Shift+Enter provides
the keyboard equivalent. Compact single-click inspection waits briefly so a
second click can purchase without opening a blocking dialog. Pending, locked,
paused, sold-out, and unaffordable offers retain server-side purchase validation.
The optional owned Shop Reroll control is always first in the action row, with
explicit hidden styling to prevent global button rules from revealing it.

The temporary/permanent shelf boundary has a vertical divider. Each offer is
centered within its equal-width slot, with the divider at the permanent slot
boundary so the permanent card has equal space on both sides. The sign-only
purchase button fills its remaining bottom space. Only hand cards use
a 200ms transform transition to glide up on hover and return on pointer leave;
reduced-motion preferences disable the transition.

Shop resize always refreshes the detail sign from current stock, including a
reroll performed while the sign was hidden. Delayed compact inspection ignores
offers that have since been replaced.


## Public Effects stage foundation

The `public` phase lasts `roundTiming.public` (30,000 ms) between Shop and
Betting from round 2 onward. Shop readiness and deadline routes both enter it;
public readiness and deadline routes both enter Betting. Each transition clears
locks. `canLock` permits connected contenders; spectators stay read-only.
The client displays the betting board, phase label, timer, Check cards, and
Ready up/Cancel ready; chip controls stay hidden and bets stay closed.

Profit Bonus and Profit Cut are now enabled here, up to two public plays per participant. Targeted public cards are now implemented; Type Reversal is active with the approved numeric and utility reversals. Purchases, loans,
rerolls, and personal card effects retain their existing stage restrictions.
Unlocked repayments work throughout planning, including Public Effects.
Manual/disconnect pause and reconnect use existing phase timers without resetting
the stage. Tests cover the ordering, permissions, timeout, retries/stale phase
IDs, reversible readiness, reconnect/manual pause, and client controls.


## Initial public, cash, and debt-relief implementations

`CardDefinition.playStage` is set only on implemented active cards and is sent
in viewer snapshots. Server permissions and hand/shop labels use the same
metadata. Existing protocol action names and readiness state remain unchanged.
The implemented active catalogue is Profit up, More draws, Double or nothing,
Shop Reroll, Reward Reroll, and the six additions documented below.

Profit Bonus/Profit Cut add +/-30 percentage points globally for the round.
`#publicProfitBonus` includes all committed plays, even from departed players;
`#cardReturn` adds personal Profit up and floors profit with a minimum 20%
multiplier. Betting validation now uses the actual modified portfolio with
BigInt totals, including overlapping wins. Stakes are not discounted and free
bets return profit only. The separate net-profit gamble follows these modifiers.
Public plays require their stage, ownership, and fewer than two prior public
plays; the next round clears them with other played effects.

Goal Grant/Cash Bonus add floored cash, respectively goal/20 and current cash/10.
Before granting cash, all outcomes and the profit gamble are checked for safe
integer payouts. Loan Relief forgives min(latest original debt/2, latest unpaid
balance), never affecting prior loans. Debt Reduction forgives a floored fifth
of total unpaid debt, oldest first. Neither effect spends cash or alters the
round's borrowing allowance. No-benefit relief/cash plays fail without consuming
the card. Cash/debt changes do not trigger an early winner check.

Tests cover public cancellation/stacking, the 80% reduction cap, the per-player
limit, stage/ready/pause/spectator restrictions, retries, expiry, owner departure,
free bets and gamble ordering, reserved cash, floored debt relief, latest-loan
capping, no-benefit retention, and card metadata labels in the client.


## Shared public-card presentation

Public cards animate for every viewer; personal cards animate only for their owner. A successful public play stores a publicAnimation
record with a unique ID, owner/card, duration, and remaining time in every
viewer snapshot. The server preserves the phase's exact remaining time and
blocks additional plays/readiness until its independent animation timer ends.
The timer hold is separate from manual and disconnect pauses. Completion
resumes scheduling only when neither of those pauses remains. Disposal/game
end cancels the presentation timer. Late callbacks are reconciled before the
next action. Retry acknowledgements cannot repeat or extend a presentation.

The browser positions a pointer-transparent popover over the real board and
uses the animation ID to prevent replay. A viewer connecting mid-animation uses
its remaining portion; elapsed time offsets the CSS animations. The phase fill
and label freeze while publicAnimation is present. Every public viewer sees the
same common pop, followed by fade or target placement. Public animations close
optional hand windows so they visibly land on the felt. Personal plays and
rerolls animate only for their owner and do not emit play notification popups; their effects and
played-card history remain server-authoritative.

Reduced motion uses stationary feedback without changing shared server timing.
Optional PlayedCard.spaceId supports future target placement but does not enable
targeted card mechanics. Viewport changes reposition the presentation; round/
match changes and unmount remove the popover and its local timer.

Purchased cards receive a clipped diagonal gold SOLD OUT stamp in the shelf,
detail sign, and compact inspection. Prices stay underneath without sold-out
suffixes; aria labels and disabled purchase controls still convey stock status.

## Dragging owned cards onto the board

Pointer handlers accept only playable owned cards in the hand fan or collection,
during Public Effects/Final Preparations, while not ready, paused, or pending.
Shop offers, reward choices, previews, and reroll cards keep their existing controls.
An eight-pixel movement threshold distinguishes a drag from a normal tap.

On movement, the optional collection closes to reveal the board. A pointer-
transparent ghost follows the mouse/pen/touch in its own layer, and board bounds
highlight a valid drop. Release submits one `play-card` intent with the existing
match/phase/request identifiers; the authoritative publicAnimation record triggers
the public animation; personal cards animate privately without play alerts. The drag itself never grants effects or optimistically animates.
All currently implemented board cards are global/personal, so any board location
is valid. Future spot-targeted mechanics still need their own targeting validation.

Outside/canceled drops and rejected/network-failed plays restore the collection
when still in the original stage. Phase, eligibility, pause, focus loss, and
unmount cancel gestures. Synthetic post-drag clicks are suppressed, including a
stage changing to Betting before release. Gesture state uses card IDs rather
than transient DOM nodes so unrelated snapshots can rebuild the fan safely.


## Animation audience and delayed-view recovery

The client no longer drops a shared animation merely because document.hidden
is true. It marks a public animation ID handled only after presentation starts.
A missing board rectangle retains the pending card; ResizeObserver, window
resize, and visibility changes retry it when the board becomes available.
Retries use the current shared record and elapsed receipt time, preventing an
old queued record from restarting a completed public animation.

Public records remain global and retain their server-controlled timer hold.
New nonpublic played-card occurrences are filtered by the local stable
participant ID. Only the owner queues those animations, including rerolls;
other players and spectators do not animate them or lose their hand window.
First snapshots do not replay personal history. Personal feedback does not
pause the stage clock, and personal success-alert popups remain disabled.


## Stage introduction ribbons

A pointer-transparent fixed ribbon signals entry to Public Effects, Betting,
and Final Preparations. Each stage has its own title, instruction, and accent
color. It slides in, holds briefly, and exits within 2.1 seconds; reduced-motion
and interface-motion preferences show a stationary ribbon. Shadow reduction is
respected. The wrapper clips horizontal travel to prevent document overflow.

Stage identity controls presentation, so cash updates, public animation holds,
and repeated snapshots do not restart it. Other stages clear it, and unmount
cancels its timer. It changes no server timing or input permissions. The visual
ribbon is aria-hidden because the existing live phase label already announces
stage changes. Tests cover stage selection, repeat updates, preferences, and
cleanup; browser checks verify width, input transparency, and viewport fit.


## Complete defined card catalogue

`src/cardRules.ts` owns small documented inventory, pricing, copy-limit,
public-status, and capped-tax helpers. Session-owned card memory retains each
copy's acquisition round, Specialist assignments, Patient Investor growth,
Third times the charm betting-round count, purchase round, and the extra public
play cooldown. Inventory mutations from drafts, shops, generators, and theft
share the same add/remove paths. Owner-only `cardDetails` exposes useful counters
without revealing hands to others.

`play-card` either commits an effect or creates an owner-only `cardPrompt`.
`choose-card-effect` accepts only opaque selection/option IDs from that pending
continuation. It revalidates resource ownership and targets before committing.
Unspent choices can be cancelled; Sticky Fingers and the paid Trade up reward
selection cannot. Their cost is committed before revelation and their remaining
choice resolves randomly at the next phase boundary. First snapshots/reconnects
restore current prompts; ordinary broadcasts do not rebuild focused options.
Phase changes clear unspent prompts. The server still broadcasts utility-card
actions during Rolling/Results, independently of retained ready flags.

Public `spotEffects` have independent IDs, card/owner/number identifiers, and a
reversed flag. White Out, Erase, Copycat, Relocation, and Reverse Fortune operate
on these records in serialized server acceptance order. Cross out is checked
again when wagers are edited. Confirmed animation snapshots carry the target
space to every viewer; a card pops onto the board and travels to that space.
Private actions retain owner-only feedback and emit no public play alert.

Settlement evaluates the Shared Agreement condition without its own bonus,
then additive bonuses, exact MinMax multiplication, win-triggered penalties,
refunds, profit gambles, capped tax transfers, debt relief and cash charges,
and finally winner qualification. All tax claims use one pre-tax snapshot;
proportional caps floor each claim with no dust redistribution. Extra losses
become penalty debt rather than negative cash. See the design's provisional
rules for money snapshots and acquisition/stage timing.

All 73 catalogue effects are active, including Type Reversal's approved numeric
and utility mappings. Late-entry/missed-reward assistance remains separate platform
work. Automated tests cover real draft-to-action flows, all public status
operations, passive and negative rules, theft privacy, paid-choice expiry,
exact taxes, free-round caps, duplicate requests, and the existing client/game
lifecycle regressions. Browser validation also checks private target dialogs,
public animation destinations, input, and portrait/landscape fit.

Targeted public cards hold the stage for 1,550ms (1,100ms pop plus 450ms placement); untargeted public cards hold for 1,400ms. Both use the authoritative animation record, and reconnect joins its remaining time. Theft retains the acquisition timing of unresolved negative cards, so transferring them cannot reset their penalty deadlines.


Type Reversal implementation constraint: preserve the original card's numerical
magnitudes, caps, scaling amounts, conditions, and duration. Flip effect direction
using that same definition (-25% becomes +25%; +15% becomes -15%), rather than
mapping to another card with different values. Neutral/risky cards and already
committed effects remain unchanged. Its +20% profit bonus counts the first copy
and caps at +100%. Utility effects use the explicit approved reversal mappings in design.md.

Negative to Positive is explicitly exempt from Type Reversal. Preserve its
positive polarity, suppression ability, and +2%-per-negative-card bonus (maximum
+60%). Resolve other cards' current polarity after reversal before suppressing
their unresolved negative effects and counting them toward that bonus.


Approved reversal utility mappings are listed in design.md. Reversed Go Fish
and Sticky Fingers choose an eligible recipient randomly. All reversed theft
transfers/interceptions must explain the source player and causing reversed
card to the recipient and source without exposing private hands publicly.
Reversal changes effect direction without reinitializing acquisition ages,
accumulated growth, counters, cooldowns, or assigned targets (+15% held-round
profit becomes -15%). Cold Streak applies to the first winning round; Short
Changed reduces winning-bet profit in the next round only and expires even
without a win. Its reversal gives +20% with the same fixed expiry.
Reversed Shop Closure grants one refresh usable only during that round.
Reversed Cross out grants Free Entry bets at 5% of each participant's current cash. Reversed Forced Sale grants one temporary card chosen from three offers.

Short Changed uses acquisition-round metadata to activate only on the following round. Its 20% reduction applies to each winning wager, independently of net round profit; expiry removes only due copies and also runs for suppressed, losing, or abstaining players. Cold Streak retains its separate first-profitable-round trigger.


## Active Type Reversal

`reversal.ts` contains owner-specific descriptions and manual stages. Parity is
computed from currently owned Type Reversal copies. Neutral/risky cards and
Negative to Positive are exempt. Every copy adds +20% betting profit, including
the first, capped at +100%. `cardRules.ts` resolves effective polarity and signed
unsuppressed copies without resetting ages, growth, counters, cooldowns, or slots.

Committed play records store their direction separately from owned-card parity.
Public statuses retain their own direction, as do paid selections and timed
positive permissions. Later acquisition/discard of Type Reversal changes only
unresolved owned effects. Animation snapshots carry committed direction so
other viewers see the correct card face regardless of their own inventory.

Formerly positive temporary cards run automatically at their original stage
when reversed into negative effects. Public presentations remain serialized and
hold the phase clock for their full animation. Former negative personal cards
can be held and manually played in their appropriate stage. Positive Short
Changed/Paperwork/Collection Notice use the next round; positive Public Silence
adds a play this round; positive Shop Closure refreshes once when used in Shop.
Positive Cold Streak waits for its first profitable round after activation.

Reversed Go Fish/Sticky Fingers pick an eligible recipient randomly and queue
an owner-only blind/revealed choice. A recipient already choosing a card is not
interrupted. Required gifts clear that recipient's ready flag so their choice
isn't skipped. Both participants get private cause messages, deduplicated by
ID; Check cards retains the latest message after reconnect. Other viewers get
neither hands nor private messages. Reversed interception also explains its
reward transfer. Paid choices use their original direction at timeout.

Free Entry resolves final public statuses at Betting entry and grants each
participant a separate free, uneditable straight-up wager worth floor(5% of
current cash). It cannot block that number. White Out/Relocation/Copycat operate
on the status before the grant; already-created wagers stay committed.
Forced Sale's reversed draft is paid before revealing its three choices.
Reversed More draws creates forced paid wagers; uncovered losses become penalty
debt. Signed cashback/insurance can add losses; reversed Parking Tax pays
subsidies even if its owner has no qualifying profit. Reversed TAX retains the
threshold and combined outgoing cap. Loan discounts and extra permissions are
shown in Bank without pretending that a debt discount removes cash.

Automatic reversal queues are reconsidered when phase timing resumes, including after host/disconnect pauses. A reversed More the Merrier acquired during Public Effects records that round as its cooldown use. Signed positive bonus components are accumulated before MinMax, so newly positive versions of negative cards use the same multiplier order as other bonuses.


Paid theft choices revalidate their original revealed options after a failed
selection. If another player spent the selected card, the owner receives a
fresh prompt containing only the still-held original options, or an immediate
close when none remain. The changed private state is broadcast even though the
action failed. New prompts reject removed option IDs; no new hidden cards are
revealed and the already-paid cost is not refunded. Timeout resolution shares
the same eligibility check.


Disabled card controls show the owning player's current blocker, including
readiness, a pending choice, a shared animation, Public Silence, or the public
card limit. These reasons are private and update even when the playable-card
list remains empty. Permanent negative cards are labeled Passive effect;
automatic temporary penalties retain their Automatic penalty label.

Cross out investigation: both players could play sequentially through actual
GameHub sockets, including a phone guest. The reported persistent player-two
block has not been reproduced; the diagnostic labels expose the cause if it
recurs rather than assuming the placement animation caused it.


### Direct card targeting and shared theft hands

Player-targeting cards highlight the eligible player cards already seated above
and below the board. Eligible betting spots are highlighted directly on the
board for public targeting and Specialist assignments; click or keyboard
activation submits the server-provided opaque option. An on-screen prompt
allows cancellation before spending an uncommitted source card.

Interactive blind theft uses a shuffled fan floating over a darkened screen,
without a surrounding box. The selecting player sees identical card backs;
the hand owner sees their own card faces in the same order and cannot select
or cancel the other player's action. Only those two participants receive this
presentation. Spectators and uninvolved players receive no hand or options.
Hidden identities remain in the server's option map. Reconnect preserves the
same choice and order; completion, cancellation, or phase expiry removes it.
Cards explicitly described as random theft retain their automatic random picks.

The approved design has a white frame, outer checkers fading toward a dark
center, an unpatterned diamond medallion, and surrounding fine lines that soften
toward the edges. Its colors follow the hand owner's public player color. Every
card in a hand uses the same back regardless of kind, polarity, or rarity.
The player-color palette is defined in src/session.ts; card backs use those same colors.


### Player-colored card backs

Card backs automatically use the hand owner's public player color. Every card
in that hand uses the same checker pattern, fading lines, white outer border,
and center diamond, regardless of its kind, polarity, or rarity. During theft
the selecting player sees the other player's color, matching that player's seat
and chips. The hand owner still sees their own card faces. No style dropdown,
extra saved setting, or rule/preset change is needed.


### Card face presentation

Temporary cards use silver faces with a faint checker texture and nested
four-point diamonds. Public cards use purple faces with diagonal slashes and a
framed diamond. Permanent cards use gold faces with cross-hatching and a central
four-point diamond surrounded by eight smaller copies of that same symbol.
Watermarks remain behind the effect text. Category badges, centered names,
card types, and duplicate counts retain their roles; serif headings and etched
frames distinguish the face from its player-colored back.

The approved styling is shared across rewards, shops, hands, inspection,
private selection, and play animations. Compact hand thumbnails keep reduced
padding and typography, and long effects retain automatic text fitting.
The two temporary design preview HTML files have been removed.
