# Loaded Roulette Implementation Plan

This plan supports [the game design](design.md). It describes planned work,
both implemented prototype behavior and remaining planned work. Last reviewed: 2026-10-29.

## Current scope

The basic roulette prototype is implemented: a 157-space legal single-zero bet
catalog, paid-stake reservations and edits, reversible locking, 60-second
betting, a six-second shared spin with a private result until landing, payouts,
five-second results, qualifying-leader/tie handling, pause/recovery, and stable
reconnect ownership. The browser supports selecting/dragging chips, exact custom
stakes, proportional stacks, physical seam targets, and native focusable board buttons.

Private card inventory, duplicate stacks, and timed reward drafts are implemented.
Final Preparations and Profit up, More draws, and Double or nothing are
implemented. Bank loans and repayments are implemented. Other card effects, shops, and
late-entry admission are not.
The package stays private and is installed as a reviewed local tarball in the
normal GameHub build for testing. Existing approved money sliders remain.

The initial six/two/five-second presentation timings, waiting for all missing
players before early auto-resume, and the departure policy in README.md are
explicit prototype decisions rather than silently settled final design rules.

## Source responsibilities

Start with a few modules; extract more only when their responsibilities grow.

| File | Planned responsibility |
| --- | --- |
| `src/definition.ts` | Real roulette settings, approved bounds, rules, input actions, and manifest. |
| `src/session.ts` | Authoritative match state, phase transitions, actions, lifecycle, and completion. |
| `src/roulette.ts` | Pocket definitions, approved bet catalog, result matching, and base payouts. |
| `src/economy.ts` | Cash reservations, loans, debt, settlement receipts, and integer calculations. |
| `src/cards.ts` | Card definitions, instances, eligibility, effect hooks, and shop/reward generation. |
| `src/visibility.ts` | Viewer-specific snapshots and private pending choices. |
| `public/client.js` | Mounting, phase views, input, snapshots, and cleanup; split board rendering when needed. |
| `public/template.html`, `public/style.css` | Betting layout, centered wheel, player areas, cards, and responsive controls. |
| `src/*.test.ts`, `test/` | Pure rules, session timing, privacy, browser behavior, and package tests. |

Use server-owned pocket definitions for both outcomes and wheel presentation.
The initial wheel has 37 single-zero pockets. Keep IDs separate from visual
positions so a later custom wheel does not require rewriting payout logic.
Custom slots remain deferred; do not enable them as part of the initial rules.

## Authoritative state

Each match needs a match ID, round, phase ID, state revision, participants,
locked-in players, deadline/remaining time, committed bets, public effects,
roulette outcome, and settlement status. Tiebreakers keep an explicit eligible
participant set and admit no new participants.

Each participant needs a stable match-local ID mapped to the current member ID,
assigned color, cash, reserved stakes, loan records, outstanding debt, borrowing
round, card instances, shop inventory, reward choices, and missed-reward tracking.
Reconnects remap membership without recreating resources. This is in-memory
match identity, not an account or persistent user database.

Card instances need their own IDs, owner, definition, acquisition round,
card-specific counters, cooldowns, and stored references such as a particular
loan. Never represent two owned copies as the same mutable instance.

Use whole-number money and explicit integer ratios. Validate safe bounds before
accepting settings or amounts; use exact intermediate products where needed and
floor monetary fractions before returning bounded JSON numbers. Keep the
explicit catch-up rounding-up rule separate. Negative cash is forbidden;
card-caused uncovered deductions become penalty debt under the design rules.

## Phases and deadlines

The normal sequence is Rewards -> Shop -> Public Placement -> Betting -> Final
Preparations -> Rolling -> Settlement. Round 1 skips card-related substages.
Planning substages default to 30 seconds each, except Betting at 60 seconds.
The wheel duration must be chosen before animation and synchronization are built.

Use one session-owned phase timer. Store a deadline based on `context.now()`;
pause preserves remaining time and resume reinstates that time. A phase advances
once on expiry or all-ready. Lock-in can be undone only before advancement.
Spectators do not count toward readiness. Connected reward timeouts choose an
offer randomly; disconnected players receive no automatic reward.

Every mutation checks the match/phase identity, role, membership, connection,
lock-in status, resources, target, and payload. Include a request ID and retain a
bounded per-player duplicate-result cache so retries cannot spend or settle twice.
Discard and trading cards are explicit exceptions to ordinary phase restrictions,
as the design allows them at any time before their target's penalty resolves.
A late request cannot reopen Betting or replace a committed roulette outcome.

## Bets, loans, and settlement

Reserve paid stakes when accepted. Changing or removing an editable bet adjusts
its reservation atomically. Free bets reserve no money and pay profit only;
normal paid wins return their stake plus profit. Validate legal spaces against
the approved bet catalog, including zero's exclusion from outside bets.

Choose the roulette pocket once through `context.randomInteger()` when Rolling
begins. Keep it private until the reveal. Start clients with an outcome-free spinning
animation, then reveal the pocket for the final landing segment. Client animation
completion cannot authorize payout.

Settle once using the design order: additive modifiers, explicit multipliers,
profit gambles, taxes, debt changes, then winner checks. Preserve the 80% profit
reduction limit. Compute tax claims from the same pre-tax values, apply the 50%
round-profit cap and proportional floors, then net opposing transfers. Do not tax
returned stakes or incoming tax transfers.

Track each loan separately. Borrowing is allowed once per round during Shop or
Betting; the provisional principal cap is 25% of the goal and surcharge 25%.
Repayment and relief never restore that round's borrowing allowance. Penalty
debt is separate from loan principal and creates no borrowing surcharge.

Record a settlement receipt internally, even before choosing its final UI, so
refunds, modifiers, taxes, and debt changes can be tested without circular sums.
Compare balances after required debt repayment. Tied highest qualifying players
continue alone; permanent departures leaving one participant award that player
a win. No remaining participants ends the match without a winner.

## Cards, rewards, and shops

Implement effects through a small set of settlement/phase hooks rather than a
separate conditional branch for every card throughout the session. Each card
definition states its timing, target, copy limit, rarity, and required snapshots.
An accepted play or trade consumes/transfers its instances atomically.

Round 1 has no reward; rounds 2 and 3 give temporary cards, round 4 permanent,
then repeat. Shop inventories are private and independent. Preserve seven offers:
three shared-selection plus two personal temporary offers, and one shared-selection
plus one personal permanent offer. A purchase marks that offer sold out; a reroll
creates new offers only for its owner. Ownership caps still apply.

The phase registry must cover public placement limits, permanent triggers,
automatic negative temporary effects, personal Final Preparations plays, and
anytime discards/trades. Removing a held negative card stops future penalties,
not charges already applied. Card-specific counters and loan references survive
round changes and reconnects.

Blind hand theft uses shuffled opaque selection handles, not exposed card IDs
that can be tracked across public reveals. Sticky Fingers reveals choices only
to its acting player. Interception targets a future reward and does not require
cards currently in the target's hand. Revalidate targets when an action commits;
concurrent discard, trade, or theft must not duplicate or spend the same card.

## Privacy and platform integration

`getPublicState(viewer)` can already return different state per viewer. Public
snapshots include identities/colors, public bets, phase/timer, public effects,
results, and standings. Include a hand, personal shop, reward choices, or private
peek only for its owner. Spectators receive public information only.

`context.emitEvent()` currently broadcasts to active viewers. Do not put private
cards, shop contents, or peek results into that channel. Deliver private choice
updates through viewer-specific snapshots; public card-use notices expose only
information the design says to reveal. A private-event SDK addition is not
required to implement the initial game this way.

The missing platform capability is mid-match spectator admission. GameHub owns
room roles and the active-player set, and the current SDK offers no generic
admission method/hook. Add an opt-in host operation and matching game hook before
enabling late entry. The hub must atomically update membership and notify the
session at an approved phase boundary, enforce the combined 12-person room cap,
and preserve reconnect tokens. Do not let game code mutate hub internals.
Existing games keep their current behavior when they do not opt in.

Use GameHub's existing host transfer, presets, input, and mounting services.
Keep session-specific phase timers inside this game initially. New optional SDK
capabilities must be reflected in peer/dev versions and verified with a packed
consumer before enabling integration.

## Reconnects and departures

Every disconnect starts or resets the game's 60-second disconnect pause. Keep
manual host pause intent separate so automatic expiry cannot undo it. Preserve
committed actions, borrowing allowance, debt, cards, and bets. Do not invent
missed purchases, card plays, or bets when continuing without someone.

Late-entry assistance derives scheduled temporary/permanent counts from the
round and halves each with rounding up. Returning participants keep their
resources and receive assistance only for rewards actually missed. Record which
missed intervals have been claimed to prevent repeated reconnect grants.
The entry-round replacement draft remains provisional until confirmed.

On permanent departure, retain committed effects/bets for their prescribed
resolution while disabling future owner triggers and winner eligibility.
Use `context.finish()` for game completion; room ownership and cleanup stay with
the hub. Never implement a second independent host-transfer timer in the game.

## Browser behavior

Render one main board at a time: betting during planning, the centered wheel
while rolling. Keep balances, phase, and primary controls stable during the
switch. Show personal shop rolls above shared selections, permanent cards to
the right, and the agreed silver/gold/purple card styling.

The browser renders server snapshots and submits intents. It must not infer
private opponent cards or calculate authoritative outcomes. Announce phase and
result changes without repeatedly announcing countdown ticks. Reduced motion
must preserve outcome and input deadlines. Remove input subscriptions, timers,
observers, animations, and pending-choice UI on destroy; late replies must not
notify or mutate a replacement game.

## Implementation milestones and verification gates

1. **Roulette and economy core:** approve the initial bet catalog, implement
   result matching, reservations, paid/free payouts, debt, and integer rounding.
   Verify every supported bet and ledger conservation with pure tests.
2. **Playable round prototype:** replace balance-increment state with timed simultaneous
   betting, lock/unlock, one outcome, settlement, pause/resume, and winner/tie
   handling. This validates the core; it is not the complete designed game.
3. **Private progression:** add card instances, reward drafts, hybrid shops,
   loans, relief, and viewer-safe state. Verify duplicate requests, copy limits,
   borrowing allowance, and player/spectator information isolation.
4. **Card interactions:** implement the agreed catalog, public effects,
   personal preparation, theft/trades, negative effects, and settlement hooks.
   Test additive/multiplicative order, tax caps, generation, refunds, and races.
5. **Membership lifecycle:** implement the opt-in hub admission contract and test
   next-round entry, catch-up accounting, reconnect remaps, departures, host
   transfer, tiebreaker exclusion, and no duplicate resource grants.
6. **Presentation and release:** complete the two board views, synchronized
   wheel/ball animation, readable 12-player betting, keyboard/touch controls,
   accessibility, and audio. Run full multiplayer sessions, packed-consumer
   checks, clean installs, and real-device playtests before enabling the game.

Keep each milestone small enough to review and retain the existing lifecycle
regressions while replacing their balance-increment-specific expectations.

## Decisions needed before their affected milestone

The design remains authoritative. These unresolved choices must be answered
before implementing the relevant feature rather than silently filled in here:

- Supported bet spaces/payout catalog and whole-number host-setting bounds.
- Shop pricing, remaining rarity/copy limits, and each card's money snapshot.
- Public-effect ordering, competing theft/interception resolution, and the
  remaining refund/gamble interactions already noted in the design.
- Early resume with several disconnected players and returning-player draft
  timing, including missed extra-card triggers.
- Departed-player payout accounting and pending-spin last-player endings.
- Permanent-effect visibility, detailed phone betting layout, and wheel/result
  presentation durations. Protective Seal remains deferred pending its own
  protection-first placement decision.

## Verification already completed

The initial pure-helper and placeholder tests have been replaced/extended with
real catalog, session, and DOM coverage. Current type checks and 90 tests cover
157 legal targets, all pocket payouts, zero exclusions, validation, reservation
accounting, duplicate/stale requests, pause/deadlines, hidden outcomes, once-only
settlement, ties, reconnect IDs, departed winners, chip drag/click, exact custom
values, stack boundaries, spectators, and teardown.

Real Edge checks at 390x844 and 1366x768 exercised click-to-bet and actual pointer
dragging onto seam/intersection targets, then locked both players, revealed the
server result, and checked settlement without browser errors or horizontal
overflow. Normal GameHub/Docker integration and multiplayer smoke checks are
verified separately before handover. Physical-device touch/performance testing
is still needed.

The basic betting renderer fits one complete table into the available viewport.
It transposes grid coordinates on orientation changes without rotating labels or
replacing betting targets. Outside bets share the number grid; seam positions
are recomputed from cell bounds. Only supporting ledgers/details can scroll.

Fitted-board checks at 360x640, 390x844, 844x390, 768x1024, and 1366x768
confirmed no page/table scrolling, all 157 targets within the viewport,
integrated outside cells, and upright labels across orientation changes.

The play column is ordered as excess seats (7-12), board/wheel, seats 1-6,
phase timer, and chip/readiness controls. The upper row hides when unused.
The information panel stays on the right in landscape and below in portrait. Player rows share six equal cells without horizontal scrolling.

Wheel motion uses one elapsed-time trajectory, including pause/resume. The
server reveal begins the two-second landing segment: the ball eases into its
pocket over the first second, then follows the wheel through one second of
braking. The reveal does not immediately announce the winning number. The
existing six-second server settlement deadline and reduced-motion behavior stay
in effect. Regression checks cover capture continuity, pocket alignment, and
braking speed, alongside twelve-seat ordering and bottom chip placement.

Loaded Roulette uses the same scoped, safe-area-aware outer-frame rules as
Egyptian War. The shell fills available height and caps width at 100rem, so
large-window margins contract before the game width shrinks. CSS owns frame
dimensions; the client only positions cells and seam targets within that frame.

Compact-width and short-height layout switches have been removed. One clamped
size unit scales spacing and controls from both viewport axes; board-container
units scale labels and seam targets from the actual available board space.
Chip selection uses the same two-row layout in both orientations. Only the
intentional portrait/landscape structural reflow changes the board arrangement.
Browser resize checks cover the former 650px and 450px thresholds on either
side and confirm continuous dimensions without page/table scrolling.

The wheel's colored pockets now end at radius 118 in the 320-unit SVG, with a
separate outer ball orbit at radius 137. Capture moves the ball inward by 47
units into its pocket. An 800ms acceleration ramp makes startup visible before
cruising and the existing capture/braking sequence; server phase duration and
settlement are unchanged. Portrait caps the board at 58dvh and reserves larger
controls and a taller information area.

The header offers GameHub an optional settings slot beside the game actions.
GameHub moves its existing settings control there and restores it on exit. The
connection dot and ping use GameHub's existing socket status and latency events,
matching Egyptian War without creating another polling loop.

A decorative vector hand follows the first 850ms of the spin clock: it approaches
the ball, flicks left, and withdraws. Pauses freeze its pose; late arrivals do
not replay it. Reduced motion hides it, and unmount cancels its animation with
the wheel. Static felt, layered rails, and raised owner-colored chip stacks add
board detail. Chip amounts sit below the discs so they do not cover the chips.
The portrait information panel fills the space remaining below the chip tray,
while the board retains its height cap. Outside labels use EVEN, ODD, and
2 to 1 for the column bets.

Red/black outside targets display colored diamonds instead of visible text;
the full bet names stay in their accessible labels and tooltips.

Wheel numbers face the center and occupy their own outer boxes at radii 100-118;
the ball passes over that band before landing at radius 90 in the separate
80-100 inner pocket band. A 650ms result camera gently centers and magnifies the
winning pocket after the wheel stops, with a gold highlight around the ball.
Pause/resume preserves camera progress; a new betting phase resets it. Reduced
motion keeps the whole wheel visible and retains just the pocket highlight.

Wheel number boxes have their own 1.8-unit gold borders; inner pocket dividers
keep the thinner 0.65-unit stroke, so the number ring reads as a separate band.

Red/black diamonds follow the cell proportions with an equal fluid inset on
all four sides, so every point floats near its border without touching it.

Hover, keyboard focus, and a 450ms touch hold preview covered pockets and the
selected stake's potential profit/return without submitting a bet. Releasing a
hold suppresses its synthetic click. Owned chip stacks open a native dialog to
update/remove that wager through existing server actions. The editor closes if
ownership/phase/permission changes; pending controls are disabled. Native dialog
focus trapping and Escape are retained, and the lock shortcut ignores dialogs.

Round receipts are cached locally for the current mounted match and rendered
once per results phase as one win/loss card per bet. The personal summary shows
stake, return, and signed net. A results modal opens 750ms after settlement to
allow the pocket zoom to finish, unless a platform modal is already open. It
closes on phase advancement and can reopen through Last round results. Match
and phase clocks remain authoritative and keep running. The scrollable receipt
area preserves the visible header/close button and summary; unmount cancels all
popup and touch-hold timers. Green seat cards carry a diagonal LOCKED IN stamp
without changing seat dimensions. No sound cues are added.

Split targets use gold seam strips oriented to their shared number edge; corner
and zero-trio junctions use small squares. Street, six-line, and first-four
bets use rectangular edge tabs marked 3, 6, and 4. Inside decorations reveal
within 28 CSS pixels of a fine desktop pointer, on hover/drop, or keyboard
focus. Touch and hybrid devices always show them. Only decorations fade;
transparent hit areas and placed chips remain present. Cached target centers
are rebuilt on layout changes, so pointer movement does not trigger repeated
layout reads, and classes change only when proximity changes. Pointer leave
and unmount clear proximity state; reduced motion disables the short fade.

Inside markers receive a cyan fill and thin gold perimeter near a pointer, keyboard focus, or chip drop target.
Their hit boxes and decoration proportions scale continuously back to the
original compact sizes as board width or height becomes constrained. The
gold perimeter stays visible with reduced shadows enabled; inactive markers retain their gold fill.

Inside marker enlargement is reserved for roomy boards; medium and small boards
retain compact decoration proportions. Hover/drop highlighting follows the
painted strip or square rather than outlining the larger invisible hit area.
Keyboard focus outlines the painted marker itself.

Post-review regressions preserve seat order when a reconnect replaces a member
ID, keep manually reopened results visible during same-phase broadcasts, and
ignore queued close events from a previous dialog once another editor is open.
Canceled touch holds suppress their following synthetic click; another pointer
cannot cancel an unrelated finger's hold. GameHub now recognizes native dialogs
when routing Escape and game shortcuts, so Escape dismisses the native popup.

Cached result summaries refresh pending-winner metadata if server eligibility
changes, without rebuilding receipt cards or resetting scroll/focus.


## Card inventory and reward foundation (2026-10-28)

`src/cards.ts` contains 72 documented definitions in design order: personal
temporary, public temporary, permanent; positive, neutral, risky, negative
within each group. Public cards retain silver frames with muted purple interiors;
other temporaries are silver and permanents gold. Negative to Positive is rare
and limited to one copy; Type Reversal is normal rarity. Their effect semantics
remain design work, including individually defined reversed effects.

Round 1 remains ordinary roulette. A 30-second reward draft precedes betting
from round 2 onward: temporary in rounds 2/3, permanent in round 4, repeating.
The server draws three distinct eligible offers with rare entries weighted 1:6
against regular entries. Explicit permanent copy caps exclude maxed cards.
Choosing grants exactly one copy; all choices can finish the phase early.
Connected players who time out receive a random offered card; disconnected
players receive none. Offline players get no new draft while absent. No
catch-up grant exists; the three supported effects trigger only on an accepted play. Reconnect retains owned
cards and an existing draft. Spectators and other players cannot see a hand
or private offers. Snapshots copy all arrays and card records.

On wide screens the bottom dock splits equally between the chip controls and
a fan of playing cards. Portrait stacks these controls. The compact
fan previews up to seven unique types; Check cards exposes the entire collection
in a scrollable native dialog. Duplicates use one card with an owned-count badge.
Each card places polarity at top left, name centered, count top right, and the
effect below. Inspecting cards never submits a gameplay action. Unsupported effects are
explicitly labeled Preview only; negative
cards remain in inventory for inspection rather than applying penalties yet.

Tests cover private snapshots, forged/stale/duplicate picks, schedule, rare
weights, copy eligibility, disconnected timeouts, reconnect retention, sorted
stacks, header placement, and draft-dialog lifecycle.

Real Edge checks at 1366x768, 1024x768, 844x390, 390x844, and
360x740 verified equal wide dock columns, all card-header positions, duplicate
counts, full-hand inspection, reward submission, cleanup, and no page overflow.
A real two-player GameHub session passed rounds 2 through 4, private inventories,
paused reward controls, native Escape dismissal, and portrait fitting with no
browser errors. Card names stay inside the compact fan; full effects are
available in the inspection dialog.


Card presentation corrections: cards use a fixed 5:7 playing-card aspect ratio.
Equal-width left/right header tracks center the name independently of badge
width. Neutral and Risky are separate indicators and catalogue sections, with
source order checked against design.md. The decorative hand is removed.
Only Check cards opens the collection; clicking a fan card does not. A pointer
hover or keyboard focus glows immediately and, after one second, shows a larger
single-card preview without changing layout. Leaving, switching phases, opening
a dialog, or unmounting clears the preview and timer. Touch users can inspect
full-size cards through Check cards.

The card dialog is larger (up to 1120px wide and 92dvh tall). Unresolved reward selection has no Close button and rejects Escape/native
cancel requests. Confirmed choices close immediately. The server's choice or timeout still advances the phase and
closes the required dialog. Optional collection inspection retains Close and
Escape. Tests cover those paths, including delayed-hover cancellation.

Responsive browser checks additionally confirm that constrained modal grids scroll
without compressing row tracks or overlapping cards, and full-card titles remain
centered independently of the left/right indicator text.


Card front styling now uses metallic silver temporary faces, rich gold permanent
faces, and purple public faces with silver rails. An etched inner frame and
small diamond ornaments provide detail without image downloads or animation.
The card type sits directly below the centered name. Effect copy is centered
horizontally and vertically within the remaining padded area. Only overflowing
copy shrinks; short descriptions retain their normal size. One shared card
ResizeObserver rechecks container changes, and is disconnected on unmount.
Pixel-rounding tolerance avoids shrinking text that already fits.

Card-back artwork has not been created. Current styling covers front faces only.

Effect categories now use high-contrast badges containing a symbol and text:
green + Positive, red minus Negative, blue-gray = Neutral, and amber ! Risky. The badge remains visible in the compact fan.
These use static CSS and retain lifetime-specific metallic faces and framing.

Reward choices have a soft, static category glow: green for Positive, red for
Negative, gray for Neutral, and amber for Risky. Hover or keyboard focus
strengthens the same glow. The reduced-shadows preference disables these
shadows while leaving the labeled badge and border accent visible.


Static surface textures now cover the betting cells themselves: fine weave on red/black cells and irregular felt patches on green areas, with wood-grain outer rails and gold inner trim.
Card fronts use fine crossed linen patterns above their existing metallic faces.
Draggable chips use eight ivory edge inserts, molded concentric rings, surface
grain, and a raised rim; the drag ghost retains the viewer's chip color and
shares the same finish. Table stacks use matching rim inserts. These are CSS
gradients and borders, with no images, filters, or continuous animations added.
Reduced shadows removes the new chip depth shadows while preserving textures.

Wheel decoration uses a static SVG brass gradient: an eight-point compass with
rounded joins and circular edging inside the 53-unit hub, plus eight alternating
radial/tangential diamond inlays at radius 131 in the fixed brown bowl. Inlays
stay outside the 118-unit numbered rotor, just inward of the wood midpoint; ball-path and
landing geometry are unchanged. No spin timings, result geometry, filters, or assets change.

Texture corrections use opaque, clipped card borders to prevent background
bleed, plus three soft, uneven specular patches within the face. Four separate
rail backgrounds follow each board edge. Green cells reveal one continuous
patchy felt surface rather than repeating the same grain in each cell. Each
brown wheel ring receives eight uneven clusters of three curved grain lines.
The outer diamond ring now has eight alternating shapes at radius 131. Neutral
badges and etched frames use blue-gray. Everything remains static and uses
CSS/SVG without additional image requests or animated shine.

The colored left-edge stripe is removed from cards; category badges and reward
glows provide category identification. The lowest shine patch is softened and
moved into the face, away from the purple card's bottom edge. Green felt uses
the felt patch layers: connected cross-hatching in irregular shading patches above the
broader mottling, with no runtime noise filter. Eight wheel diamonds sit at
radius 131, just inward of the wooden ring's midpoint.

The felt shading uses connected intersecting diagonal lines, rather than
individual X marks. Each irregular patch has a subtle dark-green radial shade
that fades outward into the base felt. Card shine at the upper left is softer
and more broadly feathered. The texture uses static SVG patterns and radial
gradients; it adds no animated noise or filter work.

The felt uses one broad cross-hatched field spanning the board in both
landscape and portrait. It scales with the board, with feathered elliptical
edges and fixed 9px line spacing, beneath betting cells, labels, and chips.
The temporary SVG texture asset is removed.

Bottom card diamonds are slightly larger and inset above the etched border
(9px ornament, 10px bottom inset; compact fan 4px/4px). Extra footer padding
keeps effect text and reward buttons clear of the ornament.

The reward picker closes immediately once the server confirms a chosen card,
including timeout choices. Players need not wait in a confirmation window for
other participants; Check cards remains available to inspect their collection.
Unresolved reward choices still cannot be dismissed.

Reward options use a native button for the entire card, plus a separate Choose
card button immediately below it; there are no nested buttons. Both submit
the same server-validated choice and disable while a request is pending. Native
Enter/Space activation is preserved. The scrollable card grid has 32px of inner
padding and inter-option spacing so the category glow clears its clipping edge,
including the first and last rows.

The betting-surface stack is the green base, transparent Egyptian War-style
felt (fine 22-degree fibres, 9px/11px dot patterns, subtle lighting),
cross-hatching, then betting cells and chips. Both texture layers ignore pointer input. The single shading field fits inside the rail and follows both board dimensions. Opaque red/black cells cover the texture underneath.

Card dialogs initially focus their heading instead of the first card. This
prevents native dialog autofocus from triggering the first reward's stronger
focus glow and delayed inspection preview. Tab still reaches the real card
buttons, whose keyboard focus indicator and activation remain available.

Cross-hatched shading uses low-contrast 1px lines spaced every 9px. Elliptical
masks fade gradually from the center instead of clipping patches to rounded
blob outlines. No blur filter is applied; textures stay below betting targets.

## First playable personal effects (2026-10-29)

`preparations` is a separate 30-second phase between betting and rolling. Both
readiness windows support lock/unlock and all-ready advancement; entering
preparations clears betting locks. All paid-bet edits are rejected afterwards.
The board, card hand, and lock control remain visible in both orientations.

The existing validated/retry-cached action route accepts `play-card` with a
card ID. The server verifies ownership, support, stage, readiness, connectivity,
pause, deadline, and safe payouts before consuming a copy. Supported IDs are
Profit up, More draws, and Double or nothing. Other cards are inspection-only.
Private snapshots expose `playableCardIds`; `playedCards` publicly records only
accepted plays and their owners, without exposing the remaining hand.

Profit up adds 20 percentage points to winning profit per copy. Returns use
BigInt intermediate arithmetic and floor per wager; public money remains safe
integer numbers. More draws adds two immutable free wagers on random legal
targets, each floor(balance / 20) at play time. Free wagers do not reserve cash
or return a stake. A stake below one or unsafe projected settlement rejects the
play without spending the card. Repeated paid and free wagers stay separate.

Double or nothing is once per round and uses a separate server draw only when
net betting profit is positive. It doubles or removes that profit after other
bonuses, leaving losing/zero rounds alone. Other copies remain owned. Exact
`settlements` carry staked cash, returned money, final net, gamble adjustment,
and optional gamble outcome; the browser lists that adjustment separately so
receipt totals explain the actual balance. Winner checks run afterwards.

Played effects and summaries reset for the next round; accepted effects and
free bets persist across pause, reconnect, and the original owner's departure.
Tests cover stage transitions, retry safety, consumption, additive/floored
bonuses, free wager accounting, both gamble outcomes, lock/pause guards,
reconnect, public announcements, and browser controls/results.

## Bank and debt accounting (2026-10-29)

Net balance = cash balance - outstanding debt. Available cash instead subtracts
reserved stakes from cash balance. Only net balance is compared with the winning
goal; borrowing adds cash and debt, and no surcharge is deducted from cash.

The bank uses existing validated, retry-cached `take-loan` and `repay-debt`
actions. Loans are betting-only and once per round, with principal capped at
floor(goal / 4) and a one-time floor(principal / 4) surcharge. Repayments accept
only unreserved cash during unlocked planning. All amounts are positive safe
integers; projected paid-wager returns remain checked after a loan. No timer,
repayment, or reconnect resets a player's borrowing allowance within a round.

Each participant owns match-local loan records with stable IDs, acquisition
round, principal, original debt, and remaining debt. Repayment allocates oldest
first. Viewer-specific `bank` state contains copied history, limits, and current
permissions; other viewers receive no history. Public balances expose total
cash, debt, and net balance. Pauses and reconnect socket rebinding preserve all
records; the room does not persist loans to disk or user accounts.

After settlement, qualifying participants automatically repay all debt before
winner comparisons. Round summaries record `debtRepaid` so the result panel
explains cash movement separately from betting profit. Goal and tie comparisons
use net balance (cash minus outstanding debt), preserving the existing last-participant win rule.

Call Bank and Last round results share a row below the wallet. The native bank dialog owns a
separate `.lr-bank-shell` and `.lr-bank-panel`, allowing future shark-mouth art
around the inner panel. Each form has four proportional value buttons, a range
slider, and a numeric field; values and exact fee previews update together.
Trusted snapshots drive availability. Pending actions disable submissions, and
phase changes dismiss the bank. The modal scrolls internally on short displays;
opening it does not pause play. Every bank listener is removed on unmount.

Bank tests cover limits, floored fees, malformed amounts, duplicate requests,
stage/role/pause/lock/disconnect guards, reserved-stake safety, oldest-first
repayment, bankruptcy recovery, next-round allowance, private defensive history,
reconnect retention, automatic payoff, and winner ordering by net balance.
Debt-relief cards remain unsupported previews in this pass.

Betting uses the board directly by clicking or dragging chips onto its targets.
The separate betting-space dropdown and Place selected bet button are removed.

The bank header sits outside the scrollable body, flush with the modal roof.
Loans and repayments use two columns when space permits, stacking on phones;
balance information, history, and rules follow below. Percentage presets use
green (25%), blue (50%), amber (75%), and rose (100%) alongside text labels.

The upper player row is grouped immediately below the title, independent of
the toolbar height. Six equal slots remain reserved even with fewer upper
players. In landscape, the row ends at the same edge as the table column.

Pre-commit review fixed a tiebreaker that kept requiring the original goal.
Once a tiebreaker begins, compare remaining contenders by net balance even
below the goal; a regression includes unpaid debt so gross cash cannot win.
