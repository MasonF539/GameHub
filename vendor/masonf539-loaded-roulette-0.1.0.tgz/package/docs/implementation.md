# Loaded Roulette Implementation

This is the current implementation reference for [the game design](design.md).
Last reviewed: 2026-11-11. Balance values remain adjustable through playtesting;
this document describes implemented behavior rather than an implementation diary.

## Source responsibilities

| File | Responsibility |
| --- | --- |
| `src/definition.ts` | Manifest, host settings, player-facing rules, scoreboard columns and keybinds. |
| `src/roulette.ts` | Single-zero pockets, 157 legal betting spaces, matching and base payouts. |
| `src/session.ts` | Authoritative phases, actions, participant ledgers, settlement, cards and lifecycle. |
| `src/cards.ts` | Ordered catalogue, card metadata, ownership limits and weighted reward draws. |
| `src/cardRules.ts` | Ownership helpers, card memory, polarity, public limits, targeted modifiers and tax caps. |
| `src/reversal.ts` | Owner-specific Type Reversal descriptions and activation stages. |
| `src/shop.ts` | Hybrid offers, frozen-average pricing, discounts and whole-money rounding. |
| `src/index.ts` | Package exports and plugin integration. |
| `public/client.js` | Board/card rendering, gestures, overlays, audio, input and mount cleanup. |
| `public/template.html`, `public/style.css` | Game markup, responsive boards, shop/bank, cards and presentation. |
| `src/*.test.ts` | Rules, sessions, privacy, lifecycle and DOM regressions. |

There are no separate economy or visibility modules: those responsibilities
currently live in the session. Extract them only when that reduces complexity.

## Match state and action validation

The session owns the match/phase IDs, round, deadline, pause state, contenders,
outcome, bets, public effects and once-only settlement. Each participant has a
stable match-local ID separate from their current socket/member ID, with cash,
loan records, card stacks, acquisition rounds, counters, shop offers, draft queues
and a bounded cache of the latest 128 request acknowledgements.

Reconnect remaps preserve participant order and all resources. All state is
match-local memory; the game does not require accounts or persistent player data.

Actions validate match and phase identity, role, connection, ownership, ready
state, pause/deadline, target and safe whole-number amounts before committing.
A repeated request ID with the same signature returns its original result;
changed content under the same ID is rejected. Late requests cannot reopen a
phase or replace a committed outcome. Any-time utility cards remain explicit
exceptions to ordinary stage/readiness restrictions.

Viewer snapshots copy mutable arrays and records. Public fields include bets,
balances, phase, public effects, confirmed plays and revealed results. Hands,
reward/shop offers, sale quotes, pending choices and transfer receipts are
viewer-specific. A blind hand exposes opaque shuffled options to the chooser;
the hand owner can see their own faces. Spectators receive no private choices.
Private card identities are never sent through broadcast notifications.

## Phase timing

| Phase | Duration and transition |
| --- | --- |
| Round 1 Betting | 60 seconds; goes directly to Rolling. |
| Rewards, from round 2 | 30 seconds shared by all queued drafts; ends when offers and mandatory choices finish. |
| Shop | 30 seconds or all-ready. |
| Public Effects | 30 seconds or all-ready, with server-held card animations. |
| Betting | 60 seconds or all-ready; closes wager editing. |
| Final Preparations | 30 seconds or all-ready. |
| Rolling | Six seconds, including final landing and a 750 ms stopped-wheel reveal. |
| Results | Five seconds before the next round or completion. |
| Winner announcement | Three seconds before returning to the lobby. |

The timers use `context.now()`. Pause saves remaining time; resume schedules the
same phase. Readiness can be undone until the phase advances. Shop/public/prep
are not silently skipped for an empty hand. No spectator counts toward readiness.
Required paid choices resolve eligible remaining options on timeout; connected
reward timeouts choose randomly, while disconnected players get no auto-reward.

The pocket is chosen once with trusted randomness when Rolling begins and stays
private until the landing segment. Clients animate the server schedule; animation
callbacks cannot settle money. Balances remain unchanged through the stopped-
wheel reveal and update only when the authoritative session enters Results.

## Money, payouts and settlement

Reserve accepted paid stakes; edits/removals adjust reservations. Free wagers
reserve no money. Cash is never negative. Uncovered card-caused deductions become
penalty debt, without a loan surcharge or consumption of a loan allowance.

For a winning paid bet, base payout is stake times (roulette profit multiplier
plus one). Additive payout modifiers apply to that full amount, including the
returned stake. Free bets have no returned paid stake: their base payout is
stake times the roulette profit multiplier, then the same payout modifiers.
A losing wager has no winning payout; eligible refunds are calculated separately.

Positive payout bonuses, growth rates and caps were halved in the 2026-11-11
rebalance. Negative card magnitudes remain unchanged. Growth can include half
percentage points: Shopping Spree adds 0.5% per purchase, for example. MinMax
multiplies positive bonus components by 1.05 per copy, not the base payout.
Non-payout grants, debt relief, refunds, taxes, free-stake coverage and prices
retain their own original values. Type Reversal preserves each revised card's
magnitude and accumulated progress, not another card's opposite definition.

Calculation order:

1. Calculate winning payouts with additive bonuses/reductions and explicit
   positive-bonus multipliers. The combined reduction stops at 80% of base payout.
2. Calculate per-wager losing-stake refunds and any extra wager penalties.
3. Derive round betting net and apply Double or nothing, then Double Everything.
4. Resolve taxes from the same pre-tax snapshot and net opposing transfers.
5. Apply debt relief, fees and qualifying winner repayment; check the winner.

Payout rates use exact basis-point/BigInt arithmetic, including fractional growth
and repeated MinMax copies. Floor once at the monetary division. Safe-range
checks run before accepting actions that could overflow settlement. Host money
settings and final monetary values remain whole numbers; Shop has its separate
nearest-unit/nearest-five rounding rule.

An 80% payout reduction can return less than the original paid stake even when
the roulette target matches. It does not protect against later taxes, gambles or
fees. Losing paid stakes are not counted again as an additional card penalty.

Receipts retain base return, card adjustment, returned amount, profit and any
extra penalty. Round summaries separately retain wagers, returned money, net,
gamble outcome/adjustment, tax, fees and debt repayment. A repayment never reduces
the recorded roulette return. Results color net green/red and explain a won bet
followed by a lost Double or nothing in that bet's existing receipt.

Double or nothing can be played once per round and gambles only positive net
betting profit, using a separate 50/50 draw. Double Everything copies multiply
net gain or loss. They do not double total wealth, shop spending or loan proceeds.

Tax claims use eligible betting profit, not returned stakes or incoming tax.
TAX triggers at a combined round-profit threshold of 10% of the goal. Cap claims
at 50% of the payer's qualifying profit and floor each proportional share without
redistributing rounding dust. Parking Tax targets the exact spot; reversed
Parking Tax subsidizes winners from its owner's cash, with overflow penalty debt.

## Bank

Borrow during Shop or Betting, normally once per round, up to 25% of the goal.
The default surcharge is 25%; Bad Credit and played Paperwork alter their stated
terms. Repayment and relief do not restore borrowing allowance. Track loans
individually; repay oldest debt first, including penalty debt. Loan Relief uses
the latest actual loan's original debt, capped by its unpaid amount; Debt
Reduction includes total outstanding debt.

The bank modal has side-by-side loan/repayment forms where space permits, percent
presets, slider and whole-number input. It distinguishes cash, available cash,
debt and net balance. It remains reachable over Shop and has no shark animation.

## Cards, rewards and shops

Use the catalogue in the design for individual effects, limits and current values;
do not maintain a second conflicting catalogue here. Ownership is stacked by
card ID, with per-card acquisition arrays and counters. Removing a held card stops
future effects without undoing settled actions. Discard/reacquisition resets that
card's growth where specified; reversal alone preserves it. Already-played
cards retain committed direction even if reversal parity changes later.

Round 1 has no cards. Round 2/3 reward temporary cards, round 4 permanent, then
repeat every three rounds. More Cards uses an independent 6:1 temporary/permanent
type roll; rare cards have weight 1 versus ordinary weight 6 within their pool.
Drafts exclude maxed cards, avoid repeats when enough alternatives exist, and
return fewer choices when the eligible pool is smaller. Recheck caps on choice
and timeout. Reward Reroll preserves draft type, choice count and remaining time.

Specialist assignment is mandatory as soon as possible after Shop. It cannot be
cancelled, and timeout assigns an eligible spot. Third Times the Charm counts
owned betting rounds with paid input, snapshots cash at Betting entry and makes
up to 20% per copy free (maximum 100%); excess wagers stay paid. Card-created free
bets and abstention do not advance it. More Cards/Choices alternate from rounds
after acquisition until two copies activate every round. More the Merrier's
extra public use has a one-round cooldown until a second copy removes it.
Alternating passives privately notify activation; fixed bonuses do not spam alerts.

Cold Streak uses the first positive-net betting round before its own reduction
and gambles. Short Changed affects next-round wins and expires after that round
even without wins. Other delayed negative cards use their catalogue timing;
suppression does not refund resolved charges. Patient Investor can grow after
a no-purchase acquisition round. Debt-Free Dividend checks debt at settlement.

Shops contain seven regular offers plus a separate 25-75%-off deal. Regular
selection is three shared temporary/public, one shared permanent, two personal
temporary/public and one personal permanent. Shared choices are common; stock
is independent. Shop Reroll replaces every slot for that owner, including shared
positions, without changing anyone else's offers.

Freeze contenders' average net when Shop opens, including offline contenders,
excluding spectators/departed players and tiebreaker outsiders. Reuse it through
that round's rerolls. Regular price is
`(4*start + 4*max(0,averageNet) + goal) * typeRate * rarityMultiplier / 200`.
Type rate is 1 or 3 for temporary/public versus permanent; rare price multiplier
is 2. Round below 20 to units, otherwise to fives, minimum 1. Personal price
modifiers and deal discounts remain separate. Buying once marks a slot sold out;
maxed ownership is distinct from sold-out stock.

Quick Sale may sell negatives and its reversed form randomly sells an eligible
card. Reseller operates through inventory selection during Shop, excludes current
negatives, and charges instead of paying when reversed. Sale quotes are private.
On Hold preserves one exact next-shop offer and its price/discount; its reversal
blocks one random next-shop offer. Both expire at the stated Shop boundary.

Public plays resolve in acceptance order. A global play reserves 1,400 ms; a
spot-targeted play reserves 1,550 ms for pop plus placement. The server holds the
stage timer and rejects overlapping submissions without consuming cards. Exact-
spot effects can target combinations/outside spaces where allowed; Crowd
Favorite, Lone Wolf and Free Entry remain number-only. White Out/Erase affect
attached statuses, never global modifiers; Copycat/Relocation preserve restrictions.

Theft/swap targets include public temporary cards, never permanent cards. Unspent
targeting can cancel; paid peeks/trades cannot. If a revealed card disappears,
retain only originally revealed choices still held; do not reveal replacements.
Timeout resolves mandatory eligible choices. Reclaim requires a valid theft link;
spending/trading that copy invalidates it. Interceptions resolve in order, with
at most one recipient per chosen reward; competing claims expire on that draft.

## Membership, pauses and winning

Optional `context.admitSpectator()` admits connected spectators only at a normal
round boundary when enabled, below 12 players, and outside tiebreakers. Older
hosts without this service keep them as viewers. GameHub owns room roles, dynamic
client-role updates, host transfer and reconnect tokens.

Entry assistance replaces the normal entry draft. Through the entry round,
permanent scheduled count is `floor((round-1)/3)` and temporary count is
`round-1-permanent`. Halve each count and round up, with two offers per assistance
card. Returning players keep resources and get half only missed normal rewards,
not missed More Cards triggers, at the next connected Rewards stage. Queued
drafts share the 30-second timer. Unchosen assistance survives a disconnect;
connected timeout drains eligible drafts randomly. Count each missed reward once.

Each disconnect starts/resets a 60-second recovery pause. Automatic early resume
waits for all missing participants; the host may resume earlier. Manual pause
intent remains independent. Reconnect preserves bets, cards, debts, draft queues
and the current loan allowance. No missing bets or purchases are invented.

Departures remove future eligibility/triggers but preserve committed actions.
Outstanding spin wagers settle into their former owner's retained ledger. With
one remaining player, finish after a pending spin or immediately outside Rolling;
with none, finish without a winner. Highest qualifying net balance wins after
settlement and debt repayment; tied highest qualifiers continue alone with shops
and rewards. No new participants enter those tiebreakers.

## Browser presentation and lifecycle

The order is title, excess seats 7-12, main board, seats 1-6, timer and bottom
actions. The table changes orientation with the viewport, retaining upright text.
Only the active betting board or wheel is shown. Player colors match seats,
chips/ghosts/stacks and card backs. The details sidebar collapses to a wallet tray
on phones and expands the same live controls into a full-screen native dialog.
Bank, scoreboard and choice overlays close that details view before opening.

Card layout, textures, categories, shop booth and theft fans follow the design.
Only the bottom hand has a one-second enlarged hover/focus inspection. Instant
plays keep inventory open with confirmation; choices expose their target UI.
Public animations reach everyone; personal animations and transfer reveals remain
private. Required pickers cannot dismiss; confirmed reward picks close promptly.

Wheel motion accelerates, decelerates and lands inward before the stopped reveal.
Reduced-motion and general graphics preferences preserve deadlines and outcomes.
The timer uses a scale animation with separate readable countdown updates.
Stage ribbons identify Public Effects, Betting and Final Preparations.

Default game keys: R ready/cancel, E cards, B bank, F results, 1-5 chip presets,
6 Max. GameHub Tab toggles the scoreboard; Shift+Tab and other dialogs/typing
retain focus navigation. Custom chip amounts accept exact k/m expansion; numeric
bank/editor inputs remain whole-money fields. Hover audio restarts per new card.

MP3 assets live in `public/assets/audio/music/` and `effects/`. Music is
`background-music.mp3`; wheel/ball, card pick/play/hover, chip, purchase, stage and
win effects use the imported recordings. Variant effects avoid immediate repeats.
Playback stops appropriately on pause, hidden tabs, phase exit and unmount. The
placeholder generator does not overwrite imported effects. One Audio settings
tab controls separate music/effect groups.

The scoreboard is a modal with Bets won, Money gained, Money spent, Cards played,
Biggest bet win and Ping. No match wins/reset action is present. Money gained
includes gross payouts and cash rewards/sales/taxes, excluding starting cash and
loans. Spending includes paid stakes, purchases, repayments and deductions,
excluding cancelled reservations and unpaid debt. Biggest win is per-bet profit
before round-wide gambles/taxes. Totals reset on a new game and survive reconnects.
Disconnected status uses the cable icon; there is no duplicate inline ping dot.

A compact gold winner announcement shows name/net balance, followed by a lobby
review of most-used cards and resolved-use counts. Review opt-in clears on mount
and destroy; GameHub clones only the completed game's review. Another game's
completion must not display this review.

## Rendering performance and cleanup

Retain unchanged shop offers, selected detail, seats, chip stacks, full bet lists,
activity/history rows and closed scoreboards. Render keys include their displayed
fields; changed owners, amounts, permissions and compact modes still update.
Batch card-font writes/measurements and avoid fitting the obscured shop hand.
Retain authorized target highlights/cutouts, but refresh pending/pause/choice
permissions and remeasure geometry on reconciliation and resize.

Build reservation totals once per viewer snapshot and index immutable card
definitions. Action validation still reads live state; no viewer result or hidden
state is cached across requests. Do not change message cadence, animation timing
or approved graphics as an incidental optimization.

Unmount removes listeners, input subscriptions, timers, observers, dialogs,
animations, audio handles and gesture ghosts. Async replies check mount/match/
phase identity before updating UI. Repeated mounting must not retain resources.

## Verification and development packaging

Run `npm run check` and `npm test`. Coverage includes legal pockets and zero,
payout modifiers/fractional growth, equal-coverage arrangements, reservations,
refunds, gambles, taxes, debt, copy caps, privacy, retries, deadlines, disconnects,
admission/catch-up, target choices, dialogs, keyboard/touch behavior and teardown.

GameHub installs this private package from its reviewed local tarball. After
runtime changes, repack and refresh that normal installation, then run GameHub's
fresh-consumer verifier and browser smoke checks. Do not publish a registry
version solely to test local work. The live tunnel, physical iPhones, subjective
audio and long multiplayer sessions still require their own checks; desktop
browser CPU throttling does not establish real-device frame rates.

See GameHub's `docs/roulette-optimization-review.md` for measured optimizations
and proposals left for review. Custom wheel slots, Protective Seal, configurable
timers, visual bank/shop redesign and other deferred ideas stay in the design's
later-additions section, not scattered implementation prompts.
