/** Registers the browser renderer; all money and roulette outcomes remain server-authoritative. */
(function registerLoadedRoulette() {
  window.GameHubRegisterGameClientModule("loaded-roulette", {
    /** Mounts the betting board, chip controls, wheel, and owned cleanup resources. */
    mount(context) {
      /** Game-scoped queries prevent one plugin from changing another game's controls. */
      const root = context.root;
      /** Returns a required element from this game's own markup. */
      const find = selector => { const element = root.querySelector(selector); if (!element) throw new Error(`Missing Loaded Roulette element: ${selector}`); return element; };
      /** Stable UI elements are retained so timer ticks never rebuild the board or form. */
      const table = find("[data-lr-table]"), players = find("[data-lr-players]");
      const amountInput = find("[data-lr-amount]"), chips = find("[data-lr-chips]"), spaceSelect = find("[data-lr-space]");
      const form = find("[data-lr-bet-form]"), lockButton = find("[data-lr-lock]"), pauseButton = find("[data-lr-pause]"), leaveButton = find("[data-lr-leave]");
      const timerLabel = find("[data-lr-timer]"), timerFill = find("[data-lr-timer-fill]"), status = find("[data-lr-status]");
      const wheel = find("[data-lr-wheel]"), ownBets = find("[data-lr-own-bets]"), allBets = find("[data-lr-all-bets]");
      /** The last trusted snapshot and local presentation deadline; no client value grants money. */
      let state = null, localDeadline = null, recoveryDeadline = null, pending = false, destroyed = false, selectedSpace = "straight:0", sequence = 0;
      /** Board nodes and bet rows remain stable while other players submit actions. */
      const targets = new Map(), cells = new Map(), rows = new Map();
      let catalog = new Map(), selectedChip = 100, hoverSpace = null, suppressClickUntil = 0;
      /** These handles are cancelled when a new phase arrives or the game is unmounted. */
      let timerAnimation = null, wheelAnimations = [], wheelKey = "", rotor = null, ball = null;
      /** A pointer gesture works with mouse, pen, and touch instead of desktop-only HTML dragging. */
      let drag = null, ghost = null;
      const compact = window.matchMedia("(max-width: 575.98px)");
      const landscape = window.matchMedia("(orientation: landscape)");
      const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");

      /** Formats whole in-game money without hiding its exact value. */
      function money(value) { return Number(value).toLocaleString(); }
      /** Uses short chip labels while exact amounts remain in accessible labels and the bet list. */
      function shortMoney(value) { return value >= 1_000_000 ? `${Number((value / 1_000_000).toFixed(1))}m` : value >= 1_000 ? `${Number((value / 1_000).toFixed(1))}k` : String(value); }
      /** Finds the viewer's current participant record, including the stable chip-owner ID. */
      function localPlayer() { return state?.balances.find(player => player.id === context.memberId) ?? null; }
      /** Returns one to ten visual chips, or one to five on small screens; the first band starts at $1. */
      function stackHeight(stake, balance) { const maximum = compact.matches ? 5 : 10; return Math.max(1, Math.min(maximum, Math.ceil(stake / Math.max(1, balance) * maximum))); }
      /** Creates text-only elements so player names and messages cannot inject HTML. */
      function element(tag, className, text) { const node = document.createElement(tag); if (className) node.className = className; if (text !== undefined) node.textContent = text; return node; }
      /** Submits one intent tied to the current match/phase and ignores replies after unmount. */
      async function submit(type, payload) {
        if (!state || pending || destroyed) return;
        pending = true; renderControls();
        const requestId = window.crypto?.randomUUID?.() ?? `${Date.now()}_${++sequence}`;
        try {
          const response = await context.submitAction({ type, payload: { ...payload, matchId: state.matchId, phaseId: state.phaseId, requestId } });
          if (!destroyed && !response.success) context.notify(response.message ?? "The action was not accepted.");
        } catch { if (!destroyed) context.notify("The action could not be sent. Check your connection."); }
        finally { if (!destroyed) { pending = false; renderControls(); } }
      }
      /** Places the chosen chip amount; the server checks cash, lock state, and the legal target again. */
      function place(spaceId, chipAmount = Number(amountInput.value)) {
        if (!state?.canBet || pending || destroyed) return;
        const amount = chipAmount;
        if (!Number.isSafeInteger(amount) || amount <= 0) { context.notify("Choose a positive whole chip value."); return; }
        if (amount > (localPlayer()?.available ?? 0)) { context.notify("That chip is larger than your available money."); return; }
        selectedSpace = spaceId; spaceSelect.value = spaceId; highlight(spaceId);
        void submit("place-bet", { spaceId, amount });
      }
      /** Selects a denomination or custom value without spending it. */
      function selectChip(value) { selectedChip = value; amountInput.value = String(value); renderControls(); }
      /** Highlights the complete covered-number set before or during a drop. */
      function highlight(spaceId) {
        const space = catalog.get(spaceId); hoverSpace = spaceId;
        for (const [id, target] of targets) target.classList.toggle("is-targeted", id === spaceId);
        for (const [number, cell] of cells) cell.classList.toggle("is-covered", space?.numbers.includes(number) === true);
        find("[data-lr-selection]").textContent = space ? `${space.label} \u00b7 ${space.profitMultiplier}:1 profit \u00b7 covers ${space.numbers.join(", ")}` : "Choose a betting target.";
      }
      /** Creates an accessible click/drop target; its stable ID is the only target sent to the server. */
      function makeTarget(space, className, text) {
        const target = element("button", className, text); target.type = "button"; target.dataset.betSpace = space.id;
        target.title = `${space.category}: ${space.label} \u00b7 ${space.profitMultiplier}:1 profit`;
        target.setAttribute("aria-label", target.title); targets.set(space.id, target);
        const marker = element("span", "lr-space-chips"); marker.setAttribute("aria-hidden", "true"); target.append(marker);
        return target;
      }
      /** Builds number cells plus separate seam/intersection targets, never nesting one button inside another. */
      function buildBoard() {
        table.replaceChildren(); spaceSelect.replaceChildren(); targets.clear(); cells.clear();
        for (let number = 0; number <= 36; number++) {
          const cell = element("div", `lr-number-cell${number === 0 ? " lr-zero-cell" : ""}`);
          const color = number === 0 ? "green" : catalog.get("red").numbers.includes(number) ? "red" : "black";
          const button = makeTarget(catalog.get(`straight:${number}`), `lr-number lr-${color}`, String(number)); cell.append(button); table.append(cell); cells.set(number, cell);
        }
        const groups = new Map();
        for (const space of catalog.values()) {
          let group = groups.get(space.category);
          if (!group) { group = element("optgroup"); group.label = space.category; groups.set(space.category, group); spaceSelect.append(group); }
          const option = element("option", "", `${space.label} (${space.profitMultiplier}:1)`); option.value = space.id; group.append(option);
          if (space.category === "Straight up") continue;
          if (space.category === "Outside") table.append(makeTarget(space, `lr-outside-target${["red", "black"].includes(space.id) ? ` lr-${space.id}` : ""}`, space.id.startsWith("column:") ? "2:1" : space.id.startsWith("dozen:") ? ["1st 12", "2nd 12", "3rd 12"][Number(space.id.split(":")[1]) - 1] : space.label));
          else {
            const target = makeTarget(space, `lr-seam lr-seam-${space.category.toLowerCase().replaceAll(" ", "-")}`, space.category === "Street" ? "3" : space.category === "Six line" ? "6" : "\u2022");
            table.append(target);
          }
        }
        spaceSelect.value = selectedSpace; layoutBoard();
      }
      /** Maps the conventional portrait table into landscape without rotating any text. */
      function placeCell(node, column, row, width = 1, height = 1) {
        if (landscape.matches) [column, row, width, height] = [row, 8 - column - width, height, width];
        node.style.gridColumn = `${column} / span ${width}`;
        node.style.gridRow = `${row} / span ${height}`;
      }
      /** Fits the game below the hub header and lays out every betting cell on one board. */
      function layoutBoard() {
        if (destroyed) return;
        const game = find(".lr-game"), viewport = window.visualViewport;
        const bottom = viewport ? viewport.height + viewport.offsetTop : window.innerHeight;
        game.style.height = `${Math.max(0, bottom - game.getBoundingClientRect().top - 8)}px`;
        for (const [number, cell] of cells) {
          if (number === 0) placeCell(cell, 3, 1, 3);
          else placeCell(cell, (number - 1) % 3 + 3, Math.floor((number - 1) / 3) + 2);
        }
        for (let group = 1; group <= 3; group++) {
          const dozen = targets.get(`dozen:${group}`), column = targets.get(`column:${group}`);
          if (dozen) placeCell(dozen, 2, 2 + (group - 1) * 4, 1, 4);
          if (column) placeCell(column, group + 2, 14);
        }
        for (const [index, id] of ["low", "even", "red", "black", "odd", "high"].entries()) {
          const target = targets.get(id); if (target) placeCell(target, 1, 2 + index * 2, 1, 2);
        }
        positionTargets();
      }
      /** Places seams at shared cell edges in either orientation; streets use the outer number edge. */
      function positionTargets() {
        if (!catalog.size || destroyed) return;
        const bounds = table.getBoundingClientRect();
        const boxes = new Map([...cells].map(([number, cell]) => { const rect = cell.getBoundingClientRect(); return [number, { left: rect.left - bounds.left, right: rect.right - bounds.left, top: rect.top - bounds.top, bottom: rect.bottom - bounds.top }]; }));
        for (const space of catalog.values()) {
          if (["Straight up", "Outside"].includes(space.category)) continue;
          const target = targets.get(space.id), covered = space.numbers.map(number => boxes.get(number));
          if (!target || covered.some(box => !box)) continue;
          let x = (Math.max(...covered.map(box => box.left)) + Math.min(...covered.map(box => box.right))) / 2;
          let y = (Math.max(...covered.map(box => box.top)) + Math.min(...covered.map(box => box.bottom))) / 2;
          if (["Street", "Six line"].includes(space.category) || space.id === "first-four") {
            if (landscape.matches) y = Math.min(...covered.map(box => box.top)) - 8;
            else x = Math.max(...covered.map(box => box.right)) + 8;
          }
          target.style.left = `${x}px`; target.style.top = `${y}px`;
        }
      }
      /** Builds the tray once; each chip is also a touch/mouse drag source. */
      function buildChips() {
        for (const value of [1, 10, 100, 1_000, 10_000, "custom"]) {
          const chip = element("button", "lr-chip", value === "custom" ? "Custom" : shortMoney(value)); chip.type = "button"; chip.dataset.chipValue = String(value); chips.append(chip);
        }
      }
      /** Cancels any active gesture without placing a wager. */
      function cancelDrag() { ghost?.remove(); ghost = null; drag = null; for (const target of targets.values()) target.classList.remove("is-drop-target"); }
      /** Begins a possible drag; a click still simply chooses the chip. */
      function pointerDown(event) {
        const chip = event.target.closest("[data-chip-value]"); if (!chip || chip.disabled || event.button !== 0 || !state?.canBet) return;
        const value = chip.dataset.chipValue === "custom" ? Number(amountInput.value) : Number(chip.dataset.chipValue);
        selectChip(value); drag = { pointerId: event.pointerId, x: event.clientX, y: event.clientY, value, moving: false, source: chip };
        chip.setPointerCapture?.(event.pointerId);
      }
      /** Moves a chip ghost and previews the legal target under the pointer, including narrow seams. */
      function pointerMove(event) {
        if (!drag || event.pointerId !== drag.pointerId) return;
        if (!drag.moving && Math.hypot(event.clientX - drag.x, event.clientY - drag.y) < 6) return;
        drag.moving = true; event.preventDefault();
        if (!ghost) { ghost = element("span", "lr-chip lr-drag-ghost", shortMoney(drag.value)); ghost.setAttribute("aria-hidden", "true"); document.body.append(ghost); }
        ghost.style.left = `${event.clientX}px`; ghost.style.top = `${event.clientY}px`;
        const target = document.elementFromPoint(event.clientX, event.clientY)?.closest("[data-bet-space]");
        for (const button of targets.values()) button.classList.toggle("is-drop-target", button === target);
        if (target && root.contains(target) && hoverSpace !== target.dataset.betSpace) highlight(target.dataset.betSpace);

      }
      /** Drops a dragged chip once; ordinary target clicks are suppressed immediately after a drop. */
      function pointerUp(event) {
        if (!drag || drag.pointerId !== event.pointerId) return;
        const moving = drag.moving, amount = drag.value, target = document.elementFromPoint(event.clientX, event.clientY)?.closest("[data-bet-space]");
        cancelDrag();
        if (moving) { suppressClickUntil = performance.now() + 350; if (target && root.contains(target)) place(target.dataset.betSpace, amount); }
      }
      /** Routes chip selection and table clicks without installing a listener on every betting space. */
      function rootClick(event) {
        const chip = event.target.closest("[data-chip-value]");
        if (chip && !chip.disabled) { selectChip(chip.dataset.chipValue === "custom" ? Number(amountInput.value) : Number(chip.dataset.chipValue)); return; }
        const target = event.target.closest("[data-bet-space]");
        if (target && !target.disabled && performance.now() >= suppressClickUntil) place(target.dataset.betSpace);
      }

      /** Rebuilds compact public standings; reserved stakes never look like already-settled losses. */
      function renderPlayers() {
        players.replaceChildren();
        for (const player of state.balances) {
          const card = element("div", `lr-player${player.id === context.memberId ? " is-local" : ""}`); card.style.setProperty("--player-color", player.color);
          card.append(element("strong", "", `${player.avatar} ${player.name}${!player.isConnected ? " \u00b7 offline" : ""}`), element("span", "", `${money(player.balance)} total`), element("small", "", `${money(player.available)} available \u00b7 ${money(player.reserved)} on table${player.locked ? " \u00b7 locked" : ""}${!player.isParticipating ? " \u00b7 watching tiebreaker" : ""}`)); players.append(card);
        }
      }
      /** Draws owner-colored stacks; small wagers start at one chip and high wagers cap at ten or five. */
      function renderTableChips() {
        const owners = new Map(state.balances.map(player => [player.participantId, player]));
        const grouped = new Map();
        for (const bet of state.bets) { if (!grouped.has(bet.spaceId)) grouped.set(bet.spaceId, []); grouped.get(bet.spaceId).push(bet); }
        for (const [spaceId, target] of targets) {
          const marker = target.querySelector(".lr-space-chips"); marker.replaceChildren();
          const bets = grouped.get(spaceId) ?? [];
          // A crowded target shows up to three stacks; the exact full owner list remains in All table bets.
          const ordered = [...bets].sort((a, b) => Number(b.ownerId === localPlayer()?.participantId) - Number(a.ownerId === localPlayer()?.participantId));
          for (const bet of ordered.slice(0, 3)) {
            const owner = owners.get(bet.ownerId), height = stackHeight(bet.amount, owner?.balance ?? bet.amount);
            const stack = element("span", "lr-chip-stack"); stack.style.setProperty("--chip-color", owner?.color ?? "#aaa");
            stack.title = `${owner?.name ?? "Departed player"}: ${money(bet.amount)} (${height} visual chips)`;
            for (let index = 0; index < height; index++) { const disc = element("span", "lr-chip-disc"); disc.style.setProperty("--stack-index", String(index)); stack.append(disc); }
            stack.append(element("span", "lr-stack-amount", shortMoney(bet.amount))); marker.append(stack);
          }
          if (bets.length > 3) marker.append(element("span", "lr-extra-owners", `+${bets.length - 3}`));
          const description = catalog.get(spaceId);
          target.setAttribute("aria-label", `${description.category}: ${description.label}; ${description.profitMultiplier}:1 profit${bets.length ? "; " + bets.map(bet => `${owners.get(bet.ownerId)?.name ?? "Departed player"} ${money(bet.amount)}`).join(", ") : ""}`);
        }
      }
      /** Updates keyed own-bet rows without throwing away an amount field currently being edited. */
      function renderBets() {
        const local = localPlayer(), mine = state.bets.filter(bet => bet.ownerId === local?.participantId);
        const ids = new Set(mine.map(bet => bet.id));
        for (const [id, row] of rows) if (!ids.has(id)) { row.remove(); rows.delete(id); }
        ownBets.querySelector(".lr-empty")?.remove();
        for (const bet of mine) {
          let row = rows.get(bet.id);
          if (!row) {
            row = element("li", "lr-own-bet"); const label = element("span"), input = element("input"), update = element("button", "", "Update"), remove = element("button", "", "Remove");
            input.type = "number"; input.min = "1"; input.step = "1"; input.inputMode = "numeric"; input.setAttribute("aria-label", `Stake for ${catalog.get(bet.spaceId).label}`);
            update.type = remove.type = "button";
            update.addEventListener("click", () => void submit("change-bet", { betId: bet.id, amount: Number(input.value) }));
            remove.addEventListener("click", () => void submit("remove-bet", { betId: bet.id }));
            row.append(label, input, update, remove); rows.set(bet.id, row); ownBets.append(row);
          }
          row.firstElementChild.textContent = catalog.get(bet.spaceId).label;
          const input = row.querySelector("input"); if (document.activeElement !== input) input.value = String(bet.amount);
          input.max = String((local?.available ?? 0) + bet.amount);
          for (const control of row.querySelectorAll("button, input")) control.disabled = !state.canBet || pending;
        }
        if (!mine.length) ownBets.append(element("li", "lr-empty", state.phase === "betting" ? "No bets placed. Abstaining is allowed." : "Betting is closed."));
        allBets.replaceChildren();
        for (const bet of state.bets) { const owner = state.balances.find(player => player.participantId === bet.ownerId); const item = element("li", "", `${owner?.name ?? "Departed player"} \u00b7 ${catalog.get(bet.spaceId)?.label ?? bet.spaceId} \u00b7 ${money(bet.amount)}`); item.style.borderLeftColor = owner?.color ?? "#aaa"; allBets.append(item); }
      }
      /** Keeps affordability, readiness, and host permissions synchronized without overwriting the typed amount. */
      function renderControls() {
        const local = localPlayer(), available = local?.available ?? 0, canBet = state?.canBet === true && !pending;
        amountInput.disabled = !canBet; amountInput.max = String(available); spaceSelect.disabled = !canBet;
        find("[data-lr-place]").disabled = !canBet; find("[data-lr-max]").disabled = !canBet || available <= 0;
        const amount = Number(amountInput.value);
        for (const chip of chips.querySelectorAll("[data-chip-value]")) {
          const custom = chip.dataset.chipValue === "custom", value = custom ? amount : Number(chip.dataset.chipValue);
          chip.disabled = !canBet || !Number.isSafeInteger(value) || value <= 0 || value > available;
          chip.setAttribute("aria-pressed", String(custom ? ![1, 10, 100, 1_000, 10_000].includes(selectedChip) : value === selectedChip));
          chip.setAttribute("aria-label", `Select or drag ${money(value)} chip${custom ? " (custom value)" : ""}`);
          if (custom) chip.textContent = "Custom";
          chip.style.setProperty("--chip-color", local?.color ?? "#ffe08a");
        }
        for (const target of targets.values()) target.disabled = !canBet;
        lockButton.disabled = !state?.canLock || pending; lockButton.textContent = state?.isLocked ? "Unlock bets" : "Lock in"; lockButton.setAttribute("aria-pressed", String(state?.isLocked === true));
        pauseButton.hidden = !context.isHost; pauseButton.disabled = !state || state.phase === "finished"; pauseButton.textContent = state?.isPaused ? "Resume" : "Pause";
        leaveButton.textContent = context.isHost ? "End game" : "Leave game";
        find("[data-lr-wallet]").textContent = local ? `${money(available)} available / ${money(local.balance)} total \u00b7 goal ${money(state.targetGoal)}` : "Spectating \u00b7 bets are read-only.";
        if (state) renderBets();
        if (!canBet && drag) cancelDrag();
      }
      /** Cancels presentation animations without changing the server-owned clock or result. */
      function clearAnimations() { timerAnimation?.cancel(); timerAnimation = null; for (const animation of wheelAnimations) animation.cancel(); wheelAnimations = []; }
      /** Refreshes countdown text only when needed; the fill uses a compositor-friendly scale animation. */
      function renderClock() {
        if (!state || destroyed) return;
        const recoveryText = recoveryDeadline === null ? "" : `Disconnect pause: ${Math.max(0, Math.ceil((recoveryDeadline - performance.now()) / 1000))} seconds remaining. The host may resume now.`;
        const recovery = find("[data-lr-recovery]"); if (recovery.textContent !== recoveryText) recovery.textContent = recoveryText;
        const remaining = state.isPaused || localDeadline === null ? state.remainingMs : Math.max(0, localDeadline - performance.now());
        const text = `${state.isPaused ? "Paused \u00b7 " : ""}${Math.ceil(remaining / 1_000)}s`;
        if (timerLabel.textContent !== text) timerLabel.textContent = text;
        const percent = Math.max(0, Math.min(100, remaining / Math.max(1, state.phaseDurationMs) * 100));
        const value = String(Math.round(percent)); if (timerFill.parentElement.getAttribute("aria-valuenow") !== value) timerFill.parentElement.setAttribute("aria-valuenow", value);
        if (!timerAnimation) timerFill.style.transform = `scaleX(${percent / 100})`;
      }
      /** Creates a vector wheel from the server's pocket order; no image-generation asset is required. */
      function buildWheel(order) {
        const namespace = "http://www.w3.org/2000/svg";
        /** Creates an SVG element with fixed presentation attributes. */
        const svgElement = (name, attributes) => { const node = document.createElementNS(namespace, name); for (const [key, value] of Object.entries(attributes)) node.setAttribute(key, String(value)); return node; };
        rotor = svgElement("g", { class: "lr-wheel-rotor" }); const radius = 132, delta = 360 / order.length;
        for (let index = 0; index < order.length; index++) {
          const number = order[index], start = (index * delta - delta / 2 - 90) * Math.PI / 180, end = (index * delta + delta / 2 - 90) * Math.PI / 180;
          const color = number === 0 ? "#15804c" : catalog.get("red").numbers.includes(number) ? "#bc3441" : "#17212d";
          rotor.append(svgElement("path", { d: `M160 160 L${160 + Math.cos(start) * radius} ${160 + Math.sin(start) * radius} A${radius} ${radius} 0 0 1 ${160 + Math.cos(end) * radius} ${160 + Math.sin(end) * radius} Z`, fill: color, stroke: "#e1bd6b", "stroke-width": ".65" }));
          const angle = (index * delta - 90) * Math.PI / 180, text = svgElement("text", { x: 160 + Math.cos(angle) * 115, y: 164 + Math.sin(angle) * 115, "text-anchor": "middle", fill: "#fff", "font-size": "9", "font-weight": "bold" }); text.textContent = String(number); rotor.append(text);
        }
        rotor.append(svgElement("circle", { cx: 160, cy: 160, r: 91, fill: "#795136", stroke: "#e1bd6b", "stroke-width": 4 }));
        rotor.append(svgElement("circle", { cx: 160, cy: 160, r: 53, fill: "#263a32", stroke: "#c49a4e", "stroke-width": 3 }));
        ball = svgElement("g", { class: "lr-wheel-ball" }); ball.append(svgElement("circle", { cx: 160, cy: 35, r: 5, fill: "white", stroke: "#ccdae7", "stroke-width": 1 }));
        wheel.replaceChildren(svgElement("circle", { cx: 160, cy: 160, r: 151, fill: "#402c22", stroke: "#b68a4d", "stroke-width": 5 }), rotor, ball);
      }
      /** Animates only presentation: the server reveals the private outcome for the final landing segment. */
      function updateWheel() {
        if (!rotor || !state) return;
        const key = `${state.phaseId}:${state.phase}:${state.isPaused}:${state.winningNumber}`;
        if (wheelKey === key) return; wheelKey = key;
        for (const animation of wheelAnimations) animation.cancel(); wheelAnimations = [];
        const index = state.winningNumber === null ? 0 : state.wheelPockets.indexOf(state.winningNumber), angle = Math.max(0, index) * 360 / state.wheelPockets.length;
        if (state.phase !== "rolling") { rotor.style.transform = "rotate(0deg)"; ball.style.transform = `rotate(${angle}deg)`; return; }
        const duration = state.phaseDurationMs, remaining = state.remainingMs, elapsed = Math.max(0, duration - remaining), landing = state.landingDurationMs, revealAt = duration - landing;
        const wheelStart = elapsed / duration * 1080;
        const endBall = -2160 + angle;
        const ballStart = state.winningNumber !== null && elapsed >= revealAt
          ? -2160 * revealAt / duration + (endBall + 2160 * revealAt / duration) * Math.min(1, (elapsed - revealAt) / landing)
          : -2160 * elapsed / duration;
        rotor.style.transform = `rotate(${wheelStart}deg)`; ball.style.transform = `rotate(${ballStart}deg)`;
        if (state.isPaused || remaining <= 0 || reducedMotion.matches) { if (state.winningNumber !== null && reducedMotion.matches) ball.style.transform = `rotate(${angle}deg)`; return; }
        if (rotor.animate && ball.animate) {
          wheelAnimations.push(rotor.animate([{ transform: `rotate(${wheelStart}deg)` }, { transform: "rotate(1080deg)" }], { duration: remaining, easing: "linear", fill: "forwards" }));
          wheelAnimations.push(ball.animate([{ transform: `rotate(${ballStart}deg)` }, { transform: `rotate(${state.winningNumber === null ? -2160 : endBall}deg)` }], { duration: remaining, easing: "linear", fill: "forwards" }));
        }
      }
      /** Reconciles one authoritative snapshot while keeping form nodes, board targets, and input focus stable. */
      function receiveState(next) {
        if (destroyed) return;
        state = next; localDeadline = state.isPaused ? null : performance.now() + state.remainingMs;
        recoveryDeadline = state.recoveryRemainingMs === null ? null : performance.now() + state.recoveryRemainingMs;
        if (!catalog.size) { catalog = new Map(state.betSpaces.map(space => [space.id, space])); buildBoard(); buildWheel(state.wheelPockets); }
        timerAnimation?.cancel(); timerAnimation = null;
        const fraction = Math.max(0, Math.min(1, state.remainingMs / Math.max(1, state.phaseDurationMs))); timerFill.style.transform = `scaleX(${fraction})`;
        if (!state.isPaused && state.remainingMs > 0 && timerFill.animate) timerAnimation = timerFill.animate([{ transform: `scaleX(${fraction})` }, { transform: "scaleX(0)" }], { duration: state.remainingMs, easing: "linear", fill: "forwards" });
        const text = state.phase === "finished" ? "Game finished" : `Round ${state.round}${state.isTiebreaker ? " \u00b7 tiebreaker" : ""} \u00b7 ${state.phase === "betting" ? "Place your bets" : state.phase === "rolling" ? "Wheel spinning" : "Round results"}`;
        const announcement = state.isPaused ? state.pauseMessage ?? "Game paused" : text;
        if (status.textContent !== announcement) status.textContent = announcement;
        find("[data-lr-recovery]").textContent = state.recoveryRemainingMs === null ? "" : `Disconnect pause: ${Math.ceil(state.recoveryRemainingMs / 1000)} seconds remaining. The host may resume now.`;
        find("[data-lr-betting]").hidden = state.phase !== "betting";
        find("[data-lr-chip-dock]").hidden = state.phase !== "betting";
        find("[data-lr-wheel-view]").hidden = state.phase === "betting";
        const resultText = state.winningNumber === null ? "Waiting for the ball to land..." : `Winning pocket: ${state.winningNumber}`;
        const result = find("[data-lr-result-number]"); if (result.textContent !== resultText) result.textContent = resultText;
        const results = find("[data-lr-results]"); results.replaceChildren();
        if (state.phase === "results") {
          if (state.winnerId) results.append(element("strong", "", `${state.balances.find(player => player.id === state.winnerId)?.name ?? "Player"} wins the match!`));
          for (const player of state.balances) { const receipts = state.receipts.filter(receipt => receipt.ownerId === player.participantId), staked = receipts.reduce((sum, receipt) => sum + receipt.amount, 0), returned = receipts.reduce((sum, receipt) => sum + receipt.returned, 0); results.append(element("p", "", `${player.name}: staked ${money(staked)} \u00b7 returned ${money(returned)} \u00b7 net ${money(returned - staked)}`)); }
          if (!state.winnerId && state.isTiebreaker) results.append(element("p", "", "Tied leaders continue in the next round."));
        }
        renderPlayers(); renderTableChips(); renderControls(); renderClock(); updateWheel(); highlight(selectedSpace);
      }
      /** Toggles readiness; the server decides whether this was the final lock and advances the phase. */
      function toggleLock() { if (state?.canLock && !pending) void submit("set-lock", { locked: !state.isLocked }); }
      /** Submits the accessible target selector's bet without requiring a drag gesture. */
      function submitForm(event) { event.preventDefault(); place(spaceSelect.value); }
      /** Keeps a typed custom value separate from the player's authoritative ledger. */
      function amountChanged() { selectedChip = Number(amountInput.value); renderControls(); }
      /** Selects the participant's current available cash as a single chip value. */
      function selectMax() { selectChip(localPlayer()?.available ?? 0); }
      /** Highlights the accessible target selector without spending until its Place button is used. */
      function selectionChanged() { selectedSpace = spaceSelect.value; highlight(selectedSpace); }
      /** Delegates pause authority to GameHub rather than deciding host ownership inside the plugin. */
      async function togglePause() { if (!state || !context.isHost) return; const response = await context.requestPause(!state.isPaused); if (!destroyed && response && !response.success) context.notify(response.message ?? "Pause could not be changed."); }
      /** Uses GameHub's existing confirmation flow for leaving or ending the game. */
      function leave() { if (context.isHost) context.requestExit(); else context.requestLeave(); }
      /** Recomputes compact stack heights when the phone breakpoint changes. */
      function compactChanged() { if (state && !destroyed) renderTableChips(); }
      /** Rebuilds animation presentation when the operating-system motion preference changes. */
      function motionChanged() { wheelKey = ""; updateWheel(); }
      buildChips(); renderControls(); layoutBoard();
      root.addEventListener("click", rootClick); chips.addEventListener("pointerdown", pointerDown);
      window.addEventListener("pointermove", pointerMove, { passive: false }); window.addEventListener("pointerup", pointerUp); window.addEventListener("pointercancel", cancelDrag);
      form.addEventListener("submit", submitForm); amountInput.addEventListener("input", amountChanged); find("[data-lr-max]").addEventListener("click", selectMax);
      spaceSelect.addEventListener("change", selectionChanged); lockButton.addEventListener("click", toggleLock); pauseButton.addEventListener("click", togglePause); leaveButton.addEventListener("click", leave);
      compact.addEventListener?.("change", compactChanged); reducedMotion.addEventListener?.("change", motionChanged);
      const unsubscribe = context.input?.onAction("toggle-lock", toggleLock) ?? (() => {});
      const observer = typeof ResizeObserver === "function" ? new ResizeObserver(positionTargets) : null; observer?.observe(table);
      window.addEventListener("resize", layoutBoard);
      window.visualViewport?.addEventListener("resize", layoutBoard);
      landscape.addEventListener?.("change", layoutBoard);
      const clockInterval = setInterval(renderClock, 200);
      return {
        receiveState,
        /** Displays public notices without exposing or deriving a hidden wheel result. */
        receiveEvent(event) { if (!destroyed && event.type === "notification" && typeof event.payload?.message === "string") context.notify(event.payload.message); },
        /** Refreshes host controls immediately after room ownership changes. */
        receivePlatformEvent(event) { if (!destroyed && event.type === "host-changed") renderControls(); },
        /** Freezes presentation promptly while the next authoritative pause snapshot is in flight. */
        setPaused(isPaused) { if (!state || destroyed || state.isPaused === isPaused) return; receiveState({ ...state, isPaused, remainingMs: localDeadline === null ? state.remainingMs : Math.max(0, localDeadline - performance.now()) }); },
        /** Removes every listener, timer, gesture, observer, and animation owned by this mount. */
        destroy() {
          destroyed = true; cancelDrag(); clearInterval(clockInterval); clearAnimations(); observer?.disconnect(); unsubscribe();
          root.removeEventListener("click", rootClick); chips.removeEventListener("pointerdown", pointerDown);
          window.removeEventListener("pointermove", pointerMove); window.removeEventListener("pointerup", pointerUp); window.removeEventListener("pointercancel", cancelDrag); window.removeEventListener("resize", layoutBoard);
          window.visualViewport?.removeEventListener("resize", layoutBoard);
          landscape.removeEventListener?.("change", layoutBoard);
          form.removeEventListener("submit", submitForm); amountInput.removeEventListener("input", amountChanged); find("[data-lr-max]").removeEventListener("click", selectMax);
          spaceSelect.removeEventListener("change", selectionChanged); lockButton.removeEventListener("click", toggleLock); pauseButton.removeEventListener("click", togglePause); leaveButton.removeEventListener("click", leave);
          compact.removeEventListener?.("change", compactChanged); reducedMotion.removeEventListener?.("change", motionChanged);
          chips.replaceChildren(); table.replaceChildren(); ownBets.replaceChildren(); allBets.replaceChildren(); players.replaceChildren(); wheel.replaceChildren(); spaceSelect.replaceChildren(); state = null;
        }
      };
    }
  });
})();
