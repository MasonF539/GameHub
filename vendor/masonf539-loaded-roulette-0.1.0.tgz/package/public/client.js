/** Registers the browser renderer; all money and roulette outcomes remain server-authoritative. */
(function registerLoadedRoulette() {
  window.GameHubRegisterGameClientModule("loaded-roulette", {
    /** Mounts the betting board, chip controls, wheel, and owned cleanup resources. */
    mount(context) {
      /** Game-scoped queries prevent one plugin from changing another game's controls. */
      const root = context.root;
      /** Returns a required element from this game's own markup. */
      const find = selector => { const element = root.querySelector(selector); if (!element) throw new Error(`Missing Loaded Roulette element: ${selector}`); return element; };
      /** Stable UI elements are retained so timer ticks never rebuild the board or form. */
      const table = find("[data-lr-table]"), players = find("[data-lr-players]"), topPlayers = find("[data-lr-players-top]");
      const amountInput = find("[data-lr-amount]"), chips = find("[data-lr-chips]");
      const lockButton = find("[data-lr-lock]"), pauseButton = find("[data-lr-pause]"), leaveButton = find("[data-lr-leave]");
      const timerLabel = find("[data-lr-timer]"), timerFill = find("[data-lr-timer-fill]"), status = find("[data-lr-status]");
      const wheel = find("[data-lr-wheel]"), ownBets = find("[data-lr-own-bets]"), allBets = find("[data-lr-all-bets]");
      /** One native dialog serves result receipts and direct editing of the viewer's own chips. */
      const dialog = find("[data-lr-dialog]"), resultList = find("[data-lr-results]"), editForm = find("[data-lr-edit-form]"), editAmount = find("[data-lr-edit-amount]");
      const preview = find("[data-lr-preview]"), resultsButton = find("[data-lr-show-results]");
      /** A bank panel owns its amount controls independently of its future decorative shell. */
      const bankDialog = find("[data-lr-bank-dialog]"), borrowForm = find("[data-lr-borrow-form]"), repayForm = find("[data-lr-repay-form]");
      let bankReturnFocus = null;
      /** The stage-owned shop remains beneath its optional bank or card-inspection dialogs. */
      const shopDialog = find("[data-lr-shop-dialog]"), shopBooth = find("[data-lr-shop-booth]"), shopScene = find("[data-lr-shop-scene]");
      const shopSignboard = find("[data-lr-shop-signboard-card]"), shopSignboardPrice = find("[data-lr-shop-signboard-price]");
      let shopKey = "", inspectedOfferId = null, shopInspectTimer = null;
      /** The private card hand has a separate dialog so inspecting it never mutates bets. */
      const cardHand = find("[data-lr-hand]"), cardDialog = find("[data-lr-card-dialog]"), cardList = find("[data-lr-card-list]");
      let cardKey = "", cardDialogMode = "hand", cardReturnFocus = null;
      /** A one-second inspection preview never opens the collection or changes a card. */
      let cardHoverTimer = null, cardHoverTarget = null, cardPopoverVisible = false;
      const cardHover = find("[data-lr-card-hover]");
      /** Presentation state is discarded on unmount; receipts never authorize a payout. */
      let lastResults = null, resultsKey = "", resultsTimer = null, editingBetId = null, editingPhase = null, returnFocus = null, hold = null, previewTarget = null;
      /** The last trusted snapshot and local presentation deadline; no client value grants money. */
      let state = null, localDeadline = null, recoveryDeadline = null, pending = false, destroyed = false, selectedSpace = "straight:0", sequence = 0;
      /** Board nodes and bet rows remain stable while other players submit actions. */
      const targets = new Map(), cells = new Map(), rows = new Map();
      /** Cached seam centers keep proximity checks free of per-pointer layout reads. */
      let markerPoints = [], markerBounds = { left: 0, top: 0 }, lastMarkerPointer = null;
      let catalog = new Map(), selectedChip = 100, hoverSpace = null, suppressClickUntil = 0;
      /** These handles are cancelled when a new phase arrives or the game is unmounted. */
      let timerAnimation = null, wheelAnimations = [], wheelKey = "", rotor = null, ball = null, flickHand = null, wheelScene = null, pocketHighlight = null;
      /** A pointer gesture works with mouse, pen, and touch instead of desktop-only HTML dragging. */
      let drag = null, ghost = null;
      /** SVG radii separate the outer orbit, inward-facing number boxes, and inner landing pockets. */
      const wheelGeometry = { orbit: 137, number: 110, divider: 100, pocket: 90 };
      const compact = window.matchMedia("(max-width: 575.98px)");
      const landscape = window.matchMedia("(orientation: landscape)");
      const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");

      /** Formats whole in-game money without hiding its exact value. */
      function money(value) { return Number(value).toLocaleString(); }
      /** Uses short chip labels while exact amounts remain in accessible labels and the bet list. */
      function shortMoney(value) { return value >= 1_000_000 ? `${Number((value / 1_000_000).toFixed(1))}m` : value >= 1_000 ? `${Number((value / 1_000).toFixed(1))}k` : String(value); }
      /** Finds the viewer's current participant record, including the stable chip-owner ID. */
      function localPlayer() { return state?.balances.find(player => player.id === context.memberId) ?? null; }
      /** Returns one to ten visual chips, or one to five on small screens; the first band starts at $1. */
      function stackHeight(stake, balance) { const maximum = compact.matches ? 5 : 10; return Math.max(1, Math.min(maximum, Math.ceil(stake / Math.max(1, balance) * maximum))); }
      /** Creates text-only elements so player names and messages cannot inject HTML. */
      function element(tag, className, text) { const node = document.createElement(tag); if (className) node.className = className; if (text !== undefined) node.textContent = text; return node; }
      /** Builds one safe text-only card: polarity left, name centered, duplicate count right, effect below. */
      function cardNode(definition, count, fan = false) {
        const node = element(fan ? "button" : "article", "lr-card"); if (fan) node.type = "button";
        node.dataset.cardId = definition.id; node.dataset.kind = definition.kind; node.dataset.polarity = definition.polarity;
        const header = element("header"), polarity = definition.polarity === "positive" ? "Positive" : definition.polarity === "negative" ? "Negative" : definition.polarity === "risky" ? "Risky" : "Neutral";
        const heading = element("div", "lr-card-heading");
        heading.append(element("strong", "lr-card-name", definition.name), element("span", "lr-card-type", `${definition.kind === "public" ? "Public temporary" : definition.kind === "permanent" ? "Permanent" : "Temporary"}${definition.rare ? " / Rare" : ""}`));
        header.append(element("span", "lr-card-polarity", polarity), heading, element("span", "lr-card-count", String(count)));
        const effect = element("p", "lr-card-effect"); effect.append(element("span", "lr-card-effect-copy", definition.description));
        node.append(header, effect);
        if (fan) node.setAttribute("aria-label", `${definition.name}, ${polarity}, ${count} owned. Hold focus to inspect this card.`);
        else node.tabIndex = 0;
        return node;
      }
      /** Shrinks only overflowing descriptions, preserving the centered breathing room and full effect text. */
      function fitCardEffects(container) {
        for (const effect of container.querySelectorAll(".lr-card-effect")) {
          if (!effect.clientHeight || !effect.clientWidth) continue;
          const copy = effect.firstElementChild; copy.style.removeProperty("font-size");
          const style = getComputedStyle(effect), availableHeight = effect.clientHeight - parseFloat(style.paddingTop) - parseFloat(style.paddingBottom);
          const availableWidth = effect.clientWidth - parseFloat(style.paddingLeft) - parseFloat(style.paddingRight);
          if (copy.scrollHeight <= availableHeight + 1 && copy.scrollWidth <= availableWidth + 1) continue;
          let upper = parseFloat(style.fontSize), lower = Math.min(upper, effect.closest(".lr-hand-fan") ? 2 : effect.closest(".lr-shop-dialog") ? 4 : 8);
          for (let step = 0; step < 7; step++) {
            const size = (lower + upper) / 2; copy.style.fontSize = `${size}px`;
            if (copy.scrollHeight > availableHeight + 1 || copy.scrollWidth > availableWidth + 1) upper = size; else lower = size;
          }
          copy.style.fontSize = `${lower}px`;
        }
      }
      /** Rechecks card descriptions when their fixed-ratio containers resize, without timer-driven layout work. */
      function fitVisibleCards() { if (!destroyed) { layoutCardFan(); fitCardEffects(cardHand); fitCardEffects(cardList); fitCardEffects(cardHover); fitCardEffects(shopBooth); } }
      /** Orders owned stacks by the server catalogue rather than acquisition order. */
      function ownedCards() {
        const counts = new Map((state?.hand ?? []).map(card => [card.cardId, card.count]));
        return (state?.cardCatalog ?? []).filter(card => counts.has(card.id)).map(card => ({ definition: card, count: counts.get(card.id) }));
      }
      /** Opens the full accessible hand or the current private reward draft. */
      function openCardDialog(mode = "hand") {
        hideCardHover(); const previousMode = cardDialogMode; cardDialogMode = mode; cardDialog.dataset.cardMode = mode;
        find("[data-lr-card-close]").hidden = mode === "rewards";
        find("[data-lr-card-close]").textContent = mode === "reward-hand" ? "Back to rewards" : "Close";
        find("[data-lr-reward-hand]").hidden = mode !== "rewards";
        cardDialog.setAttribute("closedby", mode === "rewards" ? "none" : "closerequest");
        find("[data-lr-card-title]").textContent = mode === "rewards" ? "Choose a reward" : mode === "shop" ? "Inspect shop card" : "Your cards";
        find("[data-lr-card-message]").textContent = mode === "rewards"
          ? "Choose one card. Connected players receive a random choice at timeout. Reward Reroll works before choosing a reward; Shop Reroll works during Shop; Profit up, More draws, and Double or nothing work during Final Preparations. Other effects are previews."
          : "Play Reward Reroll before choosing a reward, Shop Reroll during Shop, and other supported cards during Final Preparations. Other cards remain previews. Double or nothing is limited to once per round.";
        if (mode === "shop") { const offer = state?.shopOffers?.find(offer => offer.id === inspectedOfferId); find("[data-lr-card-message]").textContent = offer ? `Price: ${money(offer.price)}. ${offer.discountPercent ? offer.discountPercent + "% off. " : ""}Only supported effects are active; other cards remain previews.` : "This offer is no longer available."; }
        cardList.replaceChildren();
        const entries = mode === "rewards" ? (state?.cardCatalog ?? []).filter(card => (state.rewardOffers ?? []).includes(card.id)).map(definition => ({ definition, count: (state.hand ?? []).find(card => card.cardId === definition.id)?.count ?? 0 })) : mode === "shop" ? (state?.shopOffers ?? []).filter(offer => offer.id === inspectedOfferId).map(offer => ({ definition: state.cardCatalog.find(card => card.id === offer.cardId), count: state.hand.find(card => card.cardId === offer.cardId)?.count ?? 0 })) : ownedCards();
        for (const { definition, count } of entries) {
          const node = cardNode(definition, count, mode === "rewards");
          if (mode === "rewards") {
            const option = element("div", "lr-card-option"), choose = element("button", "lr-card-choose", "Choose card");
            node.dataset.rewardCard = definition.id; node.setAttribute("aria-label", `Choose ${definition.name}`); node.disabled = !state.canChooseReward || pending;
            choose.type = "button"; choose.dataset.chooseCard = definition.id; choose.disabled = node.disabled;
            option.append(node, choose); cardList.append(option);
          } else if (mode === "shop") {
            const offer = state.shopOffers.find(offer => offer.id === inspectedOfferId), option = element("div", "lr-card-option");
            prepareShopPurchase(node, offer);
            option.append(node, element("p", "lr-shop-price", shopPriceText(offer))); cardList.append(option);
          } else {
            const option = element("div", "lr-card-option"), play = element("button", "lr-card-choose", "Preview only");
            const supported = ["profit-up", "more-draws", "double-or-nothing", "shop-reroll", "reward-reroll"].includes(definition.id);
            play.type = "button"; play.dataset.playCard = definition.id;
            play.textContent = supported ? (state?.playableCardIds?.includes(definition.id) ? "Play card" : (definition.id === "shop-reroll" ? "Play during Shop" : definition.id === "reward-reroll" ? "Play during Rewards" : "Play in Final Preparations")) : "Preview only";
            play.disabled = pending || !state?.playableCardIds?.includes(definition.id);
            option.append(node, play); cardList.append(option);
          }
        }
        if (!entries.length) cardList.append(element("p", "", mode === "rewards" ? "No reward is pending." : mode === "shop" ? "This offer is no longer available." : state?.round >= 2 ? "Your hand is empty." : "No cards yet. Rewards begin in round 2."));
        if (!cardDialog.open) {
          hidePreview(); closeDialog(); cardReturnFocus = document.activeElement;
          if (cardDialog.showModal) cardDialog.showModal(); else cardDialog.setAttribute("open", "");
          // Start at the dialog heading so automatic focus does not highlight the first reward.
          find("[data-lr-card-title]").focus({ preventScroll: true });
        }
        if (cardDialog.open && previousMode !== mode) find("[data-lr-card-title]").focus({ preventScroll: true });
        fitCardEffects(cardList);
      }
      /** Only inspection can be dismissed; phase transitions and unmount may force reward cleanup. */
      function closeCardDialog(force = false) {
        if (force !== true && cardDialogMode === "reward-hand" && state?.phase === "rewards" && state.rewardOffers?.length > 0) { openCardDialog("rewards"); return; }
        if (force !== true && cardDialogMode === "rewards" && state?.phase === "rewards" && state.rewardOffers?.length > 0) return;
        hideCardHover();
        if (cardDialog.open) { if (cardDialog.close) cardDialog.close(); else cardDialog.removeAttribute("open"); }
        if (cardReturnFocus?.isConnected && !cardReturnFocus.disabled) cardReturnFocus.focus(); cardReturnFocus = null;
      }
      /** Keeps Escape from dismissing an unresolved reward choice. */
      function cancelCardDialog(event) { if (["rewards", "reward-hand"].includes(cardDialogMode) && state?.phase === "rewards" && state.rewardOffers?.length > 0) { event.preventDefault(); if (cardDialogMode === "reward-hand") openCardDialog("rewards"); } }
      /** Restores a required draft if a browser or external close request dismisses it. */
      function cardDialogClosed() { if (!cardDialog.open) hideCardHover(); if (!destroyed && !cardDialog.open && ["rewards", "reward-hand"].includes(cardDialogMode) && state?.phase === "rewards" && state.rewardOffers?.length > 0) openCardDialog("rewards"); }
      /** Removes an inspection preview and its pending timer without changing focus. */
      function hideCardHover() {
        clearTimeout(cardHoverTimer); cardHoverTimer = null;
        cardHoverTarget?.removeAttribute("aria-describedby"); cardHoverTarget = null;
        if (cardPopoverVisible) { cardHover.hidePopover(); cardPopoverVisible = false; }
        cardHover.hidden = true; cardHover.replaceChildren();
      }
      /** Enlarges a single card after a deliberate one-second hover or keyboard focus. */
      function cardHoverEntered(event) {
        if (state?.phase === "rewards") { hideCardHover(); return; }
        if (event.pointerType === "touch") return;
        const target = event.target.closest?.(".lr-card");
        if (!target || cardHover.contains(target) || target.contains(event.relatedTarget)) return;
        if (target.dataset.shopPurchase) {
          hideCardHover();
          return;
        }
        if (cardDialog.open && cardDialog.dataset.cardMode === "shop") return;
        hideCardHover(); cardHoverTarget = target;
        cardHoverTimer = setTimeout(() => {
          if (destroyed || !target.isConnected || cardHoverTarget !== target) return;
          const definition = state?.cardCatalog?.find(card => card.id === target.dataset.cardId); if (!definition) return;
          const count = Number(target.querySelector(".lr-card-count").textContent);
          const enlarged = cardNode(definition, count); enlarged.tabIndex = -1;
          cardHover.replaceChildren(enlarged); cardHover.hidden = false;
          // Popovers enter the top layer after the shop, escaping its scaling and clipping.
          const canPopover = typeof cardHover.showPopover === "function";
          const parent = canPopover ? root : cardDialog.open && cardDialog.contains(target) ? cardDialog : shopDialog.open && shopDialog.contains(target) ? shopDialog : root;
          parent.append(cardHover);
          if (canPopover) { cardHover.showPopover(); cardPopoverVisible = true; }
          fitCardEffects(cardHover);
          const box = target.getBoundingClientRect(), width = cardHover.offsetWidth, height = cardHover.offsetHeight;
          cardHover.style.left = `${Math.max(8, Math.min(innerWidth - width - 8, box.left + box.width / 2 - width / 2))}px`;
          cardHover.style.top = `${Math.max(8, Math.min(innerHeight - height - 8, box.top - height - 8))}px`;
          cardHover.id = "lr-card-hover"; target.setAttribute("aria-describedby", "lr-card-hover");
        }, 1000);
      }
      /** Moving away cancels both the glow inspection timer and its enlarged card. */
      function cardHoverLeft(event) {
        const target = event.target.closest?.(".lr-card"); if (target && !target.contains(event.relatedTarget)) hideCardHover();
      }
      /** Reconciles a stable sorted fan only when ownership or the reward phase changes. */
      function renderCards() {
        const key = JSON.stringify([state?.matchId, state?.hand, state?.rewardOffers, state?.phase, state?.canChooseReward, state?.playableCardIds, state?.playedCards]);
        if (key === cardKey) return; cardKey = key; hideCardHover();
        if (cardDialog.open && ["rewards", "reward-hand"].includes(cardDialogMode) && !state?.rewardOffers?.length) closeCardDialog(true);
        const owned = ownedCards(), total = owned.reduce((sum, card) => sum + card.count, 0);
        find("[data-lr-card-count]").textContent = `${total} card${total === 1 ? "" : "s"}`;
        find("[data-lr-hand-note]").hidden = owned.length > 0;
        find("[data-lr-view-hand]").textContent = state?.phase === "rewards" && state?.rewardOffers?.length ? "Choose reward" : "Check cards";
        cardHand.replaceChildren();
        const visible = owned;
        const offset = (index) => index - (visible.length - 1) / 2;
        const angleStep = Math.min(5, 18 / Math.max(1, visible.length - 1));
        visible.forEach(({ definition, count }, index) => {
          const node = cardNode(definition, count, true), cardOffset = offset(index);
          node.style.setProperty("--lr-card-position", String(cardOffset));
          node.style.setProperty("--lr-card-angle", `${cardOffset * angleStep}deg`);
          cardHand.append(node);
        });
        layoutCardFan();
        fitCardEffects(cardHand);
        if (state?.canChooseReward && !dialog.open) openCardDialog(cardDialog.open && cardDialogMode === "reward-hand" ? "reward-hand" : "rewards");
        else if (cardDialog.open) openCardDialog(state?.phase === "rewards" && ["rewards", "reward-hand"].includes(cardDialogMode) ? cardDialogMode : state?.phase === "shop" && cardDialogMode === "shop" ? "shop" : "hand");
      }
      /** Opens the requested private collection or submits one server-validated draft choice. */
      function cardClicked(event) {
        if (event.target.closest?.("[data-lr-shop-purchase]")) { purchaseShopCard(event); return; }
        const inspection = event.target.closest?.("[data-shop-inspect]");
        if (inspection) {
          clearTimeout(shopInspectTimer);
          if (shopScene.dataset.shopLayout === "compact") shopInspectTimer = setTimeout(() => inspectShopOffer(inspection.dataset.shopInspect), 300);
          else inspectShopOffer(inspection.dataset.shopInspect);
          return;
        }
        if (event.target.closest?.("[data-lr-reward-hand]") && state?.phase === "rewards" && state.rewardOffers?.length) { openCardDialog("reward-hand"); return; }
        const choice = event.target.closest?.("[data-choose-card],[data-reward-card]");
        if (choice && !pending && state?.canChooseReward) { choice.disabled = true; void submit("choose-reward", { cardId: choice.dataset.chooseCard ?? choice.dataset.rewardCard }); }
        else if (event.target.closest?.("[data-play-card]") && !pending) { const cardId = event.target.closest("[data-play-card]").dataset.playCard; if (state?.playableCardIds?.includes(cardId)) void submit("play-card", { cardId }); }
        else if (event.target.closest?.("[data-lr-view-hand]")) openCardDialog(state?.phase === "rewards" && state?.rewardOffers?.length ? "rewards" : "hand");
      }
      /** Submits one intent tied to the current match/phase and ignores replies after unmount. */
      async function submit(type, payload) {
        if (!state || pending || destroyed) return;
        pending = true; renderControls(); updateShopPurchaseCards(); if (cardDialog.open) openCardDialog(cardDialogMode);
        const requestId = window.crypto?.randomUUID?.() ?? `${Date.now()}_${++sequence}`;
        try {
          const response = await context.submitAction({ type, payload: { ...payload, matchId: state.matchId, phaseId: state.phaseId, requestId } });
          if (!destroyed && !response.success) context.notify(response.message ?? "The action was not accepted.");
          return response;
        } catch { if (!destroyed) context.notify("The action could not be sent. Check your connection."); }
        finally { if (!destroyed) { pending = false; renderControls(); updateShopPurchaseCards(); if (cardDialog.open) openCardDialog(cardDialogMode); } }
      }
      /** Updates purchase availability without adding a separate Buy control. */
      function updateShopPurchaseCards() {
        for (const card of root.querySelectorAll("[data-shop-purchase]")) {
          const offer = state?.shopOffers?.find(item => item.id === card.dataset.shopPurchase);
          card.setAttribute("aria-disabled", String(pending || !offer?.canBuy));
          if (card.tagName === "BUTTON") card.disabled = pending || !offer?.canBuy;
        }
      }
      /** Gives an offer card its purchase identity and keyboard alternative to double-clicking. */
      function prepareShopPurchase(card, offer) {
        card.dataset.shopPurchase = offer.id; card.tabIndex = 0; card.setAttribute("role", "button");
        card.setAttribute("aria-disabled", String(pending || !offer.canBuy));
        card.setAttribute("aria-keyshortcuts", "Shift+Enter");
        card.setAttribute("aria-label", `${state.cardCatalog.find(item => item.id === offer.cardId)?.name}. ${shopPriceText(offer)}. Double-click or press Shift+Enter to buy.`);
      }
      /** Keeps stock and affordability visible in the price line. */
      function shopPriceText(offer) {
        const status = { "sold-out": "Sold out", "already-maxed": "Already maxed", "unaffordable": "Not enough cash" }[offer.status];
        return `${money(offer.price)}${status ? ` / ${status}` : ""}`;
      }
      /** Buys only a still-available offer, cancelling the compact single-click inspection. */
      function purchaseShopCard(event) {
        const card = event.target.closest?.("[data-shop-purchase]");
        if (!card) return;
        clearTimeout(shopInspectTimer);
        const offer = state?.shopOffers?.find(item => item.id === card.dataset.shopPurchase);
        if (!pending && state?.phase === "shop" && offer?.canBuy) void submit("buy-card", { offerId: offer.id });
      }
      /** Creates a reusable card face, exact price, and one-purchase stock control. */
      function shopOfferNode(offer) {
        const definition = state.cardCatalog.find(card => card.id === offer.cardId);
        const node = element("div", `lr-shop-offer${offer.purchased ? " is-sold" : ""}`); node.dataset.shopKind = definition.kind;
        const card = cardNode(definition, state.hand.find(card => card.cardId === offer.cardId)?.count ?? 0);
        card.dataset.shopInspect = offer.id; card.tabIndex = 0; card.setAttribute("role", "button"); prepareShopPurchase(card, offer);
        const price = element("div", "lr-shop-price");
        if (offer.discountPercent) { price.append(element("del", "", money(offer.originalPrice)), element("strong", "", money(offer.price))); node.append(element("span", "lr-shop-discount", `${offer.discountPercent}% OFF`)); }
        else price.textContent = money(offer.price);
        if (offer.status !== "available") price.append(document.createTextNode(` / ${{ "sold-out": "Sold out", "already-maxed": "Already maxed", "unaffordable": "Not enough cash" }[offer.status]}`));
        const active = ["profit-up", "more-draws", "double-or-nothing", "shop-reroll", "reward-reroll"].includes(offer.cardId);
        if (active) card.querySelector(".lr-card-type").append(document.createTextNode(" / Playable"));
        node.classList.toggle("is-selected", offer.id === inspectedOfferId);
        node.append(card, price); return node;
      }
      /** Uses the side signboard on roomy screens and the full-card dialog on compact screens. */
      function inspectShopOffer(offerId) {
        if (state?.phase !== "shop" || !state.shopOffers?.some(offer => offer.id === offerId)) return;
        inspectedOfferId = offerId;
        if (shopScene.dataset.shopLayout === "compact") openCardDialog("shop");
        else selectShopOffer(offerId);
      }
      /** Keeps the signboard on the clicked offer until another offer is selected or stock changes. */
      function selectShopOffer(offerId) {
        const offer = state?.shopOffers?.find(item => item.id === offerId);
        const definition = state?.cardCatalog?.find(card => card.id === offer?.cardId);
        if (!offer || !definition) return;
        inspectedOfferId = offerId;
        const card = cardNode(definition, state.hand.find(item => item.cardId === offer.cardId)?.count ?? 0);
        card.classList.add("lr-shop-signboard-card");
        const active = ["profit-up", "more-draws", "double-or-nothing", "shop-reroll", "reward-reroll"].includes(offer.cardId);
        if (active) card.querySelector(".lr-card-type").append(document.createTextNode(" / Playable"));
        const discount = find("[data-lr-shop-signboard-discount]");
        shopSignboard.replaceChildren(card);
        shopSignboardPrice.replaceChildren();
        discount.hidden = !offer.discountPercent;
        discount.textContent = offer.discountPercent ? `${offer.discountPercent}% OFF` : "";
        if (offer.discountPercent) {
          shopSignboardPrice.append(element("del", "", money(offer.originalPrice)), document.createTextNode(" "), element("strong", "", money(offer.price)));
        } else shopSignboardPrice.textContent = money(offer.price);
        prepareShopPurchase(card, offer);
        const purchase = find("[data-lr-shop-purchase]");
        purchase.dataset.shopPurchase = offer.id; purchase.disabled = pending || !offer.canBuy;
        purchase.setAttribute("aria-disabled", String(purchase.disabled));
        purchase.textContent = offer.status === "sold-out" ? "Sold out" : offer.status === "already-maxed" ? "Already maxed" : offer.status === "unaffordable" ? "Not enough cash" : "Buy card";
        if (offer.status !== "available") shopSignboardPrice.textContent = shopPriceText(offer);
        for (const node of shopDialog.querySelectorAll(".lr-shop-offer")) node.classList.toggle("is-selected", node.querySelector("[data-shop-inspect]")?.dataset.shopInspect === offerId);
        fitCardEffects(shopSignboard);
      }
      /** Fits the complete booth into either viewport orientation, as before. */
      function fitShop() {
        if (!shopDialog.open || destroyed) return;
        const viewport = find(".lr-shop-viewport"), portrait = innerHeight > innerWidth;
        const viewportWidth = viewport.clientWidth || innerWidth, viewportHeight = viewport.clientHeight || innerHeight;
        shopScene.dataset.shopLayout = compact.matches || portrait || viewportWidth < 950 || viewportHeight <= 600 ? "compact" : "roomy";
        shopBooth.style.width = portrait ? "600px" : "960px";
        shopBooth.style.paddingLeft = portrait ? "50px" : "84px";
        shopBooth.style.paddingRight = portrait ? "50px" : "84px";
        shopBooth.dataset.orientation = portrait ? "portrait" : "landscape";
        shopScene.dataset.orientation = portrait ? "portrait" : "landscape";
        fitCardEffects(shopScene);
        const selected = state?.shopOffers?.find(offer => offer.id === inspectedOfferId) ?? state?.shopOffers?.[0];
        if (selected && shopScene.dataset.shopLayout === "roomy") selectShopOffer(selected.id);
        const scale = Math.min(1, viewportWidth / shopScene.offsetWidth, viewportHeight / shopScene.offsetHeight);
        shopScene.style.setProperty("--lr-shop-scale", String(Math.max(.01, scale)));
      }
      /** Keeps stage stock, cash, and readiness current without closing a bank opened above the shop. */
      function renderShop() {
        if (state?.phase !== "shop" || !localPlayer()?.isParticipating) { closeShop(); return; }
        const key = JSON.stringify([state.shopOffers, state.hand, pending]);
        if (key !== shopKey) {
          shopKey = key; hideCardHover();
          for (const group of ["deal", "personal", "shared"]) {
            const shelf = find(group === "deal" ? "[data-lr-shop-deals]" : `[data-lr-shop-${group}]`); shelf.replaceChildren();
            for (const offer of state.shopOffers ?? []) if (offer.group === group) shelf.append(shopOfferNode(offer));
          }
          if (!state.shopOffers?.length) find("[data-lr-shop-deals]").append(element("p", "lr-shop-deal-note", "Spectating this shop stage. Player shops are private."));
        }
        const local = localPlayer(), wallet = find("[data-lr-shop-money]"); wallet.replaceChildren();
        for (const [label, value] of [["Cash",local?.balance],["Debt",local?.debt],["Net",local?.netBalance]]) { const item = element("span", "", label); item.append(element("strong", "", value === undefined ? "-" : money(value))); wallet.append(item); }
        const shopPause = find("[data-lr-shop-pause]"); shopPause.hidden = !context.isHost; shopPause.textContent = state.isPaused ? "Resume" : "Pause"; shopPause.disabled = pending;
        const lock = find("[data-lr-shop-lock]"); lock.textContent = state.isLocked ? "Unlock" : "Lock in"; lock.disabled = pending || !state.canLock; lock.setAttribute("aria-pressed", String(state.isLocked));
        find("[data-lr-shop-bank]").disabled = !local || pending;
        const reroll = find("[data-lr-shop-reroll]"), count = state.hand.find(card => card.cardId === "shop-reroll")?.count ?? 0;
        reroll.hidden = count === 0; reroll.textContent = `Reroll (${count})`; reroll.disabled = pending || !state.playableCardIds?.includes("shop-reroll");
        if (!shopDialog.open) {
          closeDialog(); closeCardDialog(true);
          if (shopDialog.showModal) shopDialog.showModal(); else shopDialog.setAttribute("open", "");
          find("#lr-shop-title").focus({ preventScroll: true });
        }
        if (!state.shopOffers?.some(offer => offer.id === inspectedOfferId)) inspectedOfferId = null;
        fitShop();
        updateShopPurchaseCards();
      }
      /** Closes the stage's booth only when authoritative state advances or the game unmounts. */
      function closeShop() { clearTimeout(shopInspectTimer); if (shopDialog.open) { if (shopDialog.close) shopDialog.close(); else shopDialog.removeAttribute("open"); } shopKey = ""; }
      /** Escape cannot silently mark a player ready or remove the current Shop stage. */
      function cancelShop(event) { if (state?.phase === "shop") event.preventDefault(); }
      /** Opens the hand above the booth without dismissing or locking the Shop stage. */
      function checkShopCards() { if (state?.phase === "shop") openCardDialog("hand"); }
      /** Applies one owned Shop Reroll through the same retry-safe card action route. */
      function rerollShop() { if (!pending && state?.playableCardIds?.includes("shop-reroll")) void submit("play-card", { cardId: "shop-reroll" }); }
      /** Keyboard activation inspects a shelf card without accidentally purchasing it. */
      function inspectShopKey(event) { if (event.key === "Enter" && event.shiftKey && event.target.closest?.("[data-shop-purchase]")) { event.preventDefault(); purchaseShopCard(event); return; } if ((event.key === "Enter" || event.key === " ") && event.target.matches?.("[data-shop-inspect]")) { event.preventDefault(); inspectShopOffer(event.target.dataset.shopInspect); } }
      /** Reads the server-approved maximum for either bank form. */
      function bankMaximum(form) {
        return form === borrowForm ? state?.bank?.loanLimit ?? 0 : Math.max(0, Math.min(localPlayer()?.available ?? 0, localPlayer()?.debt ?? 0));
      }
      /** Synchronizes the slider and exact input for a chosen whole amount. */
      function setBankAmount(form, amount) {
        const value = Math.max(1, Math.min(bankMaximum(form) || 1, Math.floor(amount)));
        form.querySelector("[data-bank-amount]").value = String(value);
        form.querySelector("[data-bank-range]").value = String(value);
      }
      /** Updates live loan terms and permissions without replacing the amount being typed. */
      function renderBank() {
        const local = localPlayer(), bank = state?.bank;
        if (!bankDialog.open || !local || !bank) return;
        find("[data-lr-bank-summary]").textContent = `Cash ${money(local.balance)} | Available ${money(local.available)} | Debt ${money(local.debt)} | Net ${money(local.netBalance)} | Goal ${money(state.targetGoal)}`;
        for (const form of [borrowForm, repayForm]) {
          const maximum = bankMaximum(form), allowed = !pending && (form === borrowForm ? bank.canBorrow : bank.canRepay);
          const input = form.querySelector("[data-bank-amount]"), slider = form.querySelector("[data-bank-range]");
          input.max = slider.max = String(Math.max(1, maximum));
          const amount = Number(input.value), valid = Number.isSafeInteger(amount) && amount > 0 && amount <= maximum;
          input.disabled = slider.disabled = !allowed; slider.value = String(valid ? amount : Math.max(1, Math.min(maximum || 1, amount || 1)));
          for (const preset of form.querySelectorAll("[data-bank-fraction]")) {
            const value = Math.max(1, Math.floor(maximum * Number(preset.dataset.bankFraction)));
            preset.textContent = `${Number(preset.dataset.bankFraction) * 100}%`; preset.disabled = !allowed || maximum < 1;
            preset.setAttribute("aria-label", `${preset.textContent} of ${form === borrowForm ? "maximum loan" : "repayable amount"}: ${money(maximum > 0 ? value : 0)}`);
          }
          form.querySelector("[data-bank-submit]").disabled = !allowed || !valid;
        }
        const amount = Number(borrowForm.querySelector("[data-bank-amount]").value);
        const valid = Number.isSafeInteger(amount) && amount > 0 && amount <= bank.loanLimit;
        find("[data-lr-loan-terms]").textContent = valid ? `Receive ${money(amount)} cash. Fee ${money(Math.floor(amount / 4))}. Total debt added: ${money(amount + Math.floor(amount / 4))}.` : `Choose a whole loan amount from 1 to ${money(bank.loanLimit)}.`;
        find("[data-lr-borrow-status]").textContent = state.isPaused ? "The game is paused." : state.isLocked ? "Unlock before using the bank." : !["shop", "betting"].includes(state.phase) ? "New loans are available during Shop or Betting." : bank.borrowedThisRound ? "You have already borrowed this round. Loans reopen next round." : `Maximum loan: ${money(bank.loanLimit)}.`;
        const repayment = Number(repayForm.querySelector("[data-bank-amount]").value), repayLimit = bankMaximum(repayForm);
        find("[data-lr-repay-terms]").textContent = local.debt === 0 ? "You have no outstanding debt." : repayLimit === 0 ? "You have no unreserved cash to repay debt." : Number.isSafeInteger(repayment) && repayment > 0 && repayment <= repayLimit ? `Repay ${money(repayment)}. Debt remaining: ${money(local.debt - repayment)}. Available cash afterwards: ${money(local.available - repayment)}.` : `Choose a whole repayment from 1 to ${money(repayLimit)}.`;
        const history = find("[data-lr-loan-history]"); history.replaceChildren();
        for (const loan of bank.loans) history.append(element("li", "", `Round ${loan.round}: borrowed ${money(loan.principal)}; original debt ${money(loan.originalDebt)}; remaining ${money(loan.remainingDebt)}.`));
        if (!bank.loans.length) history.append(element("li", "", "No loans taken this match."));
      }
      /** Opens the bank with current terms and native focus trapping, without stopping the game clock. */
      function openBank() {
        if (!state || !localPlayer() || state.phase === "finished" || (state.phase === "rewards" && state.rewardOffers?.length)) return;
        hidePreview(); hideCardHover(); closeDialog(); closeCardDialog(true);
        bankReturnFocus = document.activeElement;
        setBankAmount(borrowForm, Math.floor((state.bank?.loanLimit ?? 1) / 4));
        setBankAmount(repayForm, bankMaximum(repayForm));
        if (!bankDialog.open) { if (bankDialog.showModal) bankDialog.showModal(); else bankDialog.setAttribute("open", ""); }
        renderBank(); find("#lr-bank-title").focus({ preventScroll: true });
      }
      /** Dismisses the optional bank panel and returns focus to its opening control. */
      function closeBank() {
        if (bankDialog.open) { if (bankDialog.close) bankDialog.close(); else bankDialog.removeAttribute("open"); }
        if (bankReturnFocus?.isConnected && !bankReturnFocus.disabled) bankReturnFocus.focus(); bankReturnFocus = null;
      }
      /** Preset buttons select a fraction of the current loan or repayment limit. */
      function bankPresetClicked(event) {
        const preset = event.target.closest?.("[data-bank-fraction]"); if (!preset || preset.disabled) return;
        const form = preset.closest("form"); setBankAmount(form, bankMaximum(form) * Number(preset.dataset.bankFraction)); renderBank();
      }
      /** Keeps a dragged bar and typed input synchronized while allowing incomplete input to be corrected. */
      function bankAmountChanged(event) {
        const form = event.target.closest("form"); if (!form) return;
        if (event.target.matches("[data-bank-range]")) setBankAmount(form, Number(event.target.value));
        renderBank();
      }
      /** Sends a loan or repayment intent; the server rechecks the stage, limit, debt, and available cash. */
      async function submitBank(event) {
        event.preventDefault();
        const form = event.currentTarget, amount = Number(form.querySelector("[data-bank-amount]").value);
        if (pending || !Number.isSafeInteger(amount) || amount < 1 || amount > bankMaximum(form) || !(form === borrowForm ? state?.bank?.canBorrow : state?.bank?.canRepay)) return;
        await submit(form === borrowForm ? "take-loan" : "repay-debt", { amount });
        if (!destroyed && bankDialog.open) renderBank();
      }
      /** Places the chosen chip amount; the server checks cash, lock state, and the legal target again. */
      function place(spaceId, chipAmount = Number(amountInput.value)) {
        if (!state?.canBet || pending || destroyed) return;
        const amount = chipAmount;
        if (!Number.isSafeInteger(amount) || amount <= 0) { context.notify("Choose a positive whole chip value."); return; }
        if (amount > (localPlayer()?.available ?? 0)) { context.notify("That chip is larger than your available money."); return; }
        selectedSpace = spaceId; highlight(spaceId);
        void submit("place-bet", { spaceId, amount });
      }
      /** Selects a denomination or custom value without spending it. */
      function selectChip(value) { selectedChip = value; amountInput.value = String(value); renderControls(); }
      /** Highlights the complete covered-number set before or during a drop. */
      function highlight(spaceId) {
        const space = catalog.get(spaceId); hoverSpace = spaceId;
        for (const [id, target] of targets) target.classList.toggle("is-targeted", id === spaceId);
        for (const [number, cell] of cells) cell.classList.toggle("is-covered", space?.numbers.includes(number) === true);
        find("[data-lr-selection]").textContent = space ? `${space.label} \u00b7 ${space.profitMultiplier}:1 profit \u00b7 covers ${space.numbers.join(", ")}` : "Choose a betting target.";
      }
      /** Shows covered numbers and selected stake/profit/return before a wager is submitted. */
      function showPreview(target) {
        const space = catalog.get(target.dataset.betSpace); if (!space || destroyed || dialog.open || state?.phase !== "betting") return;
        previewTarget?.removeAttribute("aria-describedby"); previewTarget = target; target.setAttribute("aria-describedby", "lr-bet-preview");
        highlight(space.id); preview.replaceChildren(element("strong", "", space.label));
        const stake = Number(amountInput.value), returned = stake * (space.profitMultiplier + 1);
        preview.append(element("p", "", `Covers ${space.numbers.join(", ")}`));
        preview.append(element("p", "", Number.isSafeInteger(stake) && stake > 0 && Number.isSafeInteger(returned)
          ? `Stake ${money(stake)} | If won: profit ${money(returned - stake)}, return ${money(returned)}` : `${space.profitMultiplier}:1 profit; choose a whole chip amount.`));
        preview.hidden = false; const rect = target.getBoundingClientRect();
        preview.style.left = `${Math.max(8, Math.min(window.innerWidth - preview.offsetWidth - 8, rect.left + rect.width / 2 - preview.offsetWidth / 2))}px`;
        preview.style.top = `${Math.max(8, rect.top - preview.offsetHeight - 8)}px`;
      }
      /** Dismisses a transient preview and restores the selected betting coverage. */
      function hidePreview() { preview.hidden = true; previewTarget?.removeAttribute("aria-describedby"); previewTarget = null; if (catalog.size && !destroyed) highlight(selectedSpace); }
      /** Previews pointer hover or keyboard focus without placing a wager. */
      function previewEntered(event) {
        if (event.pointerType === "touch") return;
        const target = event.target.closest?.("[data-bet-space]");
        if (target && !target.contains(event.relatedTarget)) showPreview(target);
      }
      /** Clears a preview after leaving its complete betting target. */
      function previewLeft(event) {
        const target = event.target.closest?.("[data-bet-space]");
        if (target && !target.contains(event.relatedTarget)) hidePreview();
      }
      /** Replaces a betting target's native long-press menu with its safe preview. */
      function previewContext(event) {
        const target = event.target.closest?.("[data-bet-space]"); if (!target) return;
        event.preventDefault(); showPreview(target); suppressClickUntil = performance.now() + 350;
      }
      /** Starts a touch hold; a normal tap still places the selected chip. */
      function previewHoldStart(event) {
        if (event.pointerType !== "touch") return;
        finishPreviewHold(); hidePreview();
        const target = event.target.closest?.("[data-bet-space]"); if (!target) return;
        hold = { pointerId: event.pointerId, x: event.clientX, y: event.clientY, shown: false, cancelled: false, timer: null };
        hold.timer = setTimeout(() => { if (hold && !destroyed) { hold.shown = true; showPreview(target); } }, 450);
      }
      /** Cancels a pending hold on movement; finishing a displayed hold suppresses its synthetic click. */
      function finishPreviewHold(event) {
        if (!hold || (event && event.pointerId !== hold.pointerId)) return;
        clearTimeout(hold.timer); if (hold.shown || hold.cancelled) suppressClickUntil = performance.now() + 350; hold = null;
      }
      /** Opens the shared dialog with native focus trapping and a DOM-test fallback. */
      function showDialog() {
        hidePreview();
        if (!dialog.open) { returnFocus = document.activeElement; if (typeof dialog.showModal === "function") dialog.showModal(); else dialog.setAttribute("open", ""); }
      }
      /** Closes a local dialog without mutating bets or dismissing a future round's results. */
      function closeDialog() {
        editingBetId = null; editingPhase = null;
        if (dialog.open) { if (typeof dialog.close === "function") dialog.close(); else dialog.removeAttribute("open"); }
        if (returnFocus?.isConnected && !returnFocus.disabled) returnFocus.focus(); returnFocus = null;
      }
      /** Clears editing state when Escape dismisses the native dialog. */
      function dialogClosed() { if (!dialog.open) { editingBetId = null; editingPhase = null; } }
      /** Opens a focused amount editor only for a live wager owned by the current viewer. */
      function openBetEditor(betId) {
        const bet = state?.bets.find(item => item.id === betId && item.ownerId === localPlayer()?.participantId);
        if (!bet || !state.canBet || pending) return;
        editingBetId = bet.id; editingPhase = `${state.matchId}:${state.phaseId}`;
        find("[data-lr-dialog-title]").textContent = `Edit ${catalog.get(bet.spaceId).label}`;
        find("[data-lr-dialog-summary]").textContent = `${money(bet.amount)} reserved | ${money(localPlayer().available + bet.amount)} available for this bet`;
        editForm.hidden = false; resultList.hidden = true; find("[data-lr-results-note]").hidden = true;
        editAmount.value = String(bet.amount); editAmount.max = String(localPlayer().available + bet.amount);
        showDialog(); editAmount.focus(); editAmount.select();
      }
      /** Updates the selected own bet using the same validated action as the side-panel editor. */
      async function saveEditedBet(event) {
        event.preventDefault(); const id = editingBetId, amount = Number(editAmount.value);
        if (!id || !Number.isSafeInteger(amount) || amount <= 0) return;
        const response = await submit("change-bet", { betId: id, amount });
        if (!destroyed && response?.success && editingBetId === id) closeDialog();
      }
      /** Removes an owned wager and releases its reservation only after server acknowledgement. */
      async function removeEditedBet() {
        const id = editingBetId; if (!id) return;
        const response = await submit("remove-bet", { betId: id });
        if (!destroyed && response?.success && editingBetId === id) closeDialog();
      }
      /** Shows the most recent settled receipts without reopening automatically after dismissal. */
      function openResults() {
        clearTimeout(resultsTimer); resultsTimer = null; if (!lastResults || destroyed) return;
        editingBetId = null; editingPhase = null;
        find("[data-lr-dialog-title]").textContent = `Round ${lastResults.round} | Winning pocket ${lastResults.winningNumber}`;
        const mine = lastResults.receipts.filter(bet => bet.ownerId === lastResults.viewer);
        const selected = lastResults.viewer ? mine : lastResults.receipts;
        const staked = selected.reduce((sum, bet) => sum + (bet.free ? 0 : bet.amount), 0), returned = selected.reduce((sum, bet) => sum + bet.returned, 0);
        const summaries = lastResults.settlements.filter(summary => !lastResults.viewer || summary.ownerId === lastResults.viewer);
        const gamble = summaries.reduce((sum, summary) => sum + summary.gambleAdjustment, 0), repaid = summaries.reduce((sum, summary) => sum + summary.debtRepaid, 0), net = returned - staked + gamble;
        find("[data-lr-dialog-summary]").textContent = `${lastResults.viewer ? "Your round" : "Table totals"}: Bet ${money(staked)} | Returned ${money(returned)} | Net ${net >= 0 ? "+" : ""}${money(net)}${summaries.some(summary => summary.gambleWon !== null) ? ` | Double or nothing ${gamble >= 0 ? "+" : ""}${money(gamble)}` : ""}${repaid > 0 ? ` | Debt repaid ${money(repaid)} | Cash change ${money(net - repaid)}` : ""}${lastResults.winner ? ` | ${lastResults.winner} wins the match!` : ""}`;
        editForm.hidden = true; resultList.hidden = false; find("[data-lr-results-note]").hidden = false;
        showDialog();
      }
      /** Caches one round of receipts and builds one scrollable result card for each settled bet. */
      function renderResults() {
        if (state.phase !== "results") { clearTimeout(resultsTimer); resultsTimer = null; return; }
        const key = `${state.matchId}:${state.phaseId}`;
        if (key === resultsKey) {
          const winner = state.balances.find(player => player.id === state.winnerId)?.name;
          if (lastResults.winner !== winner) { lastResults.winner = winner; if (dialog.open && !editingBetId) openResults(); }
          return;
        }
        resultsKey = key;
        lastResults = { round: state.round, winningNumber: state.winningNumber, viewer: localPlayer()?.participantId, receipts: state.receipts.map(bet => ({ ...bet })), settlements: (state.settlements ?? []).map(summary => ({ ...summary })), winner: state.balances.find(player => player.id === state.winnerId)?.name };
        const owners = new Map(state.balances.map(player => [player.participantId, player])); resultList.replaceChildren();
        for (const bet of lastResults.receipts) {
          const owner = owners.get(bet.ownerId), card = element("article", `lr-receipt ${bet.won ? "is-win" : "is-loss"}`), net = bet.returned - (bet.free ? 0 : bet.amount);
          card.style.setProperty("--player-color", owner?.color ?? "#aaa");
          card.append(element("strong", "", `${owner?.name ?? "Departed player"} | ${bet.won ? "WIN" : "LOSS"}`), element("h4", "", catalog.get(bet.spaceId)?.label ?? bet.spaceId), element("p", "", `${bet.free ? "Free bet" : "Bet"} ${money(bet.amount)} | Returned ${money(bet.returned)}`), element("p", "lr-receipt-net", `Net ${net >= 0 ? "+" : ""}${money(net)}`)); resultList.append(card);
        }
        if (!lastResults.receipts.length) resultList.append(element("p", "", "No bets were placed this round."));
        for (const summary of lastResults.settlements.filter(summary => summary.gambleWon !== null)) {
          const owner = owners.get(summary.ownerId), receipt = element("article", `lr-receipt ${summary.gambleWon ? "is-win" : "is-loss"}`);
          receipt.append(element("strong", "", `${owner?.name ?? "Departed player"} | Double or nothing`), element("p", "", `${summary.gambleWon ? "Profit doubled" : "Profit removed"}: ${summary.gambleAdjustment >= 0 ? "+" : ""}${money(summary.gambleAdjustment)}`)); resultList.append(receipt);
        }
        resultList.scrollTop = 0; resultsButton.disabled = false;
        resultsTimer = setTimeout(() => { resultsTimer = null; if (!destroyed && state?.phase === "results" && !document.querySelector(".modal.show") && !cardDialog.open) openResults(); }, reducedMotion.matches ? 0 : 750);
      }
      /** Creates an accessible click/drop target; its stable ID is the only target sent to the server. */
      function makeTarget(space, className, text) {
        const target = element("button", className), label = element("span", "lr-target-label");
        if (["red", "black"].includes(space.id)) {
          const diamond = element("span", `lr-color-diamond lr-diamond-${space.id}`); diamond.setAttribute("aria-hidden", "true"); label.append(diamond);
        } else label.textContent = text;
        target.append(label); target.type = "button"; target.dataset.betSpace = space.id;
        target.title = `${space.category}: ${space.label} \u00b7 ${space.profitMultiplier}:1 profit`;
        target.setAttribute("aria-label", target.title); targets.set(space.id, target);
        const marker = element("span", "lr-space-chips"); marker.setAttribute("aria-hidden", "true"); target.append(marker);
        return target;
      }
      /** Builds number cells plus separate seam/intersection targets, never nesting one button inside another. */
      function buildBoard() {
        table.replaceChildren(); targets.clear(); cells.clear();
        for (let number = 0; number <= 36; number++) {
          const cell = element("div", `lr-number-cell${number === 0 ? " lr-zero-cell" : ""}`);
          const color = number === 0 ? "green" : catalog.get("red").numbers.includes(number) ? "red" : "black";
          const button = makeTarget(catalog.get(`straight:${number}`), `lr-number lr-${color}`, String(number)); cell.append(button); table.append(cell); cells.set(number, cell);
        }
        for (const space of catalog.values()) {
          if (space.category === "Straight up") continue;
          if (space.category === "Outside") table.append(makeTarget(space, `lr-outside-target${["red", "black"].includes(space.id) ? " lr-color-bet" : ""}`, space.id.startsWith("column:") ? "2 to 1" : space.id.startsWith("dozen:") ? ["1st 12", "2nd 12", "3rd 12"][Number(space.id.split(":")[1]) - 1] : space.label));
          else {
            const kind = space.id.startsWith("split:") ? "split" : (space.id.startsWith("corner:") || space.id.startsWith("trio:")) ? "corner" : space.id === "first-four" ? "first-four" : space.category.toLowerCase().replaceAll(" ", "-");
            const target = makeTarget(space, `lr-seam lr-seam-${kind}`, kind === "street" ? "3" : kind === "six-line" ? "6" : kind === "first-four" ? "4" : "");
            if (["split", "corner"].includes(kind)) target.dataset.insideMarker = "true";
            table.append(target);
          }
        }
        layoutBoard();
      }
      /** Maps the conventional portrait table into landscape without rotating any text. */
      function placeCell(node, column, row, width = 1, height = 1) {
        if (landscape.matches) [column, row, width, height] = [row, 8 - column - width, height, width];
        node.style.gridColumn = `${column} / span ${width}`;
        node.style.gridRow = `${row} / span ${height}`;
      }
      /** Lays out betting cells within the fluid game frame; CSS owns available width and height. */
      function layoutBoard() {
        if (destroyed) return;
        for (const [number, cell] of cells) {
          if (number === 0) placeCell(cell, 3, 1, 3);
          else placeCell(cell, (number - 1) % 3 + 3, Math.floor((number - 1) / 3) + 2);
        }
        for (let group = 1; group <= 3; group++) {
          const dozen = targets.get(`dozen:${group}`), column = targets.get(`column:${group}`);
          if (dozen) placeCell(dozen, 2, 2 + (group - 1) * 4, 1, 4);
          if (column) placeCell(column, group + 2, 14);
        }
        for (const [index, id] of ["low", "even", "red", "black", "odd", "high"].entries()) {
          const target = targets.get(id); if (target) placeCell(target, 1, 2 + index * 2, 1, 2);
        }
        positionTargets();
        layoutCardFan();
      }
      /** Distributes every owned card across the hand panel without clipping the fan at seven. */
      function layoutCardFan() {
        const cards = cardHand.querySelectorAll(".lr-card");
        if (!cards.length) return;
        const width = cardHand.clientWidth, height = cardHand.clientHeight;
        if (!width || !height) return;
        const angleStep = Math.min(5, 18 / Math.max(1, cards.length - 1));
        const maxAngle = angleStep * (cards.length - 1) / 2 * Math.PI / 180;
        const rotatedWidthFactor = 5 / 7 * Math.cos(maxAngle) + Math.sin(maxAngle);
        const rotatedHeightFactor = 5 / 7 * Math.sin(maxAngle) + Math.cos(maxAngle);
        const cardHeight = Math.min((height - 4) / rotatedHeightFactor, width / rotatedWidthFactor);
        const cardWidth = cardHeight * 5 / 7;
        const rotatedWidth = cardWidth * Math.cos(maxAngle) + cardHeight * Math.sin(maxAngle);
        const rotatedHeight = cardWidth * Math.sin(maxAngle) + cardHeight * Math.cos(maxAngle);
        const bottomInset = Math.max(0, (rotatedHeight - cardHeight) / 2) + 2;
        const step = cards.length > 1 ? Math.max(0, Math.min(26, (width - rotatedWidth) / (cards.length - 1))) : 0;
        cardHand.style.setProperty("--lr-card-step", `${step}px`);
        cards.forEach(card => { card.style.height = `${cardHeight}px`; card.style.bottom = `${bottomInset}px`; });
      }
      /** Places seams at shared cell edges in either orientation; streets use the outer number edge. */
      function positionTargets() {
        if (!catalog.size || destroyed) return;
        const bounds = table.getBoundingClientRect(); markerBounds = { left: bounds.left, top: bounds.top }; markerPoints = [];
        const boxes = new Map([...cells].map(([number, cell]) => { const rect = cell.getBoundingClientRect(); return [number, { left: rect.left - bounds.left, right: rect.right - bounds.left, top: rect.top - bounds.top, bottom: rect.bottom - bounds.top }]; }));
        for (const space of catalog.values()) {
          if (["Straight up", "Outside"].includes(space.category)) continue;
          const target = targets.get(space.id), covered = space.numbers.map(number => boxes.get(number));
          if (!target || covered.some(box => !box)) continue;
          let x = (Math.max(...covered.map(box => box.left)) + Math.min(...covered.map(box => box.right))) / 2;
          let y = (Math.max(...covered.map(box => box.top)) + Math.min(...covered.map(box => box.bottom))) / 2;
          if (["Street", "Six line"].includes(space.category) || space.id === "first-four") {
            if (landscape.matches) y = Math.min(...covered.map(box => box.top)) / 2;
            else x = (Math.max(...covered.map(box => box.right)) + bounds.width) / 2;
          }
          target.style.left = `${x}px`; target.style.top = `${y}px`;
          if (space.id.startsWith("split:")) {
            const overlap = Math.min(...covered.map(box => box.right)) - Math.max(...covered.map(box => box.left));
            target.classList.toggle("is-horizontal", overlap > 1);
          }
          if (target.dataset.insideMarker) {
            target.classList.remove("is-near"); markerPoints.push({ target, x, y, near: false });
          }
        }
        if (lastMarkerPointer) updateNearbyMarkers(lastMarkerPointer);
      }
      /** Reveals nearby seam decorations while leaving every hit area and placed chip intact. */
      function updateNearbyMarkers(event) {
        if (destroyed || event.pointerType === "touch") return;
        lastMarkerPointer = { clientX: event.clientX, clientY: event.clientY, pointerType: event.pointerType };
        const x = event.clientX - markerBounds.left, y = event.clientY - markerBounds.top;
        for (const point of markerPoints) {
          const near = Math.hypot(point.x - x, point.y - y) <= 28;
          if (near !== point.near) { point.near = near; point.target.classList.toggle("is-near", near); }
        }
      }
      /** Clears desktop proximity hints after the pointer leaves the betting board. */
      function clearNearbyMarkers() {
        lastMarkerPointer = null;
        for (const point of markerPoints) if (point.near) { point.near = false; point.target.classList.remove("is-near"); }
      }
      /** Builds the tray once; each chip is also a touch/mouse drag source. */
      function buildChips() {
        for (const value of [1, 10, 100, 1_000, 10_000, "custom"]) {
          const chip = element("button", "lr-chip", value === "custom" ? "Custom" : shortMoney(value)); chip.type = "button"; chip.dataset.chipValue = String(value); chips.append(chip);
        }
      }
      /** Cancels any active gesture without placing a wager. */
      function cancelDrag() { ghost?.remove(); ghost = null; drag = null; for (const target of targets.values()) target.classList.remove("is-drop-target"); }
      /** Begins a possible drag; a click still simply chooses the chip. */
      function pointerDown(event) {
        const chip = event.target.closest("[data-chip-value]"); if (!chip || chip.disabled || event.button !== 0 || !state?.canBet) return;
        const value = chip.dataset.chipValue === "custom" ? Number(amountInput.value) : Number(chip.dataset.chipValue);
        selectChip(value); drag = { pointerId: event.pointerId, x: event.clientX, y: event.clientY, value, moving: false, source: chip };
        chip.setPointerCapture?.(event.pointerId);
      }
      /** Moves a chip ghost and previews the legal target under the pointer, including narrow seams. */
      function pointerMove(event) {
        updateNearbyMarkers(event);
        if (hold && event.pointerId === hold.pointerId && !hold.cancelled && Math.hypot(event.clientX - hold.x, event.clientY - hold.y) > 8) { clearTimeout(hold.timer); hold.cancelled = true; hidePreview(); }
        if (!drag || event.pointerId !== drag.pointerId) return;
        if (!drag.moving && Math.hypot(event.clientX - drag.x, event.clientY - drag.y) < 6) return;
        drag.moving = true; event.preventDefault();
        if (!ghost) { ghost = element("span", "lr-chip lr-drag-ghost", shortMoney(drag.value)); ghost.setAttribute("aria-hidden", "true"); ghost.style.setProperty("--chip-color", localPlayer()?.color ?? "#ffe08a"); document.body.append(ghost); }
        ghost.style.left = `${event.clientX}px`; ghost.style.top = `${event.clientY}px`;
        const target = document.elementFromPoint(event.clientX, event.clientY)?.closest("[data-bet-space]");
        for (const button of targets.values()) button.classList.toggle("is-drop-target", button === target);
        if (target && root.contains(target) && hoverSpace !== target.dataset.betSpace) highlight(target.dataset.betSpace);

      }
      /** Drops a dragged chip once; ordinary target clicks are suppressed immediately after a drop. */
      function pointerUp(event) {
        finishPreviewHold(event);
        if (!drag || drag.pointerId !== event.pointerId) return;
        const moving = drag.moving, amount = drag.value, target = document.elementFromPoint(event.clientX, event.clientY)?.closest("[data-bet-space]");
        cancelDrag();
        if (moving) { suppressClickUntil = performance.now() + 350; if (target && root.contains(target)) place(target.dataset.betSpace, amount); }
      }
      /** Routes chip selection and table clicks without installing a listener on every betting space. */
      function rootClick(event) {
        const ownStack = event.target.closest("[data-edit-bet]");
        if (ownStack && performance.now() >= suppressClickUntil) { event.preventDefault(); openBetEditor(ownStack.dataset.editBet); return; }
        const chip = event.target.closest("[data-chip-value]");
        if (chip && !chip.disabled) { selectChip(chip.dataset.chipValue === "custom" ? Number(amountInput.value) : Number(chip.dataset.chipValue)); return; }
        const target = event.target.closest("[data-bet-space]");
        if (target && !target.disabled && performance.now() >= suppressClickUntil) place(target.dataset.betSpace);
      }

      /** Seats the first six participants below the board and any excess participants above it. */
      function renderPlayers() {
        players.replaceChildren(); topPlayers.replaceChildren();
        topPlayers.hidden = state.balances.length <= 6;
        for (const [index, player] of state.balances.entries()) {
          const card = element("div", `lr-player${player.id === context.memberId ? " is-local" : ""}`); card.style.setProperty("--player-color", player.color);
          card.classList.toggle("is-locked", player.locked);
          card.title = `${player.locked ? "Locked in | " : ""}${player.name}: ${money(player.balance)} cash, ${money(player.debt ?? 0)} debt, ${money(player.available)} available${player.isConnected ? "" : ", offline"}`;
          card.append(element("strong", "", `${player.avatar} ${player.name}${!player.isConnected ? " \u00b7 offline" : ""}`), element("span", "", `${money(player.netBalance ?? player.balance)} net`), element("small", "", `${money(player.available)} available \u00b7 ${money(player.reserved)} on table${player.locked ? " \u00b7 locked" : ""}${!player.isParticipating ? " \u00b7 watching tiebreaker" : ""}`));
          if (player.locked) { const stamp = element("span", "lr-ready-stamp", "LOCKED IN"); stamp.setAttribute("aria-hidden", "true"); card.append(stamp); }
          (index < 6 ? players : topPlayers).append(card);
        }
      }
      /** Draws owner-colored stacks; small wagers start at one chip and high wagers cap at ten or five. */
      function renderTableChips() {
        const owners = new Map(state.balances.map(player => [player.participantId, player]));
        const grouped = new Map();
        for (const bet of state.bets) { if (!grouped.has(bet.spaceId)) grouped.set(bet.spaceId, []); grouped.get(bet.spaceId).push(bet); }
        for (const [spaceId, target] of targets) {
          const marker = target.querySelector(".lr-space-chips"); marker.replaceChildren();
          const bets = grouped.get(spaceId) ?? []; target.classList.toggle("has-chips", bets.length > 0);
          // A crowded target shows up to three stacks; the exact full owner list remains in All table bets.
          const ordered = [...bets].sort((a, b) => Number(b.ownerId === localPlayer()?.participantId) - Number(a.ownerId === localPlayer()?.participantId));
          for (const bet of ordered.slice(0, 3)) {
            const owner = owners.get(bet.ownerId), height = stackHeight(bet.amount, owner?.balance ?? bet.amount);
            const stack = element("span", "lr-chip-stack"); stack.style.setProperty("--chip-color", owner?.color ?? "#aaa");
            stack.style.setProperty("--stack-height", String(height));
            if (!bet.free && bet.ownerId === localPlayer()?.participantId) { stack.dataset.editBet = bet.id; stack.classList.add("is-own"); }
            stack.title = `${owner?.name ?? "Departed player"}: ${bet.free ? "Free bet " : ""}${money(bet.amount)} (${height} visual chips)`;
            for (let index = 0; index < height; index++) { const disc = element("span", "lr-chip-disc"); disc.style.setProperty("--stack-index", String(index)); stack.append(disc); }
            stack.append(element("span", "lr-stack-amount", shortMoney(bet.amount))); marker.append(stack);
          }
          if (bets.length > 3) marker.append(element("span", "lr-extra-owners", `+${bets.length - 3}`));
          const description = catalog.get(spaceId);
          target.setAttribute("aria-label", `${description.category}: ${description.label}; ${description.profitMultiplier}:1 profit${bets.length ? "; " + bets.map(bet => `${owners.get(bet.ownerId)?.name ?? "Departed player"} ${money(bet.amount)}`).join(", ") : ""}`);
        }
      }
      /** Updates keyed own-bet rows without throwing away an amount field currently being edited. */
      function renderBets() {
        const local = localPlayer(), mine = state.bets.filter(bet => bet.ownerId === local?.participantId);
        const ids = new Set(mine.map(bet => bet.id));
        for (const [id, row] of rows) if (!ids.has(id)) { row.remove(); rows.delete(id); }
        ownBets.querySelector(".lr-empty")?.remove();
        for (const bet of mine) {
          let row = rows.get(bet.id);
          if (!row) {
            row = element("li", "lr-own-bet"); const label = element("span"), input = element("input"), update = element("button", "", "Update"), remove = element("button", "", "Remove");
            input.type = "number"; input.min = "1"; input.step = "1"; input.inputMode = "numeric"; input.setAttribute("aria-label", `Stake for ${catalog.get(bet.spaceId).label}`);
            update.type = remove.type = "button";
            update.addEventListener("click", () => void submit("change-bet", { betId: bet.id, amount: Number(input.value) }));
            remove.addEventListener("click", () => void submit("remove-bet", { betId: bet.id }));
            row.append(label, input, update, remove); rows.set(bet.id, row); ownBets.append(row);
          }
          row.firstElementChild.textContent = `${bet.free ? "Free bet: " : ""}${catalog.get(bet.spaceId).label}`;
          const input = row.querySelector("input"); if (document.activeElement !== input) input.value = String(bet.amount);
          input.max = String((local?.available ?? 0) + bet.amount);
          for (const control of row.querySelectorAll("button, input")) control.disabled = bet.free || !state.canBet || pending;
        }
        if (!mine.length) ownBets.append(element("li", "lr-empty", state.phase === "betting" ? "No bets placed. Abstaining is allowed." : "Betting is closed."));
        allBets.replaceChildren();
        for (const bet of state.bets) { const owner = state.balances.find(player => player.participantId === bet.ownerId); const item = element("li", "", `${owner?.name ?? "Departed player"} \u00b7 ${catalog.get(bet.spaceId)?.label ?? bet.spaceId} \u00b7 ${bet.free ? "Free " : ""}${money(bet.amount)}`); item.style.borderLeftColor = owner?.color ?? "#aaa"; allBets.append(item); }
      }
      /** Keeps affordability, readiness, and host permissions synchronized without overwriting the typed amount. */
      function renderControls() {
        const local = localPlayer(), available = local?.available ?? 0, canBet = state?.canBet === true && !pending;
        const cashLabel = find("[data-lr-cash-balance]"); cashLabel.textContent = local ? money(local.balance) : "\u2014";
        amountInput.disabled = !canBet; amountInput.max = String(available);
        find("[data-lr-max]").disabled = !canBet || available <= 0;
        const amount = Number(amountInput.value);
        for (const chip of chips.querySelectorAll("[data-chip-value]")) {
          const custom = chip.dataset.chipValue === "custom", value = custom ? amount : Number(chip.dataset.chipValue);
          chip.disabled = !canBet || !Number.isSafeInteger(value) || value <= 0 || value > available;
          chip.setAttribute("aria-pressed", String(custom ? ![1, 10, 100, 1_000, 10_000].includes(selectedChip) : value === selectedChip));
          chip.setAttribute("aria-label", `Select or drag ${money(value)} chip${custom ? " (custom value)" : ""}`);
          if (custom) chip.textContent = "Custom";
          chip.style.setProperty("--chip-color", local?.color ?? "#ffe08a");
        }
        for (const target of targets.values()) target.disabled = !canBet;
        lockButton.hidden = !state || !["betting", "preparations"].includes(state.phase);
        lockButton.disabled = !state?.canLock || pending; lockButton.textContent = state?.isLocked ? (state.phase === "preparations" ? "Unlock preparations" : "Unlock bets") : "Lock in"; lockButton.setAttribute("aria-pressed", String(state?.isLocked === true));
        pauseButton.hidden = !context.isHost; pauseButton.disabled = !state || state.phase === "finished"; pauseButton.textContent = state?.isPaused ? "Resume" : "Pause";
        leaveButton.textContent = context.isHost ? "End game" : "Leave game";
        find("[data-lr-wallet]").textContent = local ? `${money(available)} available / ${money(local.balance)} cash / ${money(local.debt ?? 0)} debt / ${money(local.netBalance ?? local.balance)} net \u00b7 goal ${money(state.targetGoal)}` : "Spectating \u00b7 bets are read-only.";
        const callBank = find("[data-lr-call-bank]"); callBank.hidden = !local; callBank.disabled = !state || !local || state.phase === "finished";
        if (bankDialog.open && (!local || state?.phase === "finished")) closeBank(); else renderBank();
        renderShop();
        if (state) {
          renderBets();
          const plays = find("[data-lr-played-cards]"); plays.replaceChildren();
          for (const play of state.playedCards ?? []) {
            const owner = state.balances.find(player => player.participantId === play.ownerId);
            const card = state.cardCatalog?.find(card => card.id === play.cardId);
            plays.append(element("li", "", `${owner?.name ?? "Departed player"} played ${card?.name ?? play.cardId}`));
          }
        }
        for (const control of editForm.querySelectorAll("button,input")) control.disabled = !canBet;
        if (editingBetId) {
          const bet = state?.bets.find(item => item.id === editingBetId && item.ownerId === local?.participantId);
          if (!bet || !state.canBet || editingPhase !== `${state.matchId}:${state.phaseId}`) closeDialog();
          else editAmount.max = String(available + bet.amount);
        }
        if (!canBet && drag) cancelDrag();
        if (state?.phase !== "betting") { finishPreviewHold(); hidePreview(); }
      }
      /** Cancels presentation animations without changing the server-owned clock or result. */
      function clearAnimations() { timerAnimation?.cancel(); timerAnimation = null; for (const animation of wheelAnimations) animation.cancel(); wheelAnimations = []; }
      /** Refreshes countdown text only when needed; the fill uses a compositor-friendly scale animation. */
      function renderClock() {
        if (!state || destroyed) return;
        const recoveryText = recoveryDeadline === null ? "" : `Disconnect pause: ${Math.max(0, Math.ceil((recoveryDeadline - performance.now()) / 1000))} seconds remaining. The host may resume now.`;
        const recovery = find("[data-lr-recovery]"); if (recovery.textContent !== recoveryText) recovery.textContent = recoveryText;
        const remaining = state.isPaused || localDeadline === null ? state.remainingMs : Math.max(0, localDeadline - performance.now());
        const text = `${state.isPaused ? "Paused \u00b7 " : ""}${Math.ceil(remaining / 1_000)}s`;
        if (timerLabel.textContent !== text) timerLabel.textContent = text;
        if (state.phase === "shop") { const shopTime = find("[data-lr-shop-time]"); if (shopTime.textContent !== text) shopTime.textContent = text; }
        const result = find("[data-lr-result-number]");
        const landed = state.winningNumber !== null && (state.phase !== "rolling" || remaining <= Math.min(1000, state.landingDurationMs / 2));
        const resultText = landed ? `Winning pocket: ${state.winningNumber}` : "Waiting for the ball to land...";
        if (result.textContent !== resultText) result.textContent = resultText;
        const percent = Math.max(0, Math.min(100, remaining / Math.max(1, state.phaseDurationMs) * 100));
        const value = String(Math.round(percent)); if (timerFill.parentElement.getAttribute("aria-valuenow") !== value) timerFill.parentElement.setAttribute("aria-valuenow", value);
        if (!timerAnimation) timerFill.style.transform = `scaleX(${percent / 100})`;
      }
      /** Creates a vector wheel from the server's pocket order; no image-generation asset is required. */
      function buildWheel(order) {
        const namespace = "http://www.w3.org/2000/svg";
        /** Creates an SVG element with fixed presentation attributes. */
        const svgElement = (name, attributes) => { const node = document.createElementNS(namespace, name); for (const [key, value] of Object.entries(attributes)) node.setAttribute(key, String(value)); return node; };
        /** Builds fixed, uneven arc patches that follow the wood's circular grain. */
        function grainRing(innerRadius, outerRadius) {
          const grain = svgElement("g", { class: "lr-wheel-wood-grain", "aria-hidden": "true", fill: "none", "stroke-linecap": "round" });
          for (let patch = 0; patch < 8; patch++) {
            for (let line = 0; line < 3; line++) {
              const radius = innerRadius + (outerRadius - innerRadius) * (line + 1) / 4 + Math.sin(patch * 2 + line) * 1.4;
              const angle = patch * 45 + (patch % 3 - 1) * 7, span = 12 + (patch * 13 + line * 7) % 19;
              const start = (angle - span / 2) * Math.PI / 180, end = (angle + span / 2) * Math.PI / 180;
              grain.append(svgElement("path", { d: `M${160 + Math.cos(start) * radius} ${160 + Math.sin(start) * radius} A${radius} ${radius} 0 0 1 ${160 + Math.cos(end) * radius} ${160 + Math.sin(end) * radius}`, stroke: line === 1 ? "#24150e" : "#c58b55", "stroke-width": line === 1 ? 1.1 : .65, opacity: line === 1 ? .22 : .28 }));
            }
          }
          return grain;
        }
        rotor = svgElement("g", { class: "lr-wheel-rotor" }); const radius = 118, delta = 360 / order.length;
        for (let index = 0; index < order.length; index++) {
          const number = order[index], start = (index * delta - delta / 2 - 90) * Math.PI / 180, end = (index * delta + delta / 2 - 90) * Math.PI / 180;
          const color = number === 0 ? "#15804c" : catalog.get("red").numbers.includes(number) ? "#bc3441" : "#17212d";
          rotor.append(svgElement("path", { d: `M160 160 L${160 + Math.cos(start) * radius} ${160 + Math.sin(start) * radius} A${radius} ${radius} 0 0 1 ${160 + Math.cos(end) * radius} ${160 + Math.sin(end) * radius} Z`, fill: color, stroke: "#e1bd6b", "stroke-width": ".65" }));
          const inner = wheelGeometry.divider;
          rotor.append(svgElement("path", {
            class: "lr-wheel-number-box",
            d: `M${160 + Math.cos(start) * radius} ${160 + Math.sin(start) * radius} A${radius} ${radius} 0 0 1 ${160 + Math.cos(end) * radius} ${160 + Math.sin(end) * radius} L${160 + Math.cos(end) * inner} ${160 + Math.sin(end) * inner} A${inner} ${inner} 0 0 0 ${160 + Math.cos(start) * inner} ${160 + Math.sin(start) * inner} Z`,
            fill: color, stroke: "#e1bd6b", "stroke-width": 1.8, "stroke-linejoin": "round"
          }));
          const angle = (index * delta - 90) * Math.PI / 180;
          const x = 160 + Math.cos(angle) * wheelGeometry.number, y = 160 + Math.sin(angle) * wheelGeometry.number;
          const text = svgElement("text", { x, y, transform: `rotate(${index * delta} ${x} ${y})`, "text-anchor": "middle", "dominant-baseline": "central", fill: "#fff", "font-size": "9", "font-weight": "bold" });
          text.textContent = String(number); rotor.append(text);
        }
        rotor.append(svgElement("circle", { class: "lr-number-ring-divider", cx: 160, cy: 160, r: wheelGeometry.divider, fill: "none", stroke: "#e1bd6b", "stroke-width": 1.5 }));
        rotor.append(svgElement("circle", { cx: 160, cy: 160, r: 80, fill: "#795136", stroke: "#e1bd6b", "stroke-width": 4 }));
        rotor.append(svgElement("circle", { cx: 160, cy: 160, r: 53, fill: "#263a32", stroke: "#c49a4e", "stroke-width": 3 }));
        rotor.append(grainRing(56,78));
        // Rounded brass medallion and eight-point compass stay attached to the spinning hub.
        const compass = svgElement("g", { class: "lr-wheel-compass", "aria-hidden": "true" });
        compass.append(svgElement("circle", { cx: 160, cy: 160, r: 46, fill: "#173b33", stroke: "url(#lr-wheel-brass)", "stroke-width": 3 }),
          svgElement("circle", { cx: 160, cy: 160, r: 40, fill: "none", stroke: "#e3c479", "stroke-width": .6 }));
        const compassPoints = Array.from({ length: 16 }, (_, index) => {
          const angle = index * Math.PI / 8 - Math.PI / 2, radius = index % 2 ? 11 : index % 4 ? 30 : 42;
          return [160 + Math.cos(angle) * radius, 160 + Math.sin(angle) * radius];
        });
        compass.append(svgElement("polygon", { points: compassPoints.map(point => point.join(",")).join(" "), fill: "url(#lr-wheel-brass)", stroke: "#ffe7a4", "stroke-width": 1.2, "stroke-linejoin": "round" }));
        for (let index = 0; index < 16; index += 2) {
          const tip = compassPoints[index], inner = compassPoints[(index + 1) % 16];
          compass.append(svgElement("path", { d: `M160 160 L${tip[0]} ${tip[1]} L${inner[0]} ${inner[1]} Z`, fill: "#8e591d", opacity: .65, "stroke-linejoin": "round" }));
        }
        compass.append(svgElement("circle", { cx: 160, cy: 160, r: 6, fill: "url(#lr-wheel-brass)", stroke: "#fff1b8", "stroke-width": 1.2 }));
        rotor.append(compass);
        // Bowl inlays alternate radial/tangential diamonds, with an inward point on every one.
        const inlays = svgElement("g", { class: "lr-wheel-inlays", "aria-hidden": "true" });
        for (let index = 0; index < 8; index++) {
          const radial = index % 2 === 0, halfWidth = radial ? 2 : 4, halfHeight = radial ? 4 : 2;
          inlays.append(svgElement("polygon", { class: `lr-wheel-inlay ${radial ? "is-radial" : "is-tangential"}`, points: `160,${29 - halfHeight} ${160 + halfWidth},29 160,${29 + halfHeight} ${160 - halfWidth},29`, transform: `rotate(${index * 45} 160 160)`, fill: "url(#lr-wheel-brass)", stroke: "#f8e6a8", "stroke-width": .6, "stroke-linejoin": "round" }));
        }
        const definitions = svgElement("defs", {}), brass = svgElement("linearGradient", { id: "lr-wheel-brass", x1: "0%", y1: "0%", x2: "100%", y2: "100%" });
        for (const [offset, color] of [["0%", "#fff2b4"], ["30%", "#c18b32"], ["52%", "#ffe69b"], ["78%", "#a96d21"], ["100%", "#edd088"]]) brass.append(svgElement("stop", { offset, "stop-color": color }));
        definitions.append(brass);
        ball = svgElement("g", { class: "lr-wheel-ball" }); ball.append(svgElement("circle", { cx: 160, cy: 160 - wheelGeometry.orbit, r: 5, fill: "white", stroke: "#ccdae7", "stroke-width": 1 }));
        // A vector hand points at the launch position; it never participates in hit testing.
        flickHand = svgElement("g", { class: "lr-wheel-hand", "aria-hidden": "true", opacity: 0 });
        flickHand.append(svgElement("path", { d: "M43 -8 L62 -5 L60 21 L42 18 Z", fill: "#25496d", stroke: "#102c45", "stroke-width": 1.5 }));
        flickHand.append(svgElement("path", { d: "M44 -5 C36 -7 29 -7 23 -5 L4 -4 C-3 -4 -5 -1 -3 2 C-2 4 2 5 6 4 L20 3 L14 9 C11 13 14 16 18 15 L26 10 L22 17 C21 21 25 23 28 19 L33 13 L31 20 C31 24 36 25 38 21 L44 14 Z", fill: "#efbc91", stroke: "#87553c", "stroke-width": 1.3, "stroke-linejoin": "round" }));
        flickHand.append(svgElement("path", { d: "M1 -2 L7 -2 M27 3 L32 5 M35 6 L39 8", fill: "none", stroke: "#bd8260", "stroke-width": 1.2, "stroke-linecap": "round" }));
        pocketHighlight = svgElement("circle", { class: "lr-pocket-highlight", cx: 160, cy: 160, r: 8.5, fill: "none", stroke: "#ffe08a", "stroke-width": 2, opacity: 0, "aria-hidden": "true" });
        wheelScene = svgElement("g", { class: "lr-wheel-scene" });
        wheelScene.append(definitions, svgElement("circle", { cx: 160, cy: 160, r: 151, fill: "#402c22", stroke: "#b68a4d", "stroke-width": 5 }), grainRing(122,148), inlays, rotor, ball, pocketHighlight, flickHand);
        wheel.replaceChildren(wheelScene);
      }
      /** Integrates a linear spin-up followed by constant angular speed, in degrees. */
      function spinUpDistance(elapsed, speed, startup) {
        return speed * (elapsed < startup ? elapsed * elapsed / (2 * startup) : elapsed - startup / 2);
      }
      /** Samples visible acceleration, cruising, and one second of smooth wheel braking. */
      function wheelAngle(elapsed, duration) {
        const startup = Math.min(800, duration / 4), brake = Math.min(1000, duration / 2);
        const speed = 1080 / (duration - startup / 2 - brake / 2);
        const time = Math.max(0, Math.min(duration, elapsed)), brakingTime = Math.max(0, time - (duration - brake));
        return spinUpDistance(time, speed, startup) - speed * brakingTime * brakingTime / (2 * brake);
      }
      /** Samples the ball's orbit, eased pocket capture, and final rotation with the braking wheel. */
      function ballTransform(elapsed, duration, landing, pocketAngle, revealed) {
        const revealAt = duration - landing, catchAt = duration - Math.min(1000, landing / 2);
        const startup = Math.min(800, duration / 4), orbitSpeed = -2160 / (duration - startup / 2);
        const start = spinUpDistance(revealAt, orbitSpeed, startup);
        if (!revealed || elapsed < revealAt) return `rotate(${spinUpDistance(elapsed, orbitSpeed, startup)}deg) translateY(0px)`;
        const wheelAtCatch = wheelAngle(catchAt, duration);
        const turns = Math.ceil((wheelAtCatch + pocketAngle - start) / 360);
        const end = wheelAtCatch + pocketAngle - turns * 360;
        if (elapsed >= catchAt) return `rotate(${wheelAngle(elapsed, duration) + pocketAngle - turns * 360}deg) translateY(${wheelGeometry.orbit - wheelGeometry.pocket}px)`;
        const interval = catchAt - revealAt, progress = Math.max(0, Math.min(1, (elapsed - revealAt) / interval));
        // Cubic Hermite joins the free orbit to the wheel's velocity without a visible jump.
        const square = progress * progress, cube = square * progress;
        const wheelSpeed = 1080 / (duration - startup / 2 - Math.min(1000, duration / 2) / 2);
        const angle = (2 * cube - 3 * square + 1) * start + (cube - 2 * square + progress) * orbitSpeed * interval
          + (-2 * cube + 3 * square) * end + (cube - square) * wheelSpeed * interval;
        const inward = square * (3 - 2 * progress) * (wheelGeometry.orbit - wheelGeometry.pocket);
        return `rotate(${angle}deg) translateY(${inward}px)`;
      }
      /** Samples the launch hand's approach, leftward flick, and withdrawal on the spin clock. */
      function flickPose(elapsed) {
        const poses = [
          { time: 0, x: 171, y: 21, angle: 14, opacity: 1 },
          { time: 120, x: 163, y: 23, angle: 0, opacity: 1 },
          { time: 300, x: 150, y: 24, angle: -16, opacity: 1 },
          { time: 850, x: 202, y: -15, angle: 28, opacity: 0 }
        ];
        const end = poses.findIndex(pose => pose.time >= elapsed);
        const to = poses[end < 0 ? poses.length - 1 : end], from = poses[Math.max(0, end - 1)];
        const fraction = end < 0 ? 1 : Math.max(0, Math.min(1, (elapsed - from.time) / Math.max(1, to.time - from.time)));
        const progress = fraction * fraction * (3 - 2 * fraction);
        return { transform: `translate(${from.x + (to.x - from.x) * progress}px, ${from.y + (to.y - from.y) * progress}px) rotate(${from.angle + (to.angle - from.angle) * progress}deg)`, opacity: from.opacity + (to.opacity - from.opacity) * progress };
      }
      /** Centers a gentle result zoom on the landed ball without changing the wheel's outcome. */
      function resultCamera(elapsed, angle) {
        const progress = Math.max(0, Math.min(1, elapsed / 650)), eased = progress * progress * (3 - 2 * progress);
        const scale = 1 + .65 * eased, radians = angle * Math.PI / 180;
        const x = Math.sin(radians) * wheelGeometry.pocket, y = -Math.cos(radians) * wheelGeometry.pocket;
        return `translate(${-x * scale * eased}px, ${-y * scale * eased}px) scale(${scale})`;
      }
      /** Highlights the winning inner pocket and zooms only after the wheel has stopped. */
      function showResultPocket(angle) {
        const isResult = ["results", "finished"].includes(state.phase) && state.winningNumber !== null;
        wheelScene.style.transform = "translate(0px, 0px) scale(1)";
        pocketHighlight.style.opacity = isResult ? "1" : "0";
        if (!isResult) return;
        const radians = angle * Math.PI / 180;
        pocketHighlight.setAttribute("cx", String(160 + Math.sin(radians) * wheelGeometry.pocket));
        pocketHighlight.setAttribute("cy", String(160 - Math.cos(radians) * wheelGeometry.pocket));
        if (reducedMotion.matches || document.body.classList.contains("reduce-interface-motion")) return;
        const elapsed = Math.max(0, state.phaseDurationMs - state.remainingMs);
        wheelScene.style.transform = resultCamera(elapsed, angle);
        if (!state.isPaused && elapsed < 650 && wheelScene.animate) {
          const remaining = 650 - elapsed, frames = [];
          for (let time = 0; time < remaining; time += 16) frames.push({ offset: time / remaining, transform: resultCamera(elapsed + time, angle) });
          frames.push({ offset: 1, transform: resultCamera(650, angle) });
          wheelAnimations.push(wheelScene.animate(frames, { duration: remaining, easing: "linear", fill: "forwards" }));
        }
      }
      /** Animates continuous orbit and capture; only the server's revealed pocket guides the landing. */
      function updateWheel() {
        if (!rotor || !state) return;
        const key = `${state.phaseId}:${state.phase}:${state.isPaused}:${state.winningNumber}`;
        if (wheelKey === key) return; wheelKey = key;
        for (const animation of wheelAnimations) animation.cancel(); wheelAnimations = [];
        flickHand.style.opacity = "0";
        const index = state.winningNumber === null ? 0 : state.wheelPockets.indexOf(state.winningNumber);
        const angle = Math.max(0, index) * 360 / state.wheelPockets.length;
        showResultPocket(angle);
        if (state.phase !== "rolling") { rotor.style.transform = "rotate(0deg)"; ball.style.transform = `rotate(${angle}deg) translateY(${wheelGeometry.orbit - wheelGeometry.pocket}px)`; return; }
        const duration = state.phaseDurationMs, remaining = state.remainingMs, elapsed = Math.max(0, duration - remaining);
        const revealed = state.winningNumber !== null;
        const handPose = flickPose(elapsed); flickHand.style.transform = handPose.transform;
        flickHand.style.opacity = reducedMotion.matches ? "0" : String(handPose.opacity);
        rotor.style.transform = `rotate(${wheelAngle(elapsed, duration)}deg)`;
        ball.style.transform = ballTransform(elapsed, duration, state.landingDurationMs, angle, revealed);
        if (state.isPaused || remaining <= 0 || reducedMotion.matches) {
          if (revealed && reducedMotion.matches) { rotor.style.transform = "rotate(0deg)"; ball.style.transform = `rotate(${angle}deg) translateY(${wheelGeometry.orbit - wheelGeometry.pocket}px)`; }
          return;
        }
        if (rotor.animate && ball.animate) {
          // Sample one continuous trajectory; both animations keep the authoritative phase deadline.
          const samples = Math.max(2, Math.ceil(remaining / 16)), wheelFrames = [], ballFrames = [];
          for (let sample = 0; sample <= samples; sample++) {
            const offset = sample / samples, time = elapsed + remaining * offset;
            wheelFrames.push({ offset, transform: `rotate(${wheelAngle(time, duration)}deg)` });
            ballFrames.push({ offset, transform: ballTransform(time, duration, state.landingDurationMs, angle, revealed) });
          }
          wheelAnimations.push(rotor.animate(wheelFrames, { duration: remaining, easing: "linear", fill: "forwards" }));
          wheelAnimations.push(ball.animate(ballFrames, { duration: remaining, easing: "linear", fill: "forwards" }));
          if (elapsed < 850 && flickHand.animate) {
            const handDuration = Math.min(remaining, 850 - elapsed), handFrames = [];
            for (let time = 0; time < handDuration; time += 16) handFrames.push({ offset: time / handDuration, ...flickPose(elapsed + time) });
            handFrames.push({ offset: 1, ...flickPose(elapsed + handDuration) });
            wheelAnimations.push(flickHand.animate(handFrames, { duration: handDuration, easing: "linear", fill: "forwards" }));
          }
        }
      }
      /** Reconciles one authoritative snapshot while keeping form nodes, board targets, and input focus stable. */
      function receiveState(next) {
        if (destroyed) return;
        const previousPhase = state ? `${state.matchId}:${state.phaseId}` : null;
        state = next; localDeadline = state.isPaused ? null : performance.now() + state.remainingMs;
        recoveryDeadline = state.recoveryRemainingMs === null ? null : performance.now() + state.recoveryRemainingMs;
        if (!catalog.size) { catalog = new Map(state.betSpaces.map(space => [space.id, space])); buildBoard(); buildWheel(state.wheelPockets); }
        timerAnimation?.cancel(); timerAnimation = null;
        const fraction = Math.max(0, Math.min(1, state.remainingMs / Math.max(1, state.phaseDurationMs))); timerFill.style.transform = `scaleX(${fraction})`;
        if (!state.isPaused && state.remainingMs > 0 && timerFill.animate) timerAnimation = timerFill.animate([{ transform: `scaleX(${fraction})` }, { transform: "scaleX(0)" }], { duration: state.remainingMs, easing: "linear", fill: "forwards" });
        const text = state.phase === "finished" ? "Game finished" : `Round ${state.round}${state.isTiebreaker ? " \u00b7 tiebreaker" : ""} \u00b7 ${state.phase === "rewards" ? "Choose a card reward" : state.phase === "shop" ? "Shop: buy cards or lock in" : state.phase === "betting" ? "Place your bets" : state.phase === "preparations" ? "Final Preparations: play cards or lock in" : state.phase === "rolling" ? "Wheel spinning" : "Round results"}`;
        const announcement = state.isPaused ? state.pauseMessage ?? "Game paused" : text;
        if (status.textContent !== announcement) status.textContent = announcement;
        find("[data-lr-recovery]").textContent = state.recoveryRemainingMs === null ? "" : `Disconnect pause: ${Math.ceil(state.recoveryRemainingMs / 1000)} seconds remaining. The host may resume now.`;
        find("[data-lr-betting]").hidden = !["shop", "betting", "rewards", "preparations"].includes(state.phase);
        find("[data-lr-chip-dock]").hidden = state.phase !== "betting";
        find("[data-lr-wheel-view]").hidden = ["shop", "betting", "rewards", "preparations"].includes(state.phase);
        if (previousPhase !== `${state.matchId}:${state.phaseId}` && bankDialog.open) closeBank();
        if (previousPhase !== `${state.matchId}:${state.phaseId}` && cardDialog.open) closeCardDialog(true);
        if (dialog.open && !editingBetId && previousPhase !== `${state.matchId}:${state.phaseId}` && state.phase !== "results") closeDialog();
        renderResults();
        renderPlayers(); renderTableChips(); renderControls(); renderClock(); updateWheel(); highlight(selectedSpace); renderCards();
      }
      /** Toggles readiness; the server decides whether this was the final lock and advances the phase. */
      function toggleLock() { if (!dialog.open && !bankDialog.open && !cardDialog.open && state?.canLock && !pending) void submit("set-lock", { locked: !state.isLocked }); }
      /** Keeps a typed custom value separate from the player's authoritative ledger. */
      function amountChanged() { selectedChip = Number(amountInput.value); renderControls(); }
      /** Selects the participant's current available cash as a single chip value. */
      function selectMax() { selectChip(localPlayer()?.available ?? 0); }
      /** Delegates pause authority to GameHub rather than deciding host ownership inside the plugin. */
      async function togglePause() { if (!state || !context.isHost) return; const response = await context.requestPause(!state.isPaused); if (!destroyed && response && !response.success) context.notify(response.message ?? "Pause could not be changed."); }
      /** Uses GameHub's existing confirmation flow for leaving or ending the game. */
      function leave() { if (context.isHost) context.requestExit(); else context.requestLeave(); }
      /** Recomputes compact stack heights when the phone breakpoint changes. */
      function compactChanged() { if (state && !destroyed) renderTableChips(); }
      /** Rebuilds animation presentation when the operating-system motion preference changes. */
      function motionChanged() { wheelKey = ""; updateWheel(); }
      root.addEventListener("pointerover", cardHoverEntered); root.addEventListener("pointerout", cardHoverLeft);
      root.addEventListener("focusin", cardHoverEntered); root.addEventListener("focusout", cardHoverLeft);
      cardDialog.addEventListener("cancel", cancelCardDialog); cardDialog.addEventListener("close", cardDialogClosed);
      root.addEventListener("click", cardClicked); find("[data-lr-card-close]").addEventListener("click", closeCardDialog);
      buildChips(); renderControls(); layoutBoard();
      table.addEventListener("pointerleave", clearNearbyMarkers);
      root.addEventListener("click", rootClick); chips.addEventListener("pointerdown", pointerDown);
      root.addEventListener("pointerover", previewEntered); root.addEventListener("pointerout", previewLeft);
      root.addEventListener("focusin", previewEntered); root.addEventListener("focusout", previewLeft); root.addEventListener("pointerdown", previewHoldStart); root.addEventListener("contextmenu", previewContext);
      window.addEventListener("pointercancel", finishPreviewHold);
      find("[data-lr-dialog-close]").addEventListener("click", closeDialog); dialog.addEventListener("close", dialogClosed);
      editForm.addEventListener("submit", saveEditedBet); find("[data-lr-edit-remove]").addEventListener("click", removeEditedBet); resultsButton.addEventListener("click", openResults);
      window.addEventListener("pointermove", pointerMove, { passive: false }); window.addEventListener("pointerup", pointerUp); window.addEventListener("pointercancel", cancelDrag);
      amountInput.addEventListener("input", amountChanged); find("[data-lr-max]").addEventListener("click", selectMax);
      lockButton.addEventListener("click", toggleLock); pauseButton.addEventListener("click", togglePause); leaveButton.addEventListener("click", leave);
      compact.addEventListener?.("change", compactChanged); reducedMotion.addEventListener?.("change", motionChanged);
      find("[data-lr-call-bank]").addEventListener("click", openBank); find("[data-lr-bank-close]").addEventListener("click", closeBank);
      bankDialog.addEventListener("click", bankPresetClicked); bankDialog.addEventListener("input", bankAmountChanged);
      borrowForm.addEventListener("submit", submitBank); repayForm.addEventListener("submit", submitBank);
      root.addEventListener("dblclick", purchaseShopCard); cardDialog.addEventListener("keydown", inspectShopKey);
      shopDialog.addEventListener("cancel", cancelShop); shopDialog.addEventListener("keydown", inspectShopKey);
      find("[data-lr-shop-hand]").addEventListener("click", checkShopCards); find("[data-lr-shop-pause]").addEventListener("click", togglePause); find("[data-lr-shop-bank]").addEventListener("click", openBank); find("[data-lr-shop-lock]").addEventListener("click", toggleLock); find("[data-lr-shop-reroll]").addEventListener("click", rerollShop);
      const shopObserver = typeof ResizeObserver === "function" ? new ResizeObserver(fitShop) : null; shopObserver?.observe(find(".lr-shop-viewport"));
      const unsubscribe = context.input?.onAction("toggle-lock", toggleLock) ?? (() => {});
      const cardObserver = typeof ResizeObserver === "function" ? new ResizeObserver(fitVisibleCards) : null;
      for (const container of [cardHand, cardList, cardHover]) cardObserver?.observe(container);
      const observer = typeof ResizeObserver === "function" ? new ResizeObserver(positionTargets) : null; observer?.observe(table);
      window.addEventListener("resize", layoutBoard);
      landscape.addEventListener?.("change", layoutBoard);
      const clockInterval = setInterval(renderClock, 200);
      return {
        receiveState,
        /** Displays public notices without exposing or deriving a hidden wheel result. */
        receiveEvent(event) { if (!destroyed && event.type === "notification" && typeof event.payload?.message === "string") context.notify(event.payload.message); },
        /** Refreshes host controls immediately after room ownership changes. */
        receivePlatformEvent(event) { if (!destroyed && event.type === "host-changed") renderControls(); },
        /** Freezes presentation promptly while the next authoritative pause snapshot is in flight. */
        setPaused(isPaused) { if (!state || destroyed || state.isPaused === isPaused) return; receiveState({ ...state, isPaused, remainingMs: localDeadline === null ? state.remainingMs : Math.max(0, localDeadline - performance.now()) }); },
        /** Removes every listener, timer, gesture, observer, and animation owned by this mount. */
        destroy() {
          destroyed = true; closeBank(); closeShop(); shopObserver?.disconnect(); clearTimeout(resultsTimer); finishPreviewHold(); closeDialog(); preview.hidden = true; cancelDrag(); clearInterval(clockInterval); clearAnimations(); observer?.disconnect(); cardObserver?.disconnect(); unsubscribe();
          clearNearbyMarkers(); table.removeEventListener("pointerleave", clearNearbyMarkers);
          root.removeEventListener("click", rootClick); chips.removeEventListener("pointerdown", pointerDown);
          root.removeEventListener("pointerover", previewEntered); root.removeEventListener("pointerout", previewLeft);
          root.removeEventListener("focusin", previewEntered); root.removeEventListener("focusout", previewLeft); root.removeEventListener("pointerdown", previewHoldStart); root.removeEventListener("contextmenu", previewContext);
          window.removeEventListener("pointercancel", finishPreviewHold);
          find("[data-lr-dialog-close]").removeEventListener("click", closeDialog); dialog.removeEventListener("close", dialogClosed);
          editForm.removeEventListener("submit", saveEditedBet); find("[data-lr-edit-remove]").removeEventListener("click", removeEditedBet); resultsButton.removeEventListener("click", openResults);
          resultList.replaceChildren(); resultsButton.disabled = true;
          window.removeEventListener("pointermove", pointerMove); window.removeEventListener("pointerup", pointerUp); window.removeEventListener("pointercancel", cancelDrag); window.removeEventListener("resize", layoutBoard);
          landscape.removeEventListener?.("change", layoutBoard);
          amountInput.removeEventListener("input", amountChanged); find("[data-lr-max]").removeEventListener("click", selectMax);
          lockButton.removeEventListener("click", toggleLock); pauseButton.removeEventListener("click", togglePause); leaveButton.removeEventListener("click", leave);
          compact.removeEventListener?.("change", compactChanged); reducedMotion.removeEventListener?.("change", motionChanged);
          root.removeEventListener("pointerover", cardHoverEntered); root.removeEventListener("pointerout", cardHoverLeft);
          root.removeEventListener("focusin", cardHoverEntered); root.removeEventListener("focusout", cardHoverLeft);
          cardDialog.removeEventListener("cancel", cancelCardDialog); cardDialog.removeEventListener("close", cardDialogClosed);
          closeCardDialog(true); hideCardHover(); root.removeEventListener("click", cardClicked); find("[data-lr-card-close]").removeEventListener("click", closeCardDialog); cardHand.replaceChildren(); cardList.replaceChildren();
          find("[data-lr-call-bank]").removeEventListener("click", openBank); find("[data-lr-bank-close]").removeEventListener("click", closeBank);
          bankDialog.removeEventListener("click", bankPresetClicked); bankDialog.removeEventListener("input", bankAmountChanged);
          borrowForm.removeEventListener("submit", submitBank); repayForm.removeEventListener("submit", submitBank);
          root.removeEventListener("dblclick", purchaseShopCard); cardDialog.removeEventListener("keydown", inspectShopKey);
          shopDialog.removeEventListener("cancel", cancelShop); shopDialog.removeEventListener("keydown", inspectShopKey);
          find("[data-lr-shop-hand]").removeEventListener("click", checkShopCards); find("[data-lr-shop-pause]").removeEventListener("click", togglePause); find("[data-lr-shop-bank]").removeEventListener("click", openBank); find("[data-lr-shop-lock]").removeEventListener("click", toggleLock); find("[data-lr-shop-reroll]").removeEventListener("click", rerollShop);
          chips.replaceChildren(); table.replaceChildren(); ownBets.replaceChildren(); allBets.replaceChildren(); players.replaceChildren(); topPlayers.replaceChildren(); wheel.replaceChildren(); state = null;
        }
      };
    }
  });
})();
