/** Registers the browser renderer; all money and roulette outcomes remain server-authoritative. */
(function registerLoadedRoulette() {
  window.GameHubRegisterGameClientModule("loaded-roulette", {
    /** Mounts the betting board, chip controls, wheel, and owned cleanup resources. */
    mount(context) {
      /** Game-scoped queries prevent one plugin from changing another game's controls. */
      const root = context.root;
      /** Returns a required element from this game's own markup. */
      const find = selector => { const element = root.querySelector(selector); if (!element) throw new Error(`Missing Loaded Roulette element: ${selector}`); return element; };
      /** Stable UI elements are retained so timer ticks never rebuild the board or form. */
      const table = find("[data-lr-table]"), players = find("[data-lr-players]"), topPlayers = find("[data-lr-players-top]");
      const amountInput = find("[data-lr-amount]"), chips = find("[data-lr-chips]"), spaceSelect = find("[data-lr-space]");
      const form = find("[data-lr-bet-form]"), lockButton = find("[data-lr-lock]"), pauseButton = find("[data-lr-pause]"), leaveButton = find("[data-lr-leave]");
      const timerLabel = find("[data-lr-timer]"), timerFill = find("[data-lr-timer-fill]"), status = find("[data-lr-status]");
      const wheel = find("[data-lr-wheel]"), ownBets = find("[data-lr-own-bets]"), allBets = find("[data-lr-all-bets]");
      /** One native dialog serves result receipts and direct editing of the viewer's own chips. */
      const dialog = find("[data-lr-dialog]"), resultList = find("[data-lr-results]"), editForm = find("[data-lr-edit-form]"), editAmount = find("[data-lr-edit-amount]");
      const preview = find("[data-lr-preview]"), resultsButton = find("[data-lr-show-results]");
      /** Presentation state is discarded on unmount; receipts never authorize a payout. */
      let lastResults = null, resultsKey = "", resultsTimer = null, editingBetId = null, editingPhase = null, returnFocus = null, hold = null, previewTarget = null;
      /** The last trusted snapshot and local presentation deadline; no client value grants money. */
      let state = null, localDeadline = null, recoveryDeadline = null, pending = false, destroyed = false, selectedSpace = "straight:0", sequence = 0;
      /** Board nodes and bet rows remain stable while other players submit actions. */
      const targets = new Map(), cells = new Map(), rows = new Map();
      /** Cached seam centers keep proximity checks free of per-pointer layout reads. */
      let markerPoints = [], markerBounds = { left: 0, top: 0 }, lastMarkerPointer = null;
      let catalog = new Map(), selectedChip = 100, hoverSpace = null, suppressClickUntil = 0;
      /** These handles are cancelled when a new phase arrives or the game is unmounted. */
      let timerAnimation = null, wheelAnimations = [], wheelKey = "", rotor = null, ball = null, flickHand = null, wheelScene = null, pocketHighlight = null;
      /** A pointer gesture works with mouse, pen, and touch instead of desktop-only HTML dragging. */
      let drag = null, ghost = null;
      /** SVG radii separate the outer orbit, inward-facing number boxes, and inner landing pockets. */
      const wheelGeometry = { orbit: 137, number: 110, divider: 100, pocket: 90 };
      const compact = window.matchMedia("(max-width: 575.98px)");
      const landscape = window.matchMedia("(orientation: landscape)");
      const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");

      /** Formats whole in-game money without hiding its exact value. */
      function money(value) { return Number(value).toLocaleString(); }
      /** Uses short chip labels while exact amounts remain in accessible labels and the bet list. */
      function shortMoney(value) { return value >= 1_000_000 ? `${Number((value / 1_000_000).toFixed(1))}m` : value >= 1_000 ? `${Number((value / 1_000).toFixed(1))}k` : String(value); }
      /** Finds the viewer's current participant record, including the stable chip-owner ID. */
      function localPlayer() { return state?.balances.find(player => player.id === context.memberId) ?? null; }
      /** Returns one to ten visual chips, or one to five on small screens; the first band starts at $1. */
      function stackHeight(stake, balance) { const maximum = compact.matches ? 5 : 10; return Math.max(1, Math.min(maximum, Math.ceil(stake / Math.max(1, balance) * maximum))); }
      /** Creates text-only elements so player names and messages cannot inject HTML. */
      function element(tag, className, text) { const node = document.createElement(tag); if (className) node.className = className; if (text !== undefined) node.textContent = text; return node; }
      /** Submits one intent tied to the current match/phase and ignores replies after unmount. */
      async function submit(type, payload) {
        if (!state || pending || destroyed) return;
        pending = true; renderControls();
        const requestId = window.crypto?.randomUUID?.() ?? `${Date.now()}_${++sequence}`;
        try {
          const response = await context.submitAction({ type, payload: { ...payload, matchId: state.matchId, phaseId: state.phaseId, requestId } });
          if (!destroyed && !response.success) context.notify(response.message ?? "The action was not accepted.");
          return response;
        } catch { if (!destroyed) context.notify("The action could not be sent. Check your connection."); }
        finally { if (!destroyed) { pending = false; renderControls(); } }
      }
      /** Places the chosen chip amount; the server checks cash, lock state, and the legal target again. */
      function place(spaceId, chipAmount = Number(amountInput.value)) {
        if (!state?.canBet || pending || destroyed) return;
        const amount = chipAmount;
        if (!Number.isSafeInteger(amount) || amount <= 0) { context.notify("Choose a positive whole chip value."); return; }
        if (amount > (localPlayer()?.available ?? 0)) { context.notify("That chip is larger than your available money."); return; }
        selectedSpace = spaceId; spaceSelect.value = spaceId; highlight(spaceId);
        void submit("place-bet", { spaceId, amount });
      }
      /** Selects a denomination or custom value without spending it. */
      function selectChip(value) { selectedChip = value; amountInput.value = String(value); renderControls(); }
      /** Highlights the complete covered-number set before or during a drop. */
      function highlight(spaceId) {
        const space = catalog.get(spaceId); hoverSpace = spaceId;
        for (const [id, target] of targets) target.classList.toggle("is-targeted", id === spaceId);
        for (const [number, cell] of cells) cell.classList.toggle("is-covered", space?.numbers.includes(number) === true);
        find("[data-lr-selection]").textContent = space ? `${space.label} \u00b7 ${space.profitMultiplier}:1 profit \u00b7 covers ${space.numbers.join(", ")}` : "Choose a betting target.";
      }
      /** Shows covered numbers and selected stake/profit/return before a wager is submitted. */
      function showPreview(target) {
        const space = catalog.get(target.dataset.betSpace); if (!space || destroyed || dialog.open || state?.phase !== "betting") return;
        previewTarget?.removeAttribute("aria-describedby"); previewTarget = target; target.setAttribute("aria-describedby", "lr-bet-preview");
        highlight(space.id); preview.replaceChildren(element("strong", "", space.label));
        const stake = Number(amountInput.value), returned = stake * (space.profitMultiplier + 1);
        preview.append(element("p", "", `Covers ${space.numbers.join(", ")}`));
        preview.append(element("p", "", Number.isSafeInteger(stake) && stake > 0 && Number.isSafeInteger(returned)
          ? `Stake ${money(stake)} | If won: profit ${money(returned - stake)}, return ${money(returned)}` : `${space.profitMultiplier}:1 profit; choose a whole chip amount.`));
        preview.hidden = false; const rect = target.getBoundingClientRect();
        preview.style.left = `${Math.max(8, Math.min(window.innerWidth - preview.offsetWidth - 8, rect.left + rect.width / 2 - preview.offsetWidth / 2))}px`;
        preview.style.top = `${Math.max(8, rect.top - preview.offsetHeight - 8)}px`;
      }
      /** Dismisses a transient preview and restores the selected betting coverage. */
      function hidePreview() { preview.hidden = true; previewTarget?.removeAttribute("aria-describedby"); previewTarget = null; if (catalog.size && !destroyed) highlight(selectedSpace); }
      /** Previews pointer hover or keyboard focus without placing a wager. */
      function previewEntered(event) {
        if (event.pointerType === "touch") return;
        const target = event.target.closest?.("[data-bet-space]");
        if (target && !target.contains(event.relatedTarget)) showPreview(target);
      }
      /** Clears a preview after leaving its complete betting target. */
      function previewLeft(event) {
        const target = event.target.closest?.("[data-bet-space]");
        if (target && !target.contains(event.relatedTarget)) hidePreview();
      }
      /** Replaces a betting target's native long-press menu with its safe preview. */
      function previewContext(event) {
        const target = event.target.closest?.("[data-bet-space]"); if (!target) return;
        event.preventDefault(); showPreview(target); suppressClickUntil = performance.now() + 350;
      }
      /** Starts a touch hold; a normal tap still places the selected chip. */
      function previewHoldStart(event) {
        if (event.pointerType !== "touch") return;
        finishPreviewHold(); hidePreview();
        const target = event.target.closest?.("[data-bet-space]"); if (!target) return;
        hold = { pointerId: event.pointerId, x: event.clientX, y: event.clientY, shown: false, timer: null };
        hold.timer = setTimeout(() => { if (hold && !destroyed) { hold.shown = true; showPreview(target); } }, 450);
      }
      /** Cancels a pending hold on movement; finishing a displayed hold suppresses its synthetic click. */
      function finishPreviewHold(event) {
        if (!hold || (event && event.pointerId !== hold.pointerId)) return;
        clearTimeout(hold.timer); if (hold.shown) suppressClickUntil = performance.now() + 350; hold = null;
      }
      /** Opens the shared dialog with native focus trapping and a DOM-test fallback. */
      function showDialog() {
        hidePreview(); returnFocus = document.activeElement;
        if (!dialog.open) { if (typeof dialog.showModal === "function") dialog.showModal(); else dialog.setAttribute("open", ""); }
      }
      /** Closes a local dialog without mutating bets or dismissing a future round's results. */
      function closeDialog() {
        editingBetId = null; editingPhase = null;
        if (dialog.open) { if (typeof dialog.close === "function") dialog.close(); else dialog.removeAttribute("open"); }
        if (returnFocus?.isConnected && !returnFocus.disabled) returnFocus.focus(); returnFocus = null;
      }
      /** Clears editing state when Escape dismisses the native dialog. */
      function dialogClosed() { editingBetId = null; editingPhase = null; }
      /** Opens a focused amount editor only for a live wager owned by the current viewer. */
      function openBetEditor(betId) {
        const bet = state?.bets.find(item => item.id === betId && item.ownerId === localPlayer()?.participantId);
        if (!bet || !state.canBet || pending) return;
        editingBetId = bet.id; editingPhase = `${state.matchId}:${state.phaseId}`;
        find("[data-lr-dialog-title]").textContent = `Edit ${catalog.get(bet.spaceId).label}`;
        find("[data-lr-dialog-summary]").textContent = `${money(bet.amount)} reserved | ${money(localPlayer().available + bet.amount)} available for this bet`;
        editForm.hidden = false; resultList.hidden = true; find("[data-lr-results-note]").hidden = true;
        editAmount.value = String(bet.amount); editAmount.max = String(localPlayer().available + bet.amount);
        showDialog(); editAmount.focus(); editAmount.select();
      }
      /** Updates the selected own bet using the same validated action as the side-panel editor. */
      async function saveEditedBet(event) {
        event.preventDefault(); const id = editingBetId, amount = Number(editAmount.value);
        if (!id || !Number.isSafeInteger(amount) || amount <= 0) return;
        const response = await submit("change-bet", { betId: id, amount });
        if (!destroyed && response?.success && editingBetId === id) closeDialog();
      }
      /** Removes an owned wager and releases its reservation only after server acknowledgement. */
      async function removeEditedBet() {
        const id = editingBetId; if (!id) return;
        const response = await submit("remove-bet", { betId: id });
        if (!destroyed && response?.success && editingBetId === id) closeDialog();
      }
      /** Shows the most recent settled receipts without reopening automatically after dismissal. */
      function openResults() {
        clearTimeout(resultsTimer); resultsTimer = null; if (!lastResults || destroyed) return;
        editingBetId = null; editingPhase = null;
        find("[data-lr-dialog-title]").textContent = `Round ${lastResults.round} | Winning pocket ${lastResults.winningNumber}`;
        const mine = lastResults.receipts.filter(bet => bet.ownerId === lastResults.viewer);
        const selected = lastResults.viewer ? mine : lastResults.receipts;
        const staked = selected.reduce((sum, bet) => sum + bet.amount, 0), returned = selected.reduce((sum, bet) => sum + bet.returned, 0), net = returned - staked;
        find("[data-lr-dialog-summary]").textContent = `${lastResults.viewer ? "Your round" : "Table totals"}: Bet ${money(staked)} | Returned ${money(returned)} | Net ${net >= 0 ? "+" : ""}${money(net)}${lastResults.winner ? ` | ${lastResults.winner} wins the match!` : ""}`;
        editForm.hidden = true; resultList.hidden = false; find("[data-lr-results-note]").hidden = false;
        showDialog();
      }
      /** Caches one round of receipts and builds one scrollable result card for each settled bet. */
      function renderResults() {
        if (state.phase !== "results") { clearTimeout(resultsTimer); resultsTimer = null; return; }
        const key = `${state.matchId}:${state.phaseId}`; if (key === resultsKey) return; resultsKey = key;
        lastResults = { round: state.round, winningNumber: state.winningNumber, viewer: localPlayer()?.participantId, receipts: state.receipts.map(bet => ({ ...bet })), winner: state.balances.find(player => player.id === state.winnerId)?.name };
        const owners = new Map(state.balances.map(player => [player.participantId, player])); resultList.replaceChildren();
        for (const bet of lastResults.receipts) {
          const owner = owners.get(bet.ownerId), card = element("article", `lr-receipt ${bet.won ? "is-win" : "is-loss"}`), net = bet.returned - bet.amount;
          card.style.setProperty("--player-color", owner?.color ?? "#aaa");
          card.append(element("strong", "", `${owner?.name ?? "Departed player"} | ${bet.won ? "WIN" : "LOSS"}`), element("h4", "", catalog.get(bet.spaceId)?.label ?? bet.spaceId), element("p", "", `Bet ${money(bet.amount)} | Returned ${money(bet.returned)}`), element("p", "lr-receipt-net", `Net ${net >= 0 ? "+" : ""}${money(net)}`)); resultList.append(card);
        }
        if (!lastResults.receipts.length) resultList.append(element("p", "", "No bets were placed this round."));
        resultList.scrollTop = 0; resultsButton.disabled = false;
        resultsTimer = setTimeout(() => { resultsTimer = null; if (!destroyed && state?.phase === "results" && !document.querySelector(".modal.show")) openResults(); }, reducedMotion.matches ? 0 : 750);
      }
      /** Creates an accessible click/drop target; its stable ID is the only target sent to the server. */
      function makeTarget(space, className, text) {
        const target = element("button", className), label = element("span", "lr-target-label");
        if (["red", "black"].includes(space.id)) {
          const diamond = element("span", `lr-color-diamond lr-diamond-${space.id}`); diamond.setAttribute("aria-hidden", "true"); label.append(diamond);
        } else label.textContent = text;
        target.append(label); target.type = "button"; target.dataset.betSpace = space.id;
        target.title = `${space.category}: ${space.label} \u00b7 ${space.profitMultiplier}:1 profit`;
        target.setAttribute("aria-label", target.title); targets.set(space.id, target);
        const marker = element("span", "lr-space-chips"); marker.setAttribute("aria-hidden", "true"); target.append(marker);
        return target;
      }
      /** Builds number cells plus separate seam/intersection targets, never nesting one button inside another. */
      function buildBoard() {
        table.replaceChildren(); spaceSelect.replaceChildren(); targets.clear(); cells.clear();
        for (let number = 0; number <= 36; number++) {
          const cell = element("div", `lr-number-cell${number === 0 ? " lr-zero-cell" : ""}`);
          const color = number === 0 ? "green" : catalog.get("red").numbers.includes(number) ? "red" : "black";
          const button = makeTarget(catalog.get(`straight:${number}`), `lr-number lr-${color}`, String(number)); cell.append(button); table.append(cell); cells.set(number, cell);
        }
        const groups = new Map();
        for (const space of catalog.values()) {
          let group = groups.get(space.category);
          if (!group) { group = element("optgroup"); group.label = space.category; groups.set(space.category, group); spaceSelect.append(group); }
          const option = element("option", "", `${space.label} (${space.profitMultiplier}:1)`); option.value = space.id; group.append(option);
          if (space.category === "Straight up") continue;
          if (space.category === "Outside") table.append(makeTarget(space, `lr-outside-target${["red", "black"].includes(space.id) ? " lr-color-bet" : ""}`, space.id.startsWith("column:") ? "2 to 1" : space.id.startsWith("dozen:") ? ["1st 12", "2nd 12", "3rd 12"][Number(space.id.split(":")[1]) - 1] : space.label));
          else {
            const kind = space.id.startsWith("split:") ? "split" : (space.id.startsWith("corner:") || space.id.startsWith("trio:")) ? "corner" : space.id === "first-four" ? "first-four" : space.category.toLowerCase().replaceAll(" ", "-");
            const target = makeTarget(space, `lr-seam lr-seam-${kind}`, kind === "street" ? "3" : kind === "six-line" ? "6" : kind === "first-four" ? "4" : "");
            if (["split", "corner"].includes(kind)) target.dataset.insideMarker = "true";
            table.append(target);
          }
        }
        spaceSelect.value = selectedSpace; layoutBoard();
      }
      /** Maps the conventional portrait table into landscape without rotating any text. */
      function placeCell(node, column, row, width = 1, height = 1) {
        if (landscape.matches) [column, row, width, height] = [row, 8 - column - width, height, width];
        node.style.gridColumn = `${column} / span ${width}`;
        node.style.gridRow = `${row} / span ${height}`;
      }
      /** Lays out betting cells within the fluid game frame; CSS owns available width and height. */
      function layoutBoard() {
        if (destroyed) return;
        for (const [number, cell] of cells) {
          if (number === 0) placeCell(cell, 3, 1, 3);
          else placeCell(cell, (number - 1) % 3 + 3, Math.floor((number - 1) / 3) + 2);
        }
        for (let group = 1; group <= 3; group++) {
          const dozen = targets.get(`dozen:${group}`), column = targets.get(`column:${group}`);
          if (dozen) placeCell(dozen, 2, 2 + (group - 1) * 4, 1, 4);
          if (column) placeCell(column, group + 2, 14);
        }
        for (const [index, id] of ["low", "even", "red", "black", "odd", "high"].entries()) {
          const target = targets.get(id); if (target) placeCell(target, 1, 2 + index * 2, 1, 2);
        }
        positionTargets();
      }
      /** Places seams at shared cell edges in either orientation; streets use the outer number edge. */
      function positionTargets() {
        if (!catalog.size || destroyed) return;
        const bounds = table.getBoundingClientRect(); markerBounds = { left: bounds.left, top: bounds.top }; markerPoints = [];
        const boxes = new Map([...cells].map(([number, cell]) => { const rect = cell.getBoundingClientRect(); return [number, { left: rect.left - bounds.left, right: rect.right - bounds.left, top: rect.top - bounds.top, bottom: rect.bottom - bounds.top }]; }));
        for (const space of catalog.values()) {
          if (["Straight up", "Outside"].includes(space.category)) continue;
          const target = targets.get(space.id), covered = space.numbers.map(number => boxes.get(number));
          if (!target || covered.some(box => !box)) continue;
          let x = (Math.max(...covered.map(box => box.left)) + Math.min(...covered.map(box => box.right))) / 2;
          let y = (Math.max(...covered.map(box => box.top)) + Math.min(...covered.map(box => box.bottom))) / 2;
          if (["Street", "Six line"].includes(space.category) || space.id === "first-four") {
            if (landscape.matches) y = Math.min(...covered.map(box => box.top)) / 2;
            else x = (Math.max(...covered.map(box => box.right)) + bounds.width) / 2;
          }
          target.style.left = `${x}px`; target.style.top = `${y}px`;
          if (space.id.startsWith("split:")) {
            const overlap = Math.min(...covered.map(box => box.right)) - Math.max(...covered.map(box => box.left));
            target.classList.toggle("is-horizontal", overlap > 1);
          }
          if (target.dataset.insideMarker) {
            target.classList.remove("is-near"); markerPoints.push({ target, x, y, near: false });
          }
        }
        if (lastMarkerPointer) updateNearbyMarkers(lastMarkerPointer);
      }
      /** Reveals nearby seam decorations while leaving every hit area and placed chip intact. */
      function updateNearbyMarkers(event) {
        if (destroyed || event.pointerType === "touch") return;
        lastMarkerPointer = { clientX: event.clientX, clientY: event.clientY, pointerType: event.pointerType };
        const x = event.clientX - markerBounds.left, y = event.clientY - markerBounds.top;
        for (const point of markerPoints) {
          const near = Math.hypot(point.x - x, point.y - y) <= 28;
          if (near !== point.near) { point.near = near; point.target.classList.toggle("is-near", near); }
        }
      }
      /** Clears desktop proximity hints after the pointer leaves the betting board. */
      function clearNearbyMarkers() {
        lastMarkerPointer = null;
        for (const point of markerPoints) if (point.near) { point.near = false; point.target.classList.remove("is-near"); }
      }
      /** Builds the tray once; each chip is also a touch/mouse drag source. */
      function buildChips() {
        for (const value of [1, 10, 100, 1_000, 10_000, "custom"]) {
          const chip = element("button", "lr-chip", value === "custom" ? "Custom" : shortMoney(value)); chip.type = "button"; chip.dataset.chipValue = String(value); chips.append(chip);
        }
      }
      /** Cancels any active gesture without placing a wager. */
      function cancelDrag() { ghost?.remove(); ghost = null; drag = null; for (const target of targets.values()) target.classList.remove("is-drop-target"); }
      /** Begins a possible drag; a click still simply chooses the chip. */
      function pointerDown(event) {
        const chip = event.target.closest("[data-chip-value]"); if (!chip || chip.disabled || event.button !== 0 || !state?.canBet) return;
        const value = chip.dataset.chipValue === "custom" ? Number(amountInput.value) : Number(chip.dataset.chipValue);
        selectChip(value); drag = { pointerId: event.pointerId, x: event.clientX, y: event.clientY, value, moving: false, source: chip };
        chip.setPointerCapture?.(event.pointerId);
      }
      /** Moves a chip ghost and previews the legal target under the pointer, including narrow seams. */
      function pointerMove(event) {
        updateNearbyMarkers(event);
        if (hold && Math.hypot(event.clientX - hold.x, event.clientY - hold.y) > 8) { finishPreviewHold(event); hidePreview(); }
        if (!drag || event.pointerId !== drag.pointerId) return;
        if (!drag.moving && Math.hypot(event.clientX - drag.x, event.clientY - drag.y) < 6) return;
        drag.moving = true; event.preventDefault();
        if (!ghost) { ghost = element("span", "lr-chip lr-drag-ghost", shortMoney(drag.value)); ghost.setAttribute("aria-hidden", "true"); document.body.append(ghost); }
        ghost.style.left = `${event.clientX}px`; ghost.style.top = `${event.clientY}px`;
        const target = document.elementFromPoint(event.clientX, event.clientY)?.closest("[data-bet-space]");
        for (const button of targets.values()) button.classList.toggle("is-drop-target", button === target);
        if (target && root.contains(target) && hoverSpace !== target.dataset.betSpace) highlight(target.dataset.betSpace);

      }
      /** Drops a dragged chip once; ordinary target clicks are suppressed immediately after a drop. */
      function pointerUp(event) {
        finishPreviewHold(event);
        if (!drag || drag.pointerId !== event.pointerId) return;
        const moving = drag.moving, amount = drag.value, target = document.elementFromPoint(event.clientX, event.clientY)?.closest("[data-bet-space]");
        cancelDrag();
        if (moving) { suppressClickUntil = performance.now() + 350; if (target && root.contains(target)) place(target.dataset.betSpace, amount); }
      }
      /** Routes chip selection and table clicks without installing a listener on every betting space. */
      function rootClick(event) {
        const ownStack = event.target.closest("[data-edit-bet]");
        if (ownStack && performance.now() >= suppressClickUntil) { event.preventDefault(); openBetEditor(ownStack.dataset.editBet); return; }
        const chip = event.target.closest("[data-chip-value]");
        if (chip && !chip.disabled) { selectChip(chip.dataset.chipValue === "custom" ? Number(amountInput.value) : Number(chip.dataset.chipValue)); return; }
        const target = event.target.closest("[data-bet-space]");
        if (target && !target.disabled && performance.now() >= suppressClickUntil) place(target.dataset.betSpace);
      }

      /** Seats the first six participants below the board and any excess participants above it. */
      function renderPlayers() {
        players.replaceChildren(); topPlayers.replaceChildren();
        topPlayers.hidden = state.balances.length <= 6;
        for (const [index, player] of state.balances.entries()) {
          const card = element("div", `lr-player${player.id === context.memberId ? " is-local" : ""}`); card.style.setProperty("--player-color", player.color);
          card.classList.toggle("is-locked", player.locked);
          card.title = `${player.locked ? "Locked in | " : ""}${player.name}: ${money(player.balance)} total, ${money(player.available)} available${player.isConnected ? "" : ", offline"}`;
          card.append(element("strong", "", `${player.avatar} ${player.name}${!player.isConnected ? " \u00b7 offline" : ""}`), element("span", "", `${money(player.balance)} total`), element("small", "", `${money(player.available)} available \u00b7 ${money(player.reserved)} on table${player.locked ? " \u00b7 locked" : ""}${!player.isParticipating ? " \u00b7 watching tiebreaker" : ""}`));
          if (player.locked) { const stamp = element("span", "lr-ready-stamp", "LOCKED IN"); stamp.setAttribute("aria-hidden", "true"); card.append(stamp); }
          (index < 6 ? players : topPlayers).append(card);
        }
      }
      /** Draws owner-colored stacks; small wagers start at one chip and high wagers cap at ten or five. */
      function renderTableChips() {
        const owners = new Map(state.balances.map(player => [player.participantId, player]));
        const grouped = new Map();
        for (const bet of state.bets) { if (!grouped.has(bet.spaceId)) grouped.set(bet.spaceId, []); grouped.get(bet.spaceId).push(bet); }
        for (const [spaceId, target] of targets) {
          const marker = target.querySelector(".lr-space-chips"); marker.replaceChildren();
          const bets = grouped.get(spaceId) ?? []; target.classList.toggle("has-chips", bets.length > 0);
          // A crowded target shows up to three stacks; the exact full owner list remains in All table bets.
          const ordered = [...bets].sort((a, b) => Number(b.ownerId === localPlayer()?.participantId) - Number(a.ownerId === localPlayer()?.participantId));
          for (const bet of ordered.slice(0, 3)) {
            const owner = owners.get(bet.ownerId), height = stackHeight(bet.amount, owner?.balance ?? bet.amount);
            const stack = element("span", "lr-chip-stack"); stack.style.setProperty("--chip-color", owner?.color ?? "#aaa");
            stack.style.setProperty("--stack-height", String(height));
            if (bet.ownerId === localPlayer()?.participantId) { stack.dataset.editBet = bet.id; stack.classList.add("is-own"); }
            stack.title = `${owner?.name ?? "Departed player"}: ${money(bet.amount)} (${height} visual chips)`;
            for (let index = 0; index < height; index++) { const disc = element("span", "lr-chip-disc"); disc.style.setProperty("--stack-index", String(index)); stack.append(disc); }
            stack.append(element("span", "lr-stack-amount", shortMoney(bet.amount))); marker.append(stack);
          }
          if (bets.length > 3) marker.append(element("span", "lr-extra-owners", `+${bets.length - 3}`));
          const description = catalog.get(spaceId);
          target.setAttribute("aria-label", `${description.category}: ${description.label}; ${description.profitMultiplier}:1 profit${bets.length ? "; " + bets.map(bet => `${owners.get(bet.ownerId)?.name ?? "Departed player"} ${money(bet.amount)}`).join(", ") : ""}`);
        }
      }
      /** Updates keyed own-bet rows without throwing away an amount field currently being edited. */
      function renderBets() {
        const local = localPlayer(), mine = state.bets.filter(bet => bet.ownerId === local?.participantId);
        const ids = new Set(mine.map(bet => bet.id));
        for (const [id, row] of rows) if (!ids.has(id)) { row.remove(); rows.delete(id); }
        ownBets.querySelector(".lr-empty")?.remove();
        for (const bet of mine) {
          let row = rows.get(bet.id);
          if (!row) {
            row = element("li", "lr-own-bet"); const label = element("span"), input = element("input"), update = element("button", "", "Update"), remove = element("button", "", "Remove");
            input.type = "number"; input.min = "1"; input.step = "1"; input.inputMode = "numeric"; input.setAttribute("aria-label", `Stake for ${catalog.get(bet.spaceId).label}`);
            update.type = remove.type = "button";
            update.addEventListener("click", () => void submit("change-bet", { betId: bet.id, amount: Number(input.value) }));
            remove.addEventListener("click", () => void submit("remove-bet", { betId: bet.id }));
            row.append(label, input, update, remove); rows.set(bet.id, row); ownBets.append(row);
          }
          row.firstElementChild.textContent = catalog.get(bet.spaceId).label;
          const input = row.querySelector("input"); if (document.activeElement !== input) input.value = String(bet.amount);
          input.max = String((local?.available ?? 0) + bet.amount);
          for (const control of row.querySelectorAll("button, input")) control.disabled = !state.canBet || pending;
        }
        if (!mine.length) ownBets.append(element("li", "lr-empty", state.phase === "betting" ? "No bets placed. Abstaining is allowed." : "Betting is closed."));
        allBets.replaceChildren();
        for (const bet of state.bets) { const owner = state.balances.find(player => player.participantId === bet.ownerId); const item = element("li", "", `${owner?.name ?? "Departed player"} \u00b7 ${catalog.get(bet.spaceId)?.label ?? bet.spaceId} \u00b7 ${money(bet.amount)}`); item.style.borderLeftColor = owner?.color ?? "#aaa"; allBets.append(item); }
      }
      /** Keeps affordability, readiness, and host permissions synchronized without overwriting the typed amount. */
      function renderControls() {
        const local = localPlayer(), available = local?.available ?? 0, canBet = state?.canBet === true && !pending;
        amountInput.disabled = !canBet; amountInput.max = String(available); spaceSelect.disabled = !canBet;
        find("[data-lr-place]").disabled = !canBet; find("[data-lr-max]").disabled = !canBet || available <= 0;
        const amount = Number(amountInput.value);
        for (const chip of chips.querySelectorAll("[data-chip-value]")) {
          const custom = chip.dataset.chipValue === "custom", value = custom ? amount : Number(chip.dataset.chipValue);
          chip.disabled = !canBet || !Number.isSafeInteger(value) || value <= 0 || value > available;
          chip.setAttribute("aria-pressed", String(custom ? ![1, 10, 100, 1_000, 10_000].includes(selectedChip) : value === selectedChip));
          chip.setAttribute("aria-label", `Select or drag ${money(value)} chip${custom ? " (custom value)" : ""}`);
          if (custom) chip.textContent = "Custom";
          chip.style.setProperty("--chip-color", local?.color ?? "#ffe08a");
        }
        for (const target of targets.values()) target.disabled = !canBet;
        lockButton.disabled = !state?.canLock || pending; lockButton.textContent = state?.isLocked ? "Unlock bets" : "Lock in"; lockButton.setAttribute("aria-pressed", String(state?.isLocked === true));
        pauseButton.hidden = !context.isHost; pauseButton.disabled = !state || state.phase === "finished"; pauseButton.textContent = state?.isPaused ? "Resume" : "Pause";
        leaveButton.textContent = context.isHost ? "End game" : "Leave game";
        find("[data-lr-wallet]").textContent = local ? `${money(available)} available / ${money(local.balance)} total \u00b7 goal ${money(state.targetGoal)}` : "Spectating \u00b7 bets are read-only.";
        if (state) renderBets();
        for (const control of editForm.querySelectorAll("button,input")) control.disabled = !canBet;
        if (editingBetId) {
          const bet = state?.bets.find(item => item.id === editingBetId && item.ownerId === local?.participantId);
          if (!bet || !state.canBet || editingPhase !== `${state.matchId}:${state.phaseId}`) closeDialog();
          else editAmount.max = String(available + bet.amount);
        }
        if (!canBet && drag) cancelDrag();
        if (state?.phase !== "betting") { finishPreviewHold(); hidePreview(); }
      }
      /** Cancels presentation animations without changing the server-owned clock or result. */
      function clearAnimations() { timerAnimation?.cancel(); timerAnimation = null; for (const animation of wheelAnimations) animation.cancel(); wheelAnimations = []; }
      /** Refreshes countdown text only when needed; the fill uses a compositor-friendly scale animation. */
      function renderClock() {
        if (!state || destroyed) return;
        const recoveryText = recoveryDeadline === null ? "" : `Disconnect pause: ${Math.max(0, Math.ceil((recoveryDeadline - performance.now()) / 1000))} seconds remaining. The host may resume now.`;
        const recovery = find("[data-lr-recovery]"); if (recovery.textContent !== recoveryText) recovery.textContent = recoveryText;
        const remaining = state.isPaused || localDeadline === null ? state.remainingMs : Math.max(0, localDeadline - performance.now());
        const text = `${state.isPaused ? "Paused \u00b7 " : ""}${Math.ceil(remaining / 1_000)}s`;
        if (timerLabel.textContent !== text) timerLabel.textContent = text;
        const result = find("[data-lr-result-number]");
        const landed = state.winningNumber !== null && (state.phase !== "rolling" || remaining <= Math.min(1000, state.landingDurationMs / 2));
        const resultText = landed ? `Winning pocket: ${state.winningNumber}` : "Waiting for the ball to land...";
        if (result.textContent !== resultText) result.textContent = resultText;
        const percent = Math.max(0, Math.min(100, remaining / Math.max(1, state.phaseDurationMs) * 100));
        const value = String(Math.round(percent)); if (timerFill.parentElement.getAttribute("aria-valuenow") !== value) timerFill.parentElement.setAttribute("aria-valuenow", value);
        if (!timerAnimation) timerFill.style.transform = `scaleX(${percent / 100})`;
      }
      /** Creates a vector wheel from the server's pocket order; no image-generation asset is required. */
      function buildWheel(order) {
        const namespace = "http://www.w3.org/2000/svg";
        /** Creates an SVG element with fixed presentation attributes. */
        const svgElement = (name, attributes) => { const node = document.createElementNS(namespace, name); for (const [key, value] of Object.entries(attributes)) node.setAttribute(key, String(value)); return node; };
        rotor = svgElement("g", { class: "lr-wheel-rotor" }); const radius = 118, delta = 360 / order.length;
        for (let index = 0; index < order.length; index++) {
          const number = order[index], start = (index * delta - delta / 2 - 90) * Math.PI / 180, end = (index * delta + delta / 2 - 90) * Math.PI / 180;
          const color = number === 0 ? "#15804c" : catalog.get("red").numbers.includes(number) ? "#bc3441" : "#17212d";
          rotor.append(svgElement("path", { d: `M160 160 L${160 + Math.cos(start) * radius} ${160 + Math.sin(start) * radius} A${radius} ${radius} 0 0 1 ${160 + Math.cos(end) * radius} ${160 + Math.sin(end) * radius} Z`, fill: color, stroke: "#e1bd6b", "stroke-width": ".65" }));
          const inner = wheelGeometry.divider;
          rotor.append(svgElement("path", {
            class: "lr-wheel-number-box",
            d: `M${160 + Math.cos(start) * radius} ${160 + Math.sin(start) * radius} A${radius} ${radius} 0 0 1 ${160 + Math.cos(end) * radius} ${160 + Math.sin(end) * radius} L${160 + Math.cos(end) * inner} ${160 + Math.sin(end) * inner} A${inner} ${inner} 0 0 0 ${160 + Math.cos(start) * inner} ${160 + Math.sin(start) * inner} Z`,
            fill: color, stroke: "#e1bd6b", "stroke-width": 1.8, "stroke-linejoin": "round"
          }));
          const angle = (index * delta - 90) * Math.PI / 180;
          const x = 160 + Math.cos(angle) * wheelGeometry.number, y = 160 + Math.sin(angle) * wheelGeometry.number;
          const text = svgElement("text", { x, y, transform: `rotate(${index * delta} ${x} ${y})`, "text-anchor": "middle", "dominant-baseline": "central", fill: "#fff", "font-size": "9", "font-weight": "bold" });
          text.textContent = String(number); rotor.append(text);
        }
        rotor.append(svgElement("circle", { class: "lr-number-ring-divider", cx: 160, cy: 160, r: wheelGeometry.divider, fill: "none", stroke: "#e1bd6b", "stroke-width": 1.5 }));
        rotor.append(svgElement("circle", { cx: 160, cy: 160, r: 80, fill: "#795136", stroke: "#e1bd6b", "stroke-width": 4 }));
        rotor.append(svgElement("circle", { cx: 160, cy: 160, r: 53, fill: "#263a32", stroke: "#c49a4e", "stroke-width": 3 }));
        ball = svgElement("g", { class: "lr-wheel-ball" }); ball.append(svgElement("circle", { cx: 160, cy: 160 - wheelGeometry.orbit, r: 5, fill: "white", stroke: "#ccdae7", "stroke-width": 1 }));
        // A vector hand points at the launch position; it never participates in hit testing.
        flickHand = svgElement("g", { class: "lr-wheel-hand", "aria-hidden": "true", opacity: 0 });
        flickHand.append(svgElement("path", { d: "M43 -8 L62 -5 L60 21 L42 18 Z", fill: "#25496d", stroke: "#102c45", "stroke-width": 1.5 }));
        flickHand.append(svgElement("path", { d: "M44 -5 C36 -7 29 -7 23 -5 L4 -4 C-3 -4 -5 -1 -3 2 C-2 4 2 5 6 4 L20 3 L14 9 C11 13 14 16 18 15 L26 10 L22 17 C21 21 25 23 28 19 L33 13 L31 20 C31 24 36 25 38 21 L44 14 Z", fill: "#efbc91", stroke: "#87553c", "stroke-width": 1.3, "stroke-linejoin": "round" }));
        flickHand.append(svgElement("path", { d: "M1 -2 L7 -2 M27 3 L32 5 M35 6 L39 8", fill: "none", stroke: "#bd8260", "stroke-width": 1.2, "stroke-linecap": "round" }));
        pocketHighlight = svgElement("circle", { class: "lr-pocket-highlight", cx: 160, cy: 160, r: 8.5, fill: "none", stroke: "#ffe08a", "stroke-width": 2, opacity: 0, "aria-hidden": "true" });
        wheelScene = svgElement("g", { class: "lr-wheel-scene" });
        wheelScene.append(svgElement("circle", { cx: 160, cy: 160, r: 151, fill: "#402c22", stroke: "#b68a4d", "stroke-width": 5 }), rotor, ball, pocketHighlight, flickHand);
        wheel.replaceChildren(wheelScene);
      }
      /** Integrates a linear spin-up followed by constant angular speed, in degrees. */
      function spinUpDistance(elapsed, speed, startup) {
        return speed * (elapsed < startup ? elapsed * elapsed / (2 * startup) : elapsed - startup / 2);
      }
      /** Samples visible acceleration, cruising, and one second of smooth wheel braking. */
      function wheelAngle(elapsed, duration) {
        const startup = Math.min(800, duration / 4), brake = Math.min(1000, duration / 2);
        const speed = 1080 / (duration - startup / 2 - brake / 2);
        const time = Math.max(0, Math.min(duration, elapsed)), brakingTime = Math.max(0, time - (duration - brake));
        return spinUpDistance(time, speed, startup) - speed * brakingTime * brakingTime / (2 * brake);
      }
      /** Samples the ball's orbit, eased pocket capture, and final rotation with the braking wheel. */
      function ballTransform(elapsed, duration, landing, pocketAngle, revealed) {
        const revealAt = duration - landing, catchAt = duration - Math.min(1000, landing / 2);
        const startup = Math.min(800, duration / 4), orbitSpeed = -2160 / (duration - startup / 2);
        const start = spinUpDistance(revealAt, orbitSpeed, startup);
        if (!revealed || elapsed < revealAt) return `rotate(${spinUpDistance(elapsed, orbitSpeed, startup)}deg) translateY(0px)`;
        const wheelAtCatch = wheelAngle(catchAt, duration);
        const turns = Math.ceil((wheelAtCatch + pocketAngle - start) / 360);
        const end = wheelAtCatch + pocketAngle - turns * 360;
        if (elapsed >= catchAt) return `rotate(${wheelAngle(elapsed, duration) + pocketAngle - turns * 360}deg) translateY(${wheelGeometry.orbit - wheelGeometry.pocket}px)`;
        const interval = catchAt - revealAt, progress = Math.max(0, Math.min(1, (elapsed - revealAt) / interval));
        // Cubic Hermite joins the free orbit to the wheel's velocity without a visible jump.
        const square = progress * progress, cube = square * progress;
        const wheelSpeed = 1080 / (duration - startup / 2 - Math.min(1000, duration / 2) / 2);
        const angle = (2 * cube - 3 * square + 1) * start + (cube - 2 * square + progress) * orbitSpeed * interval
          + (-2 * cube + 3 * square) * end + (cube - square) * wheelSpeed * interval;
        const inward = square * (3 - 2 * progress) * (wheelGeometry.orbit - wheelGeometry.pocket);
        return `rotate(${angle}deg) translateY(${inward}px)`;
      }
      /** Samples the launch hand's approach, leftward flick, and withdrawal on the spin clock. */
      function flickPose(elapsed) {
        const poses = [
          { time: 0, x: 171, y: 21, angle: 14, opacity: 1 },
          { time: 120, x: 163, y: 23, angle: 0, opacity: 1 },
          { time: 300, x: 150, y: 24, angle: -16, opacity: 1 },
          { time: 850, x: 202, y: -15, angle: 28, opacity: 0 }
        ];
        const end = poses.findIndex(pose => pose.time >= elapsed);
        const to = poses[end < 0 ? poses.length - 1 : end], from = poses[Math.max(0, end - 1)];
        const fraction = end < 0 ? 1 : Math.max(0, Math.min(1, (elapsed - from.time) / Math.max(1, to.time - from.time)));
        const progress = fraction * fraction * (3 - 2 * fraction);
        return { transform: `translate(${from.x + (to.x - from.x) * progress}px, ${from.y + (to.y - from.y) * progress}px) rotate(${from.angle + (to.angle - from.angle) * progress}deg)`, opacity: from.opacity + (to.opacity - from.opacity) * progress };
      }
      /** Centers a gentle result zoom on the landed ball without changing the wheel's outcome. */
      function resultCamera(elapsed, angle) {
        const progress = Math.max(0, Math.min(1, elapsed / 650)), eased = progress * progress * (3 - 2 * progress);
        const scale = 1 + .65 * eased, radians = angle * Math.PI / 180;
        const x = Math.sin(radians) * wheelGeometry.pocket, y = -Math.cos(radians) * wheelGeometry.pocket;
        return `translate(${-x * scale * eased}px, ${-y * scale * eased}px) scale(${scale})`;
      }
      /** Highlights the winning inner pocket and zooms only after the wheel has stopped. */
      function showResultPocket(angle) {
        const isResult = ["results", "finished"].includes(state.phase) && state.winningNumber !== null;
        wheelScene.style.transform = "translate(0px, 0px) scale(1)";
        pocketHighlight.style.opacity = isResult ? "1" : "0";
        if (!isResult) return;
        const radians = angle * Math.PI / 180;
        pocketHighlight.setAttribute("cx", String(160 + Math.sin(radians) * wheelGeometry.pocket));
        pocketHighlight.setAttribute("cy", String(160 - Math.cos(radians) * wheelGeometry.pocket));
        if (reducedMotion.matches || document.body.classList.contains("reduce-interface-motion")) return;
        const elapsed = Math.max(0, state.phaseDurationMs - state.remainingMs);
        wheelScene.style.transform = resultCamera(elapsed, angle);
        if (!state.isPaused && elapsed < 650 && wheelScene.animate) {
          const remaining = 650 - elapsed, frames = [];
          for (let time = 0; time < remaining; time += 16) frames.push({ offset: time / remaining, transform: resultCamera(elapsed + time, angle) });
          frames.push({ offset: 1, transform: resultCamera(650, angle) });
          wheelAnimations.push(wheelScene.animate(frames, { duration: remaining, easing: "linear", fill: "forwards" }));
        }
      }
      /** Animates continuous orbit and capture; only the server's revealed pocket guides the landing. */
      function updateWheel() {
        if (!rotor || !state) return;
        const key = `${state.phaseId}:${state.phase}:${state.isPaused}:${state.winningNumber}`;
        if (wheelKey === key) return; wheelKey = key;
        for (const animation of wheelAnimations) animation.cancel(); wheelAnimations = [];
        flickHand.style.opacity = "0";
        const index = state.winningNumber === null ? 0 : state.wheelPockets.indexOf(state.winningNumber);
        const angle = Math.max(0, index) * 360 / state.wheelPockets.length;
        showResultPocket(angle);
        if (state.phase !== "rolling") { rotor.style.transform = "rotate(0deg)"; ball.style.transform = `rotate(${angle}deg) translateY(${wheelGeometry.orbit - wheelGeometry.pocket}px)`; return; }
        const duration = state.phaseDurationMs, remaining = state.remainingMs, elapsed = Math.max(0, duration - remaining);
        const revealed = state.winningNumber !== null;
        const handPose = flickPose(elapsed); flickHand.style.transform = handPose.transform;
        flickHand.style.opacity = reducedMotion.matches ? "0" : String(handPose.opacity);
        rotor.style.transform = `rotate(${wheelAngle(elapsed, duration)}deg)`;
        ball.style.transform = ballTransform(elapsed, duration, state.landingDurationMs, angle, revealed);
        if (state.isPaused || remaining <= 0 || reducedMotion.matches) {
          if (revealed && reducedMotion.matches) { rotor.style.transform = "rotate(0deg)"; ball.style.transform = `rotate(${angle}deg) translateY(${wheelGeometry.orbit - wheelGeometry.pocket}px)`; }
          return;
        }
        if (rotor.animate && ball.animate) {
          // Sample one continuous trajectory; both animations keep the authoritative phase deadline.
          const samples = Math.max(2, Math.ceil(remaining / 16)), wheelFrames = [], ballFrames = [];
          for (let sample = 0; sample <= samples; sample++) {
            const offset = sample / samples, time = elapsed + remaining * offset;
            wheelFrames.push({ offset, transform: `rotate(${wheelAngle(time, duration)}deg)` });
            ballFrames.push({ offset, transform: ballTransform(time, duration, state.landingDurationMs, angle, revealed) });
          }
          wheelAnimations.push(rotor.animate(wheelFrames, { duration: remaining, easing: "linear", fill: "forwards" }));
          wheelAnimations.push(ball.animate(ballFrames, { duration: remaining, easing: "linear", fill: "forwards" }));
          if (elapsed < 850 && flickHand.animate) {
            const handDuration = Math.min(remaining, 850 - elapsed), handFrames = [];
            for (let time = 0; time < handDuration; time += 16) handFrames.push({ offset: time / handDuration, ...flickPose(elapsed + time) });
            handFrames.push({ offset: 1, ...flickPose(elapsed + handDuration) });
            wheelAnimations.push(flickHand.animate(handFrames, { duration: handDuration, easing: "linear", fill: "forwards" }));
          }
        }
      }
      /** Reconciles one authoritative snapshot while keeping form nodes, board targets, and input focus stable. */
      function receiveState(next) {
        if (destroyed) return;
        state = next; localDeadline = state.isPaused ? null : performance.now() + state.remainingMs;
        recoveryDeadline = state.recoveryRemainingMs === null ? null : performance.now() + state.recoveryRemainingMs;
        if (!catalog.size) { catalog = new Map(state.betSpaces.map(space => [space.id, space])); buildBoard(); buildWheel(state.wheelPockets); }
        timerAnimation?.cancel(); timerAnimation = null;
        const fraction = Math.max(0, Math.min(1, state.remainingMs / Math.max(1, state.phaseDurationMs))); timerFill.style.transform = `scaleX(${fraction})`;
        if (!state.isPaused && state.remainingMs > 0 && timerFill.animate) timerAnimation = timerFill.animate([{ transform: `scaleX(${fraction})` }, { transform: "scaleX(0)" }], { duration: state.remainingMs, easing: "linear", fill: "forwards" });
        const text = state.phase === "finished" ? "Game finished" : `Round ${state.round}${state.isTiebreaker ? " \u00b7 tiebreaker" : ""} \u00b7 ${state.phase === "betting" ? "Place your bets" : state.phase === "rolling" ? "Wheel spinning" : "Round results"}`;
        const announcement = state.isPaused ? state.pauseMessage ?? "Game paused" : text;
        if (status.textContent !== announcement) status.textContent = announcement;
        find("[data-lr-recovery]").textContent = state.recoveryRemainingMs === null ? "" : `Disconnect pause: ${Math.ceil(state.recoveryRemainingMs / 1000)} seconds remaining. The host may resume now.`;
        find("[data-lr-betting]").hidden = state.phase !== "betting";
        find("[data-lr-chip-dock]").hidden = state.phase !== "betting";
        find("[data-lr-wheel-view]").hidden = state.phase === "betting";
        if (dialog.open && !editingBetId && state.phase !== "results") closeDialog();
        renderResults();
        renderPlayers(); renderTableChips(); renderControls(); renderClock(); updateWheel(); highlight(selectedSpace);
      }
      /** Toggles readiness; the server decides whether this was the final lock and advances the phase. */
      function toggleLock() { if (!dialog.open && state?.canLock && !pending) void submit("set-lock", { locked: !state.isLocked }); }
      /** Submits the accessible target selector's bet without requiring a drag gesture. */
      function submitForm(event) { event.preventDefault(); place(spaceSelect.value); }
      /** Keeps a typed custom value separate from the player's authoritative ledger. */
      function amountChanged() { selectedChip = Number(amountInput.value); renderControls(); }
      /** Selects the participant's current available cash as a single chip value. */
      function selectMax() { selectChip(localPlayer()?.available ?? 0); }
      /** Highlights the accessible target selector without spending until its Place button is used. */
      function selectionChanged() { selectedSpace = spaceSelect.value; highlight(selectedSpace); }
      /** Delegates pause authority to GameHub rather than deciding host ownership inside the plugin. */
      async function togglePause() { if (!state || !context.isHost) return; const response = await context.requestPause(!state.isPaused); if (!destroyed && response && !response.success) context.notify(response.message ?? "Pause could not be changed."); }
      /** Uses GameHub's existing confirmation flow for leaving or ending the game. */
      function leave() { if (context.isHost) context.requestExit(); else context.requestLeave(); }
      /** Recomputes compact stack heights when the phone breakpoint changes. */
      function compactChanged() { if (state && !destroyed) renderTableChips(); }
      /** Rebuilds animation presentation when the operating-system motion preference changes. */
      function motionChanged() { wheelKey = ""; updateWheel(); }
      buildChips(); renderControls(); layoutBoard();
      table.addEventListener("pointerleave", clearNearbyMarkers);
      root.addEventListener("click", rootClick); chips.addEventListener("pointerdown", pointerDown);
      root.addEventListener("pointerover", previewEntered); root.addEventListener("pointerout", previewLeft);
      root.addEventListener("focusin", previewEntered); root.addEventListener("focusout", previewLeft); root.addEventListener("pointerdown", previewHoldStart); root.addEventListener("contextmenu", previewContext);
      window.addEventListener("pointercancel", finishPreviewHold);
      find("[data-lr-dialog-close]").addEventListener("click", closeDialog); dialog.addEventListener("close", dialogClosed);
      editForm.addEventListener("submit", saveEditedBet); find("[data-lr-edit-remove]").addEventListener("click", removeEditedBet); resultsButton.addEventListener("click", openResults);
      window.addEventListener("pointermove", pointerMove, { passive: false }); window.addEventListener("pointerup", pointerUp); window.addEventListener("pointercancel", cancelDrag);
      form.addEventListener("submit", submitForm); amountInput.addEventListener("input", amountChanged); find("[data-lr-max]").addEventListener("click", selectMax);
      spaceSelect.addEventListener("change", selectionChanged); lockButton.addEventListener("click", toggleLock); pauseButton.addEventListener("click", togglePause); leaveButton.addEventListener("click", leave);
      compact.addEventListener?.("change", compactChanged); reducedMotion.addEventListener?.("change", motionChanged);
      const unsubscribe = context.input?.onAction("toggle-lock", toggleLock) ?? (() => {});
      const observer = typeof ResizeObserver === "function" ? new ResizeObserver(positionTargets) : null; observer?.observe(table);
      window.addEventListener("resize", layoutBoard);
      landscape.addEventListener?.("change", layoutBoard);
      const clockInterval = setInterval(renderClock, 200);
      return {
        receiveState,
        /** Displays public notices without exposing or deriving a hidden wheel result. */
        receiveEvent(event) { if (!destroyed && event.type === "notification" && typeof event.payload?.message === "string") context.notify(event.payload.message); },
        /** Refreshes host controls immediately after room ownership changes. */
        receivePlatformEvent(event) { if (!destroyed && event.type === "host-changed") renderControls(); },
        /** Freezes presentation promptly while the next authoritative pause snapshot is in flight. */
        setPaused(isPaused) { if (!state || destroyed || state.isPaused === isPaused) return; receiveState({ ...state, isPaused, remainingMs: localDeadline === null ? state.remainingMs : Math.max(0, localDeadline - performance.now()) }); },
        /** Removes every listener, timer, gesture, observer, and animation owned by this mount. */
        destroy() {
          destroyed = true; clearTimeout(resultsTimer); finishPreviewHold(); closeDialog(); preview.hidden = true; cancelDrag(); clearInterval(clockInterval); clearAnimations(); observer?.disconnect(); unsubscribe();
          clearNearbyMarkers(); table.removeEventListener("pointerleave", clearNearbyMarkers);
          root.removeEventListener("click", rootClick); chips.removeEventListener("pointerdown", pointerDown);
          root.removeEventListener("pointerover", previewEntered); root.removeEventListener("pointerout", previewLeft);
          root.removeEventListener("focusin", previewEntered); root.removeEventListener("focusout", previewLeft); root.removeEventListener("pointerdown", previewHoldStart); root.removeEventListener("contextmenu", previewContext);
          window.removeEventListener("pointercancel", finishPreviewHold);
          find("[data-lr-dialog-close]").removeEventListener("click", closeDialog); dialog.removeEventListener("close", dialogClosed);
          editForm.removeEventListener("submit", saveEditedBet); find("[data-lr-edit-remove]").removeEventListener("click", removeEditedBet); resultsButton.removeEventListener("click", openResults);
          resultList.replaceChildren(); resultsButton.disabled = true;
          window.removeEventListener("pointermove", pointerMove); window.removeEventListener("pointerup", pointerUp); window.removeEventListener("pointercancel", cancelDrag); window.removeEventListener("resize", layoutBoard);
          landscape.removeEventListener?.("change", layoutBoard);
          form.removeEventListener("submit", submitForm); amountInput.removeEventListener("input", amountChanged); find("[data-lr-max]").removeEventListener("click", selectMax);
          spaceSelect.removeEventListener("change", selectionChanged); lockButton.removeEventListener("click", toggleLock); pauseButton.removeEventListener("click", togglePause); leaveButton.removeEventListener("click", leave);
          compact.removeEventListener?.("change", compactChanged); reducedMotion.removeEventListener?.("change", motionChanged);
          chips.replaceChildren(); table.replaceChildren(); ownBets.replaceChildren(); allBets.replaceChildren(); players.replaceChildren(); topPlayers.replaceChildren(); wheel.replaceChildren(); spaceSelect.replaceChildren(); state = null;
        }
      };
    }
  });
})();
