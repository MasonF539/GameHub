# Loaded Roulette

Loaded Roulette now has a playable **basic single-zero roulette prototype** for
2-12 players. It replaces the temporary Add 1 action with real timed betting,
a shared server-chosen spin, and once-only payouts. Private card collections, reward drafts, and personal/public card effects are
playable in Public Effects or Final Preparations as indicated. Bank loans and repayments are available;
Shops and Shop Reroll are available; other effects and mid-match admission are still planned; this is not the complete designed game.

## Play the prototype

The current GameHub build installs a reviewed private development tarball from
its `vendor/` directory. Rebuild/start GameHub normally and choose Loaded
Roulette in the lobby. No npm publication is needed for this prototype.

- Select a chip, then click a target, or drag a chip onto it with mouse, pen, or touch.
- Quick denominations are 1, 10, 100, 1,000, and 10,000. The amount field and Custom chip support any affordable positive whole amount.
- Repeated chips on the same spot combine into one exact stake. Stakes reserve available cash; they are not settled losses until the spin ends.
- Stacks show one chip for $1 through 10% of settled bankroll, two through 20%, and so on up to ten. Phones use five levels in 20% bands. Exact stakes remain visible in the editable bet list.
- Seats 1-6 sit below the board; seats 7-12 sit above it when present. The timer and chip tray sit beneath the lower seats, so chips drag upward. Bet details stay in a right-hand panel when space allows.
- The entire betting table fits the viewport without scrolling. It runs horizontally in landscape and vertically in portrait, with upright labels and integrated outside-bet cells. Supporting bet details can scroll separately.
- Split targets use gold strips between numbers; corner targets at intersections; streets and six lines are along the row edge. Zero combinations and all conventional outside bets are available.
- Edit or remove a bet before readying up. You can cancel ready until everyone is ready or betting expires.
- Starting money uses a 1,000?200,000 slider (default 100,000); the goal is 100,000?2,000,000 (default 1,000,000), both in 1,000-unit steps.

## Prototype timing and recovery

Betting lasts 60 seconds, followed by 30 seconds of Final Preparations;
each phase can close early when everyone locks in. The initial presentation
uses a six-second spin, reveals the result for the final two seconds, and shows
settlement for five seconds. These are provisional presentation defaults. The
server draws once and settles independently of client animation completion.

Pause preserves phase time. Every disconnect starts or resets a 60-second pause;
the host can resume immediately. Early automatic resume waits for all missing
participants, and automatic recovery never undoes a manual pause. Reconnecting
with a new socket retains the same bankroll, reservations, and chip ownership.

Highest qualifying net balance wins. Net balance is cash minus outstanding debt. Equal leaders continue in tied-only
rounds. Departed owners' already-committed rolling bets settle, but they cannot
win. A departing pending winner is rechecked before match completion. If one
contender remains before a roll is committed, reservations are released and
that contender wins; if a roll is already underway, it settles first. No
participants ends the match without a winner. These departure details and the
all-missing-return rule are explicit prototype choices for the design's open
questions.

Without the future loan system, a player with no cash can abstain and watch;
the prototype does not grant money or invent bets. Late joiners remain
spectators until the future platform admission contract is implemented.

## Develop and verify

Use Node 24 for development. Node >=20 is the runtime engine range, not a
promise that every development dependency supports all Node 20 versions.

```powershell
npm ci
npm run check
npm test
npm run build
npm pack --dry-run
```

Keep `private: true`. To refresh GameHub after source changes, run `npm run update:roulette`
from GameHub. It checks/tests this project, builds/packs it into vendor/,
refreshes the readystallation, and runs `verify:packages`. Do not publish solely to test locally.

## Documentation

- [Design](docs/design.md): full intended game, including future progression systems.
- [Implementation](docs/implementation.md): architecture, implemented prototype, and remaining milestones.

Functions, classes, types, and important fields/constants have JSDoc hover
descriptions. Browser queries stay inside the mounted game root; every owned
listener, observer, timer, gesture, and animation is removed on unmount.

The spin slows the ball into its winning pocket before the wheel brakes over
the final second. The winning-number label appears at capture, while outcome
selection and settlement remain server-owned.

The game frame uses Egyptian War's fluid full-window shell with a 100rem width
cap. Outer margins disappear first on narrower windows; the game then follows
the remaining space without Bootstrap container-width jumps.

Controls, spacing, and board labels scale continuously with available space.
The board's own dimensions drive its label/target sizes, including portrait.
Landscape keeps the information panel on the right; portrait keeps it below,
without additional compact-width layout switches.

The wheel has a separate outer ball track, visible acceleration, and inward
pocket capture. Portrait reserves more room for controls. Settings sits beside
the game actions, with live connection status and ping underneath.

A short vector hand flick launches each spin and respects reduced motion. The
betting table uses detailed felt/rails and raised, player-colored chips with
amount labels underneath. EVEN and ODD are uppercase, column bets read 2 to 1,
and red/black bets use colored diamonds. The portrait bet panel fills leftover
space below the chip tray.

Wheel numbers face inward in separate boxes outside the landing pockets. The
ball crosses the number ring to land near the center, then a brief result zoom
highlights the winning pocket. Reduced motion uses the highlight without zoom.

Hover or hold a betting target to preview coverage, stake, and potential return.
Click your own placed chip to update or remove its wager; the existing bet list
still works. Ready seats turn green with a diagonal READY stamp.
After the pocket zoom, round results open in a scrollable modal with a card for
each bet and a personal net summary. Last round results reopens it while the
match continues. The timer keeps running; the modal closes when the next phase
starts. Sound cues remain deferred.

Inside split strips and corner squares appear near the desktop pointer or on
keyboard focus. Touch and hybrid devices keep them shown. Placed chips always
remain visible; street/six-line bets use permanently visible rectangular tabs.


## Cards and Final Preparations

Rewards begin before betting in round 2. Choose one of three cards within
30 seconds; rounds 2 and 3 offer temporary cards, round 4 permanent, repeating.
A connected player who does not choose receives a random offered card; an
absent player receives none. Hands and offers are private and survive reconnect.
The fan groups cards in design order, with duplicate counts in the top right.
Check cards opens the full collection and effect descriptions. After betting,
paid wagers freeze and readiness resets for Final Preparations. Supported cards
have a Play card button; permanent cards show Passive effect and resolve while owned.
Specialist has a Choose slot action. Type Reversal is active and preserves each card's own values and accumulated state.

- Profit up: consume a copy for +20% profit on winning bets this round. Copies add, and fractional money rounds down per wager.
- More draws: consume a copy for two random legal, uneditable free bets, each worth floor(5% of cash balance at play time). They reserve no cash and pay only profit on a win. At least 20 settled cash is needed.
- Double or nothing: once per round, gamble positive net betting profit after other bonuses. A separate server-side 50/50 draw doubles that profit or removes it; zero and losses stay unchanged. Extra copies remain for later rounds.

Each completed temporary card play consumes one copy and updates played-card history. Only public plays show an alert. Readying up
in preparations blocks further plays until you cancel ready; host pause and reconnect
preserve accepted cards and free bets. Round results show card-adjusted returns
and a separate Double or nothing adjustment before checking the match winner.
The full defined catalogue is active: targeted public effects, personal cards, generators,
trades/theft, passive permanent bonuses, and automatic negative penalties.
Type Reversal is active; numeric and approved utility effects reverse without replacing their values.


The chip box explicitly labels Current cash balance. Cash includes reserved
stakes until settlement; available cash excludes those stakes, while net
balance subtracts debt.

## Call Bank

Call Bank and Last round results share a row below the balance panel. It opens loan and repayment controls, each
with four percentage buttons (25%, 50%, 75%, and 100% of the current limit), a slider,
and a synchronized whole-number input. Terms show the exact fee and debt before
Confirm loan. The phase timer continues while the bank is open.

Borrow once per round during unlocked Shop or Betting, up to 25% of the goal. A loan
adds spendable principal and debt equal to principal plus floor(25%). There is
no recurring interest. Unpaid debt does not prevent another loan next round.
Repay during unlocked planning using only unreserved cash; repayment does not
reset the loan allowance. The bank retains private per-loan repayment history.

Players' net balance is cash minus outstanding debt. After settlement, debt is paid in full
automatically if the player can still meet the goal afterwards; results show
the payment, and winner/tie comparisons use net balance. Pause, refresh, and
reconnect preserve debt and that round's borrowing allowance. Loan/debt data
exists only in the current match's server memory.

The modal separates `.lr-bank-shell` from `.lr-bank-panel`, leaving room for
future shark-mouth framing without coupling artwork to forms or keyboard flow.

Betting uses the board directly by clicking or dragging chips onto its targets.
The separate betting-space dropdown and Place selected bet button are removed.


## Shop

Round 1 remains ordinary roulette. From round 2, a 30-second Shop stage follows
Rewards and precedes Betting. The striped booth has a centered wooden SHOP sign,
a separate display headed DEALS then REGULAR, and a bottom Cash / Debt / Net,
Call Bank, and Ready up bar. All eight offers fit without scrolling; tap a card
for a larger inspection with its purchase button. There is no Close button:
Ready up changes to Cancel ready, and all-ready or the deadline advances the game.
The host can pause/resume inside the shop. Closing the bank returns to it.

There are seven regular offers: two personal temporary/public and one personal
permanent at the top; three shared temporary/public and one shared permanent
below, with permanents on the right. Shared selection is the same across players,
but stock and spending are independent. A separate personal deal above these
seven draws a 25%-75% inclusive discount, fixed for that refresh. It is usually
temporary (6:1 temporary/permanent type weight).

Shop prices scale with starting cash, the goal, and average participating-player
net balance (cash minus outstanding debt):

```text
scale = 2 * starting cash + 2 * max(0, average net balance) + goal / 2
raw price = scale * card rate * rarity multiplier
```

Card rate is 1% for temporary/public and 3% for permanent. Rare cards apply a
2x multiplier before rounding. Round to the nearest whole unit below 20, or
the nearest 5 otherwise, always at least 1. Deals apply their 25%-75% discount
to the base price and use the same rounding rule.

| Starting cash | Goal | Average net | Temporary | Permanent |
| ---: | ---: | ---: | ---: | ---: |
| 50,000 | 100,000 | 50,000 | 2,500 | 7,500 |
| 50,000 | 100,000 | 100,000 | 3,500 | 10,500 |
| 100,000 | 1,000,000 | 100,000 | 9,000 | 27,000 |

The average is captured when Shop opens and reused for all purchases and
rerolls in that stage. Offline participants still count; spectators, departed
players, and players watching a tiebreaker do not. Prices refresh with the next
Shop stage. Borrowed principal does not count as new net wealth. Room size
alone does not increase prices. These weights remain balancing defaults;
round-number and individual-card adjustments are still deferred.

Each offer sells once. Sold out, Already maxed, and Not enough cash identify
unavailable purchases. Only accepted purchases deduct cash and grant a copy.
Shop Reroll consumes one owned copy and replaces all your offers (including the
deal and previously shared slots), without changing other players' shops.
Type Reversal activates on acquisition; each additional owned copy flips effect directions again. Pause/reconnect preserve stock and purchases.
Loans taken in Shop use the same once-per-round allowance as Betting.


### Checking cards and rerolling rewards

Shop and Rewards each expose Check cards. In Shop it opens the hand above the
booth, where Shop Reroll can be played. In Rewards it temporarily shows the
hand; Back to rewards or Escape returns to the mandatory picker instead of
closing the stage. A timeout or stage transition still closes the old view.

Reward Reroll is a normal positive temporary card. Play an already-owned copy
before accepting a reward to replace all current choices, preserving their
count, temporary/permanent type, rarity weighting, ownership caps, and remaining
time. It does not reroll anyone else's draft. Previously offered cards are
excluded when enough alternatives exist. A copy selected as the current reward
is saved for a later draft. Each accepted use consumes one copy; retries do not
consume another copy. The current working name can be changed later.

Shop cards use more shelf space and larger type. Hover/focus for one second
opens a full-size top-layer preview above the shop; tapping opens the readable
inspection dialog with its purchase button. All eight shelf offers still fit
without scrolling.

Shop cards can be clicked to inspect and double-clicked (or double-tapped) to
buy. Keyboard users can press Shift+Enter on a card to buy it. Prices and stock
status appear below each card; only the detail sign has a Buy card button. On roomy
landscape screens, the wooden side sign keeps the selected card visible.


### Public Effects stage

From round 2, the planning sequence is Rewards -> Shop -> Public Effects ->
Betting -> Final Preparations. Public Effects lasts 30 seconds, shows the betting
board, and allows checking your hand and reversible Ready up. All-ready advances
early; the deadline advances automatically. Round 1 retains ordinary roulette.

Profit Bonus and Profit Cut are playable in this stage, with a two-public-card
limit per player per round, with an extra play from More the Merrier when available. Targeted effects use private choice prompts and visible board markers. Betting, purchases, and new loans are unavailable during
Public Effects; unlocked debt repayment remains available through Call Bank.
Host pause, disconnect recovery, reconnect, and spectator permissions use the
same server rules as other planning stages. Readiness resets before Betting.


### Additional implemented card effects

| Card | Stage | Effect |
| --- | --- | --- |
| Profit Bonus | Public Effects | +30% winning profit for everyone this round. |
| Profit Cut | Public Effects | -30% winning profit for everyone this round. |
| Loan Relief | Final Preparations | Clear half the latest loan's original debt, capped by its unpaid balance. |
| Debt Reduction | Final Preparations | Clear 20% of all outstanding debt, oldest loans first. |
| Goal Grant | Final Preparations | Add 5% of the goal to current cash. |
| Cash Bonus | Final Preparations | Add 10% of current cash, including reserved stakes. |

Public profit modifiers add with Profit up and cancel equally; total reductions
stop at 80%, leaving at least 20% of normal winning profit. They affect paid and
free bets, persist after their owner leaves, and expire at the next round.
The profit gamble runs after these bonuses. Public plays are limited to two
per player by default; More the Merrier adds one when its cooldown permits.

Cash/debt percentages floor to whole units. Relief spends no cash, never resets
borrowing eligibility, and retains the card if it cannot clear a whole unit.
Latest-loan relief never spills into older loans. Cash Bonus also retains its
card if cash is below 10. Each accepted play consumes one copy and updates played-card history;
retries cannot repeat it. Cash changes are immediate; winner selection still
waits for settlement. Type Reversal is active.


### Public card presentation

Public cards pop onto the felt in a shared, noninteractive layer. The server
holds the exact Public Effects time remaining for the animation (currently
1.4 seconds) and permits one public play at a time. Other players and spectators
see the same animation; reconnecting viewers join its remaining portion.
Manual/disconnect pauses remain independent and are never cleared by an
animation finishing. The countdown resumes without resetting its duration.

Spot-targeted cards additionally slide/shrink to their selected space after the
common pop and then travel to their selected board number. Reduced motion uses stationary
feedback while preserving the same shared hold. Personal cards and rerolls animate only for their owner and have no play-alert popup. Public plays can still show an alert.
Public animations reveal the board by closing optional hand windows.

Purchased shop cards show a gold diagonal SOLD OUT overlay rather than adding
sold-out text beneath the price. The disabled purchase button still indicates
Sold out, and card labels retain accessible stock status.

### Drag cards to play

During Public Effects or Final Preparations, drag an eligible owned card from
the fan or Check cards window onto the betting board. Dragging from the window
reveals the board. A valid drop submits the same server-checked play as Play
card; confirmation starts the shared animation for public cards only. Personal cards animate privately without play alerts. Dropping outside,
canceling the pointer, or a rejected play does not consume the card and restores
the card window when appropriate. Mouse, pen, and touch share this behavior.
Preview cards and cards for another stage cannot be played by dragging.

Public Effects, Betting, and Final Preparations each show a brief full-width
stage ribbon. It runs for about two seconds, does not block controls or pause
the clock, and uses stationary feedback with reduced-motion preferences.


### Complete card rules in the current build

All defined catalogue effects are active, including Type Reversal and its approved utility mappings. Use Check cards for Play card, Choose slot,
passive status, and current counters. Public plays animate for everyone;
personal plays animate only for their owner. Private target dialogs never expose
another player's remaining hand. Dragging a targeted public card onto a number
selects that number; dropping elsewhere opens its target picker.

Trades and Discard work throughout a live match, including the wheel spin.
Unspent choices can be cancelled. Sticky Fingers spends its card when it reveals
choices; Trade up spends both inputs before revealing its permanent draft.
Those paid selections cannot be dismissed or rerolled for free, and unfinished
paid choices resolve randomly at a phase deadline. Revealed cards that have
already been spent by their owner cannot be stolen.

Normal permanent effects work while owned. Acquisition counts as the first held
round; Specialist must be assigned through Choose slot. More cards/More choices
with one copy trigger every second round after acquisition; two copies trigger
every round. More the Merrier's extra public play has a one-round cooldown
unless two copies are held. Patient Investor growth pauses on purchase and never
resets while held. Third times the charm counts betting rounds while owned;
its third round is free, with the combined stake budget snapshotted when Betting
opens and capped at 20% of cash per copy, maximum 100%.

Cashback refunds 20% of each losing paid stake per copy, capped at that stake;
free bets have no paid stake to refund. Cold Streak waits for the first
profitable betting round, then resolves and discards. Short Changed reduces
winning profit by 20% during the next round only, then expires even if no bets
win or the player abstains. Paperwork, Shop Closure,
Public Silence, Collection Notice, and Forced Sale first become due in the next
round; Limited Selection affects the next draft and Bad Investment the next
purchase. Forced Sale allows an owned-card choice during Final Preparations,
with a random eligible fallback at timeout. Negative to Positive suppresses
unresolved personal penalties while held without deleting their cards.

TAX includes profit exactly at 10% of the goal. TAX/Parking Tax claims use a
shared pre-tax profit snapshot after bonuses and gambles, never incoming tax
income. The combined payer cap is 50%; excess claims scale proportionally and
floor individually, leaving rounding dust with the payer. Debt Collector clears
debt from winning wager profit. Double Everything copies stack as repeated doublings (subject to safe integer limits). Extra losses from Double Everything become
penalty debt when cash is insufficient. All money remains whole-valued.


### Type Reversal

Each owned copy flips positive/negative card effects again and grants +20%
betting profit, capped at +100%; the first copy counts. Neutral/risky cards and
Negative to Positive are exempt. Cards keep their original values and accumulated
state: a scaled +15% becomes -15%. Already-played effects do not change.

Negative versions of positive temporary cards resolve automatically at their
applicable stage. Positive versions of negative personal cards can be held and
played. Check cards shows the current descriptions and polarity. Reversed
Go Fish/Sticky Fingers choose a random recipient; transfer messages explain
which player's reversed card caused a gift without exposing private hands.
Free Entry (reversed Cross out) gives every participant a free straight-up bet
on the marked number worth 5% of their cash when Betting opens. Reversed Forced
Sale grants one temporary card chosen from three offers. See the design for the
full mappings, timing, and unchanged caps.

Disabled card buttons explain the current restriction (for example, Cancel ready
to play, Blocked by Public Silence, or Public card limit reached). Negative
permanent cards show Passive effect, just like other passive permanent cards.

Card targets are selected directly on the highlighted player cards or betting
spaces. Blind theft shows a shared shuffled fan: backs for the selecting player,
faces for the hand owner. Only the selecting player can act. The approved card-back design automatically follows each hand owner's player color.

Card backs automatically match the hand owner's player color, including when
another player is selecting a card to steal. All backs retain the same design
and white border. No personal style setting is required.

Card fronts use silver checkers for temporary cards, purple diagonal texture for
public cards, and gold cross-hatching for permanents. Each type shares its own
diamond watermark; category badges and duplicate counts remain visible.
