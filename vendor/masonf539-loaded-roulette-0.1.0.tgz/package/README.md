# Loaded Roulette

Loaded Roulette now has a playable **basic single-zero roulette prototype** for
2?12 players. It replaces the temporary Add 1 action with real timed betting,
a shared server-chosen spin, and once-only payouts. Cards, shops, loans, and
mid-match admission are still planned; this is not the complete designed game.

## Play the prototype

The current GameHub build installs a reviewed private development tarball from
its `vendor/` directory. Rebuild/start GameHub normally and choose Loaded
Roulette in the lobby. No npm publication is needed for this prototype.

- Select a chip, then click a target, or drag a chip onto it with mouse, pen, or touch.
- Quick denominations are 1, 10, 100, 1,000, and 10,000. The amount field and Custom chip support any affordable positive whole amount.
- Repeated chips on the same spot combine into one exact stake. Stakes reserve available cash; they are not settled losses until the spin ends.
- Stacks show one chip for $1 through 10% of settled bankroll, two through 20%, and so on up to ten. Phones use five levels in 20% bands. Exact stakes remain visible in the editable bet list.
- The entire betting table fits the viewport without scrolling. It runs horizontally in landscape and vertically in portrait, with upright labels and integrated outside-bet cells. Supporting bet details can scroll separately.
- Split targets sit between numbers; corner targets at intersections; streets and six lines are along the row edge. Zero combinations and all conventional outside bets are available. A precise-target dropdown provides a keyboard/touch alternative.
- Edit or remove a bet before locking. You can unlock until everyone locks or betting expires.
- Starting money uses a 1,000?200,000 slider (default 100,000); the goal is 100,000?2,000,000 (default 1,000,000), both in 1,000-unit steps.

## Prototype timing and recovery

Betting lasts 60 seconds; all-ready can close it early. The initial presentation
uses a six-second spin, reveals the result for the final two seconds, and shows
settlement for five seconds. These are provisional presentation defaults. The
server draws once and settles independently of client animation completion.

Pause preserves phase time. Every disconnect starts or resets a 60-second pause;
the host can resume immediately. Early automatic resume waits for all missing
participants, and automatic recovery never undoes a manual pause. Reconnecting
with a new socket retains the same bankroll, reservations, and chip ownership.

Highest qualifying settled balance wins. Equal leaders continue in tied-only
rounds. Departed owners' already-committed rolling bets settle, but they cannot
win. A departing pending winner is rechecked before match completion. If one
contender remains before a roll is committed, reservations are released and
that contender wins; if a roll is already underway, it settles first. No
participants ends the match without a winner. These departure details and the
all-missing-return rule are explicit prototype choices for the design's open
questions.

Without the future loan system, a player with no cash can abstain and watch;
the prototype does not grant money or invent bets. Late joiners remain
spectators until the future platform admission contract is implemented.

## Develop and verify

Use Node 24 for development. Node >=20 is the runtime engine range, not a
promise that every development dependency supports all Node 20 versions.

```powershell
npm ci
npm run check
npm test
npm run build
npm pack --dry-run
```

Keep `private: true`. To refresh GameHub after source changes, run `npm run update:roulette`
from GameHub. It checks/tests this project, builds/packs it into vendor/,
refreshes the locked installation, and runs `verify:packages`. Do not publish solely to test locally.

## Documentation

- [Design](docs/design.md): full intended game, including future progression systems.
- [Implementation](docs/implementation.md): architecture, implemented prototype, and remaining milestones.

Functions, classes, types, and important fields/constants have JSDoc hover
descriptions. Browser queries stay inside the mounted game root; every owned
listener, observer, timer, gesture, and animation is removed on unmount.
