# Loaded Roulette

Loaded Roulette now has a playable **basic single-zero roulette prototype** for
2?12 players. It replaces the temporary Add 1 action with real timed betting,
a shared server-chosen spin, and once-only payouts. Private card collections, reward drafts, and three personal card effects are
available in Final Preparations. Bank loans and repayments are available;
Shops and Shop Reroll are available; other effects and mid-match admission are still planned; this is not the complete designed game.

## Play the prototype

The current GameHub build installs a reviewed private development tarball from
its `vendor/` directory. Rebuild/start GameHub normally and choose Loaded
Roulette in the lobby. No npm publication is needed for this prototype.

- Select a chip, then click a target, or drag a chip onto it with mouse, pen, or touch.
- Quick denominations are 1, 10, 100, 1,000, and 10,000. The amount field and Custom chip support any affordable positive whole amount.
- Repeated chips on the same spot combine into one exact stake. Stakes reserve available cash; they are not settled losses until the spin ends.
- Stacks show one chip for $1 through 10% of settled bankroll, two through 20%, and so on up to ten. Phones use five levels in 20% bands. Exact stakes remain visible in the editable bet list.
- Seats 1-6 sit below the board; seats 7-12 sit above it when present. The timer and chip tray sit beneath the lower seats, so chips drag upward. Bet details stay in a right-hand panel when space allows.
- The entire betting table fits the viewport without scrolling. It runs horizontally in landscape and vertically in portrait, with upright labels and integrated outside-bet cells. Supporting bet details can scroll separately.
- Split targets use gold strips between numbers; corner targets at intersections; streets and six lines are along the row edge. Zero combinations and all conventional outside bets are available.
- Edit or remove a bet before locking. You can unlock until everyone locks or betting expires.
- Starting money uses a 1,000?200,000 slider (default 100,000); the goal is 100,000?2,000,000 (default 1,000,000), both in 1,000-unit steps.

## Prototype timing and recovery

Betting lasts 60 seconds, followed by 30 seconds of Final Preparations;
each phase can close early when everyone locks in. The initial presentation
uses a six-second spin, reveals the result for the final two seconds, and shows
settlement for five seconds. These are provisional presentation defaults. The
server draws once and settles independently of client animation completion.

Pause preserves phase time. Every disconnect starts or resets a 60-second pause;
the host can resume immediately. Early automatic resume waits for all missing
participants, and automatic recovery never undoes a manual pause. Reconnecting
with a new socket retains the same bankroll, reservations, and chip ownership.

Highest qualifying net balance wins. Net balance is cash minus outstanding debt. Equal leaders continue in tied-only
rounds. Departed owners' already-committed rolling bets settle, but they cannot
win. A departing pending winner is rechecked before match completion. If one
contender remains before a roll is committed, reservations are released and
that contender wins; if a roll is already underway, it settles first. No
participants ends the match without a winner. These departure details and the
all-missing-return rule are explicit prototype choices for the design's open
questions.

Without the future loan system, a player with no cash can abstain and watch;
the prototype does not grant money or invent bets. Late joiners remain
spectators until the future platform admission contract is implemented.

## Develop and verify

Use Node 24 for development. Node >=20 is the runtime engine range, not a
promise that every development dependency supports all Node 20 versions.

```powershell
npm ci
npm run check
npm test
npm run build
npm pack --dry-run
```

Keep `private: true`. To refresh GameHub after source changes, run `npm run update:roulette`
from GameHub. It checks/tests this project, builds/packs it into vendor/,
refreshes the locked installation, and runs `verify:packages`. Do not publish solely to test locally.

## Documentation

- [Design](docs/design.md): full intended game, including future progression systems.
- [Implementation](docs/implementation.md): architecture, implemented prototype, and remaining milestones.

Functions, classes, types, and important fields/constants have JSDoc hover
descriptions. Browser queries stay inside the mounted game root; every owned
listener, observer, timer, gesture, and animation is removed on unmount.

The spin slows the ball into its winning pocket before the wheel brakes over
the final second. The winning-number label appears at capture, while outcome
selection and settlement remain server-owned.

The game frame uses Egyptian War's fluid full-window shell with a 100rem width
cap. Outer margins disappear first on narrower windows; the game then follows
the remaining space without Bootstrap container-width jumps.

Controls, spacing, and board labels scale continuously with available space.
The board's own dimensions drive its label/target sizes, including portrait.
Landscape keeps the information panel on the right; portrait keeps it below,
without additional compact-width layout switches.

The wheel has a separate outer ball track, visible acceleration, and inward
pocket capture. Portrait reserves more room for controls. Settings sits beside
the game actions, with live connection status and ping underneath.

A short vector hand flick launches each spin and respects reduced motion. The
betting table uses detailed felt/rails and raised, player-colored chips with
amount labels underneath. EVEN and ODD are uppercase, column bets read 2 to 1,
and red/black bets use colored diamonds. The portrait bet panel fills leftover
space below the chip tray.

Wheel numbers face inward in separate boxes outside the landing pockets. The
ball crosses the number ring to land near the center, then a brief result zoom
highlights the winning pocket. Reduced motion uses the highlight without zoom.

Hover or hold a betting target to preview coverage, stake, and potential return.
Click your own placed chip to update or remove its wager; the existing bet list
still works. Locked seats turn green with a diagonal LOCKED IN stamp.
After the pocket zoom, round results open in a scrollable modal with a card for
each bet and a personal net summary. Last round results reopens it while the
match continues. The timer keeps running; the modal closes when the next phase
starts. Sound cues remain deferred.

Inside split strips and corner squares appear near the desktop pointer or on
keyboard focus. Touch and hybrid devices keep them shown. Placed chips always
remain visible; street/six-line bets use permanently visible rectangular tabs.


## Cards and Final Preparations

Rewards begin before betting in round 2. Choose one of three cards within
30 seconds; rounds 2 and 3 offer temporary cards, round 4 permanent, repeating.
A connected player who does not choose receives a random offered card; an
absent player receives none. Hands and offers are private and survive reconnect.
The fan groups cards in design order, with duplicate counts in the top right.
Check cards opens the full collection and effect descriptions. After betting,
paid wagers freeze and readiness resets for Final Preparations. Supported cards
have a Play card button; others remain marked Preview only.

- Profit up: consume a copy for +20% profit on winning bets this round. Copies add, and fractional money rounds down per wager.
- More draws: consume a copy for two random legal, uneditable free bets, each worth floor(5% of cash balance at play time). They reserve no cash and pay only profit on a win. At least 20 settled cash is needed.
- Double or nothing: once per round, gamble positive net betting profit after other bonuses. A separate server-side 50/50 draw doubles that profit or removes it; zero and losses stay unchanged. Extra copies remain for later rounds.

Each accepted card play consumes one copy and is publicly announced. Locking
preparations blocks further plays until unlocked; host pause and reconnect
preserve accepted cards and free bets. Round results show card-adjusted returns
and a separate Double or nothing adjustment before checking the match winner.
Other card effects, including negative penalties and debt-relief cards, are still previews.


The chip box explicitly labels Current cash balance. Cash includes reserved
stakes until settlement; available cash excludes those stakes, while net
balance subtracts debt.

## Call Bank

Call Bank and Last round results share a row below the balance panel. It opens loan and repayment controls, each
with four percentage buttons (25%, 50%, 75%, and 100% of the current limit), a slider,
and a synchronized whole-number input. Terms show the exact fee and debt before
Confirm loan. The phase timer continues while the bank is open.

Borrow once per round during unlocked Shop or Betting, up to 25% of the goal. A loan
adds spendable principal and debt equal to principal plus floor(25%). There is
no recurring interest. Unpaid debt does not prevent another loan next round.
Repay during unlocked planning using only unreserved cash; repayment does not
reset the loan allowance. The bank retains private per-loan repayment history.

Players' net balance is cash minus outstanding debt. After settlement, debt is paid in full
automatically if the player can still meet the goal afterwards; results show
the payment, and winner/tie comparisons use net balance. Pause, refresh, and
reconnect preserve debt and that round's borrowing allowance. Loan/debt data
exists only in the current match's server memory.

The modal separates `.lr-bank-shell` from `.lr-bank-panel`, leaving room for
future shark-mouth framing without coupling artwork to forms or keyboard flow.

Betting uses the board directly by clicking or dragging chips onto its targets.
The separate betting-space dropdown and Place selected bet button are removed.


## Shop

Round 1 remains ordinary roulette. From round 2, a 30-second Shop stage follows
Rewards and precedes Betting. The striped booth has a centered wooden SHOP sign,
a separate display headed DEALS then REGULAR, and a bottom Cash / Debt / Net,
Call Bank, and Lock in bar. All eight offers fit without scrolling; tap a card
for a larger inspection with its purchase button. There is no Close button:
Lock in changes to Unlock, and all-ready or the deadline advances the game.
The host can pause/resume inside the shop. Closing the bank returns to it.

There are seven regular offers: two personal temporary/public and one personal
permanent at the top; three shared temporary/public and one shared permanent
below, with permanents on the right. Shared selection is the same across players,
but stock and spending are independent. A separate personal deal above these
seven draws a 25%-75% inclusive discount, fixed for that refresh. It is usually
temporary (6:1 temporary/permanent type weight).

Shop prices scale with starting cash, the goal, and average participating-player
net balance (cash minus outstanding debt):

```text
scale = 2 * starting cash + 2 * max(0, average net balance) + goal / 2
raw price = scale * card rate * rarity multiplier
```

Card rate is 1% for temporary/public and 3% for permanent. Rare cards apply a
2x multiplier before rounding. Round to the nearest whole unit below 20, or
the nearest 5 otherwise, always at least 1. Deals apply their 25%-75% discount
to the base price and use the same rounding rule.

| Starting cash | Goal | Average net | Temporary | Permanent |
| ---: | ---: | ---: | ---: | ---: |
| 50,000 | 100,000 | 50,000 | 2,500 | 7,500 |
| 50,000 | 100,000 | 100,000 | 3,500 | 10,500 |
| 100,000 | 1,000,000 | 100,000 | 9,000 | 27,000 |

The average is captured when Shop opens and reused for all purchases and
rerolls in that stage. Offline participants still count; spectators, departed
players, and players watching a tiebreaker do not. Prices refresh with the next
Shop stage. Borrowed principal does not count as new net wealth. Room size
alone does not increase prices. These weights remain balancing defaults;
round-number and individual-card adjustments are still deferred.

Each offer sells once. Sold out, Already maxed, and Not enough cash identify
unavailable purchases. Only accepted purchases deduct cash and grant a copy.
Shop Reroll consumes one owned copy and replaces all your offers (including the
deal and previously shared slots), without changing other players' shops.
Unimplemented card effects remain marked Preview; buying them collects a card
without activating its effect. Pause/reconnect preserve stock and purchases.
Loans taken in Shop use the same once-per-round allowance as Betting.


### Checking cards and rerolling rewards

Shop and Rewards each expose Check cards. In Shop it opens the hand above the
booth, where Shop Reroll can be played. In Rewards it temporarily shows the
hand; Back to rewards or Escape returns to the mandatory picker instead of
closing the stage. A timeout or stage transition still closes the old view.

Reward Reroll is a normal positive temporary card. Play an already-owned copy
before accepting a reward to replace all current choices, preserving their
count, temporary/permanent type, rarity weighting, ownership caps, and remaining
time. It does not reroll anyone else's draft. Previously offered cards are
excluded when enough alternatives exist. A copy selected as the current reward
is saved for a later draft. Each accepted use consumes one copy; retries do not
consume another copy. The current working name can be changed later.

Shop cards use more shelf space and larger type. Hover/focus for one second
opens a full-size top-layer preview above the shop; tapping opens the readable
inspection dialog with its purchase button. All eight shelf offers still fit
without scrolling.

Shop cards can be clicked to inspect and double-clicked (or double-tapped) to
buy. Keyboard users can press Shift+Enter on a card to buy it. Prices and stock
status appear below each card; only the detail sign has a Buy card button. On roomy
landscape screens, the wooden side sign keeps the selected card visible.
